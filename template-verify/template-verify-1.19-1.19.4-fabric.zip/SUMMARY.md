# Template Verify Summary

| Range | Loader | Minecraft | Status | Jar | Log |
| --- | --- | --- | --- | --- | --- |
| 1.19-1.19.4 | fabric | 1.19 | success | template_test-0.0.0.jar | 1.19.log |
| 1.19-1.19.4 | fabric | 1.19.1 | success | template_test-0.0.0.jar | 1.19.1.log |
| 1.19-1.19.4 | fabric | 1.19.2 | success | template_test-0.0.0.jar | 1.19.2.log |
| 1.19-1.19.4 | fabric | 1.19.3 | success | template_test-0.0.0.jar | 1.19.3.log |
| 1.19-1.19.4 | fabric | 1.19.4 | success | template_test-0.0.0.jar | 1.19.4.log |
