# Template Verify Summary

| Range | Loader | Minecraft | Status | Jar | Log |
| --- | --- | --- | --- | --- | --- |
| 1.21.2-1.21.8 | fabric | 1.21.2 | success | template_test-0.0.0.jar | 1.21.2.log |
| 1.21.2-1.21.8 | fabric | 1.21.3 | success | template_test-0.0.0.jar | 1.21.3.log |
| 1.21.2-1.21.8 | fabric | 1.21.4 | success | template_test-0.0.0.jar | 1.21.4.log |
| 1.21.2-1.21.8 | fabric | 1.21.5 | success | template_test-0.0.0.jar | 1.21.5.log |
| 1.21.2-1.21.8 | fabric | 1.21.6 | success | template_test-0.0.0.jar | 1.21.6.log |
| 1.21.2-1.21.8 | fabric | 1.21.7 | success | template_test-0.0.0.jar | 1.21.7.log |
| 1.21.2-1.21.8 | fabric | 1.21.8 | success | template_test-0.0.0.jar | 1.21.8.log |
