# Template Verify Summary

| Range | Loader | Minecraft | Status | Jar | Log |
| --- | --- | --- | --- | --- | --- |
| 1.21-1.21.1 | fabric | 1.21 | success | template_test-0.0.0.jar | 1.21.log |
| 1.21-1.21.1 | fabric | 1.21.1 | success | template_test-0.0.0.jar | 1.21.1.log |
