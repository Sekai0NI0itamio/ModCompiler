# Template Verify Summary

| Range | Loader | Minecraft | Status | Jar | Log |
| --- | --- | --- | --- | --- | --- |
| 1.17-1.17.1 | fabric | 1.17 | success | template_test-0.0.0.jar | 1.17.log |
| 1.17-1.17.1 | fabric | 1.17.1 | success | template_test-0.0.0.jar | 1.17.1.log |
