# Template Verify Summary

| Range | Loader | Minecraft | Status | Jar | Log |
| --- | --- | --- | --- | --- | --- |
| 1.20-1.20.6 | neoforge | 1.20.2 | success | template_test-0.0.0.jar | 1.20.2.log |
| 1.20-1.20.6 | neoforge | 1.20.4 | success | template_test-0.0.0.jar | 1.20.4.log |
| 1.20-1.20.6 | neoforge | 1.20.5 | success | template_test-0.0.0.jar | 1.20.5.log |
| 1.20-1.20.6 | neoforge | 1.20.6 | success | template_test-0.0.0.jar | 1.20.6.log |
