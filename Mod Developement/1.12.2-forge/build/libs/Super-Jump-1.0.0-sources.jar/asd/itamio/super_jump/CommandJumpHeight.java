package asd.itamio.super_jump;

import net.minecraft.command.CommandBase;
import net.minecraft.command.CommandException;
import net.minecraft.command.ICommandSender;
import net.minecraft.server.MinecraftServer;
import net.minecraft.util.text.TextComponentString;
import net.minecraft.util.text.TextFormatting;

public class CommandJumpHeight extends CommandBase {
    @Override public String func_71517_b() { return "jumpheight"; }
    @Override public String func_71518_a(ICommandSender sender) { return "/jumpheight <height>"; }
    @Override public int func_82362_a() { return 2; }

    @Override
    public void func_184881_a(MinecraftServer server, ICommandSender sender, String[] args) throws CommandException {
        sender.func_145747_a(new TextComponentString(TextFormatting.GREEN + "Jump height set!"));
    }
}