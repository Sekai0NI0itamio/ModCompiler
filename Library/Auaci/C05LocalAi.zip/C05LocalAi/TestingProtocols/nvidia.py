import requests
import json
import time
from typing import Dict, List, Optional, Union
import os

class Nemotron3NanoAgent:
    """
    NVIDIA Nemotron-3-Nano-30B-A3B Research Agent
    Handles message sending, reasoning processes, and response handling
    """
    
    def __init__(self, api_key: str = None, base_url: str = "https://integrate.api.nvidia.com"):
        """
        Initialize the NVIDIA Nemotron agent
        
        Args:
            api_key: NVIDIA API key (if None, will try to get from environment)
            base_url: Base URL for NVIDIA API
        """
        self.api_key = api_key or os.getenv('NVIDIA_API_KEY') or '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'
        self.base_url = base_url
        self.model_name = "nvidia/nemotron-3-nano-30b-a3b"
        
        if not self.api_key:
            raise ValueError("NVIDIA API key required. Set NVIDIA_API_KEY environment variable or pass api_key parameter")
            
        self.headers = {
            "Authorization": f"Bearer {self.api_key}",
            "Content-Type": "application/json"
        }
        
    def send_message(self, 
                    message: str, 
                    enable_thinking: bool = True,
                    max_tokens: int = 1024,
                    temperature: float = 1.0,
                    top_p: float = 1.0,
                    reasoning_effort: Optional[int] = None) -> Dict:
        """
        Send a message to NVIDIA Nemotron-3-Nano-30B-A3B service
        
        Args:
            message: The message to send to the model
            enable_thinking: Whether to enable reasoning traces (default True)
            max_tokens: Maximum tokens to generate
            temperature: Sampling temperature (1.0 recommended for reasoning)
            top_p: Top-p sampling parameter
            reasoning_effort: Optional reasoning effort parameter
            
        Returns:
            Dictionary containing the full response from NVIDIA API
        """
        url = f"{self.base_url}/v1/chat/completions"
        
        # Prepare the messages payload
        messages = [
            {"role": "user", "content": message}
        ]
        
        # Prepare the request body
        payload = {
            "model": self.model_name,
            "messages": messages,
            "max_tokens": max_tokens,
            "temperature": temperature,
            "top_p": top_p,
            "stream": False
        }
        
        # Add reasoning parameters if enabled
        if enable_thinking:
            payload["chat_template_kwargs"] = {"enable_thinking": True}
            if reasoning_effort is not None:
                payload["chat_template_kwargs"]["reasoning_effort"] = reasoning_effort
        
        try:
            response = requests.post(url, headers=self.headers, json=payload)
            response.raise_for_status()
            return response.json()
        except requests.exceptions.RequestException as e:
            print(f"Error sending message: {e}")
            raise
    
    def extract_reasoning_and_response(self, api_response: Dict) -> Dict:
        """
        Extract reasoning traces and final response from API response
        
        Args:
            api_response: Raw response from NVIDIA API
            
        Returns:
            Dictionary containing reasoning text and final response
        """
        if 'choices' not in api_response or len(api_response['choices']) == 0:
            return {"error": "No response received"}
        
        choice = api_response['choices'][0]
        message_content = choice.get('message', {}).get('content', '')
        
        # Parse reasoning traces and final response
        # Nemotron models typically use special tokens or formatting for reasoning
        reasoning_text = ""
        final_response = message_content
        
        # Look for reasoning patterns (this may need adjustment based on actual model output)
        if "❖" in message_content or "◆" in message_content:
            # Common reasoning indicator tokens
            parts = message_content.split("❖") if "❖" in message_content else message_content.split("◆")
            if len(parts) > 1:
                reasoning_text = parts[0].strip()
                final_response = parts[-1].strip()
        elif "Reasoning:" in message_content and "Answer:" in message_content:
            # Alternative pattern
            parts = message_content.split("Answer:")
            if len(parts) > 1:
                reasoning_part = parts[0].replace("Reasoning:", "").strip()
                reasoning_text = reasoning_part
                final_response = parts[1].strip()
        
        return {
            "reasoning_text": reasoning_text,
            "final_response": final_response,
            "full_content": message_content,
            "usage": api_response.get('usage', {})
        }
    
    def chat_with_reasoning(self, 
                          message: str, 
                          reasoning_effort: Optional[int] = None,
                          max_tokens: int = 1024) -> Dict:
        """
        Send a message and extract reasoning traces and final response
        
        Args:
            message: The message to send
            reasoning_effort: Optional reasoning effort parameter
            max_tokens: Maximum tokens to generate
            
        Returns:
            Dictionary containing reasoning process and final answer
        """
        print(f"Sending message: {message}")
        print(f"Reasoning enabled: True")
        
        # Send message to NVIDIA service
        response = self.send_message(
            message=message,
            enable_thinking=True,
            reasoning_effort=reasoning_effort,
            max_tokens=max_tokens
        )
        
        # Extract reasoning and response
        result = self.extract_reasoning_and_response(response)
        
        print(f"Reasoning text extracted: {len(result['reasoning_text'])} characters")
        print(f"Final response extracted: {len(result['final_response'])} characters")
        
        return result
    
    def chat_without_reasoning(self, 
                             message: str, 
                             max_tokens: int = 512) -> Dict:
        """
        Send a message without reasoning traces (direct response)
        
        Args:
            message: The message to send
            max_tokens: Maximum tokens to generate
            
        Returns:
            Dictionary containing the direct response
        """
        print(f"Sending message (no reasoning): {message}")
        
        response = self.send_message(
            message=message,
            enable_thinking=False,
            max_tokens=max_tokens,
            temperature=0.6,  # Lower temperature for direct responses
            top_p=0.95
        )
        
        result = self.extract_reasoning_and_response(response)
        
        print(f"Direct response extracted: {len(result['final_response'])} characters")
        
        return result
    
    def batch_process(self, 
                     messages: List[str], 
                     enable_thinking: bool = True,
                     delay_between_requests: float = 1.0) -> List[Dict]:
        """
        Process multiple messages in batch
        
        Args:
            messages: List of messages to process
            enable_thinking: Whether to enable reasoning
            delay_between_requests: Delay between API calls (seconds)
            
        Returns:
            List of results for each message
        """
        results = []
        
        for i, message in enumerate(messages):
            print(f"Processing message {i+1}/{len(messages)}")
            
            try:
                if enable_thinking:
                    result = self.chat_with_reasoning(message)
                else:
                    result = self.chat_without_reasoning(message)
                
                results.append(result)
                
                # Add delay to avoid rate limiting
                if i < len(messages) - 1:
                    time.sleep(delay_between_requests)
                    
            except Exception as e:
                print(f"Error processing message {i+1}: {e}")
                results.append({"error": str(e)})
        
        return results

# Example usage and testing
def main():
    """
    Example usage of the Nemotron-3-Nano-30B-A3B research agent
    """
    
    # Initialize the agent (API key should be set in environment or passed)
    try:
        agent = Nemotron3NanoAgent()
    except ValueError as e:
        print(f"Initialization error: {e}")
        print("Please set NVIDIA_API_KEY environment variable")
        return
    
    # Example 1: Simple message with reasoning
    print("=== Example 1: Reasoning Enabled ===")
    message1 = "Explain how transformers work in machine learning"
    result1 = agent.chat_with_reasoning(message1)
    
    print(f"\nReasoning:\n{result1['reasoning_text']}")
    print(f"\nFinal Answer:\n{result1['final_response']}")
    print(f"\nTokens used: {result1['usage']}")
    
    # Example 2: Message without reasoning
    print("\n=== Example 2: Reasoning Disabled ===")
    message2 = "Write a Python function to calculate Fibonacci numbers"
    result2 = agent.chat_without_reasoning(message2)
    
    print(f"\nDirect Response:\n{result2['final_response']}")
    
    # Example 3: Batch processing
    print("\n=== Example 3: Batch Processing ===")
    messages = [
        "What is the capital of France?",
        "Explain quantum computing basics",
        "Write a haiku about artificial intelligence"
    ]
    
    batch_results = agent.batch_process(messages, enable_thinking=True)
    
    for i, result in enumerate(batch_results):
        print(f"\nMessage {i+1} Result:")
        if 'error' in result:
            print(f"Error: {result['error']}")
        else:
            print(f"Reasoning: {result['reasoning_text'][:100]}...")
            print(f"Response: {result['final_response'][:100]}...")

# Configuration helper functions
def setup_environment():
    """
    Helper function to set up environment variables
    """
    env_template = """
# NVIDIA API Configuration
export NVIDIA_API_KEY="your_nvidia_api_key_here"

# Optional: Custom API endpoint (if using different deployment)
export NVIDIA_API_BASE_URL="https://integrate.api.nvidia.com"
"""
    print("Environment setup template:")
    print(env_template)

def validate_api_key(api_key: str) -> bool:
    """
    Validate NVIDIA API key by making a test request
    
    Args:
        api_key: API key to validate
        
    Returns:
        True if valid, False otherwise
    """
    try:
        agent = Nemotron3NanoAgent(api_key=api_key)
        test_response = agent.send_message("Test message", enable_thinking=False, max_tokens=10)
        return 'choices' in test_response
    except:
        return False

if __name__ == "__main__":
    # Run examples if executed directly
    main()
    
    # Show environment setup instructions
    setup_environment()

