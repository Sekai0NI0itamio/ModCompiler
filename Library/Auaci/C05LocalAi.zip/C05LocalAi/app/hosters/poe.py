from typing import Any, AsyncIterator, Dict, List, Optional

from openai import AsyncOpenAI

from ..core.utils import debug_print
from .base import Hoster, HosterConfig


class PoeHoster(Hoster):
    def __init__(self, keyring):
        super().__init__(HosterConfig(hoster="poe", base_url="https://api.poe.com/v1"), keyring)

    def transform_extra_body(self, extra_body: Optional[Dict[str, Any]]) -> Optional[Dict[str, Any]]:
        if not extra_body:
            return extra_body

        transformed = dict(extra_body)

        if "response_format" in transformed:
            response_format = transformed.pop("response_format")
            if isinstance(response_format, dict) and response_format.get("type") == "text":
                pass
            else:
                transformed["response_format"] = response_format

        if "max_completion_tokens" in transformed:
            transformed["max_tokens"] = transformed.pop("max_completion_tokens")

        unsupported_params = [
            "parallel_tool_calls",
            "seed",
        ]
        for param in unsupported_params:
            if param in transformed:
                debug_print(f"[TRANSFORM:poe] Removing unsupported parameter: {param}")
                transformed.pop(param)

        return transformed

    async def stream_chat_completions(
        self,
        *,
        api_key: str,
        model: str,
        messages: List[dict],
        extra_body: Optional[Dict[str, Any]] = None,
        tools: Optional[List[Dict[str, Any]]] = None,
        tool_choice: Optional[Any] = None,
    ) -> AsyncIterator[Any]:
        client = AsyncOpenAI(api_key=api_key, base_url=self.config.base_url)
        try:
            create_kwargs: Dict[str, Any] = {
                "model": model,
                "messages": messages,
                "stream": True,
            }
            if extra_body:
                create_kwargs["extra_body"] = self.transform_extra_body(extra_body)
            if tools:
                create_kwargs["tools"] = tools
                if tool_choice is not None:
                    create_kwargs["tool_choice"] = tool_choice

            response = await client.chat.completions.create(**create_kwargs)
            try:
                async for chunk in response:
                    yield chunk
            finally:
                try:
                    aclose = getattr(response, "aclose", None)
                    if callable(aclose):
                        r = aclose()
                        if hasattr(r, "__await__"):
                            await r
                except Exception:
                    pass
        finally:
            try:
                aclose = getattr(client, "aclose", None)
                if callable(aclose):
                    r = aclose()
                    if hasattr(r, "__await__"):
                        await r
            except Exception:
                pass
