from __future__ import annotations

from abc import ABC, abstractmethod
from dataclasses import dataclass
from typing import Any, AsyncIterator, Dict, List, Optional

from ..core.keyring import KeyRing


@dataclass
class HosterConfig:
    hoster: str
    base_url: str


class Hoster(ABC):
    """A streaming chat-completions hoster."""

    def __init__(self, config: HosterConfig, keyring: KeyRing):
        self.config = config
        self.keyring = keyring

    @abstractmethod
    def transform_extra_body(self, extra_body: Optional[Dict[str, Any]]) -> Optional[Dict[str, Any]]:
        ...

    @abstractmethod
    async def stream_chat_completions(
        self,
        *,
        api_key: str,
        model: str,
        messages: List[dict],
        extra_body: Optional[Dict[str, Any]] = None,
        tools: Optional[List[Dict[str, Any]]] = None,
        tool_choice: Optional[Any] = None,
    ) -> AsyncIterator[Any]:
        ...
