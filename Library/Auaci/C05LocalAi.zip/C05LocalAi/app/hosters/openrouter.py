from typing import Any, AsyncIterator, Dict, List, Optional

from openai import AsyncOpenAI

from .base import Hoster, HosterConfig


class OpenRouterHoster(Hoster):
    def __init__(self, keyring):
        super().__init__(HosterConfig(hoster="openrouter", base_url="https://openrouter.ai/api/v1"), keyring)

    def transform_extra_body(self, extra_body: Optional[Dict[str, Any]]) -> Optional[Dict[str, Any]]:
        # OpenRouter is largely OpenAI-compatible; pass through.
        return extra_body

    async def stream_chat_completions(
        self,
        *,
        api_key: str,
        model: str,
        messages: List[dict],
        extra_body: Optional[Dict[str, Any]] = None,
        tools: Optional[List[Dict[str, Any]]] = None,
        tool_choice: Optional[Any] = None,
    ) -> AsyncIterator[Any]:
        client = AsyncOpenAI(api_key=api_key, base_url=self.config.base_url)
        try:
            create_kwargs: Dict[str, Any] = {
                "model": model,
                "messages": messages,
                "stream": True,
                "extra_body": extra_body or {},
            }
            if tools:
                create_kwargs["tools"] = tools
                if tool_choice is not None:
                    create_kwargs["tool_choice"] = tool_choice

            response = await client.chat.completions.create(**create_kwargs)
            try:
                async for chunk in response:
                    yield chunk
            finally:
                try:
                    aclose = getattr(response, "aclose", None)
                    if callable(aclose):
                        r = aclose()
                        if hasattr(r, "__await__"):
                            await r
                except Exception:
                    pass
        finally:
            try:
                aclose = getattr(client, "aclose", None)
                if callable(aclose):
                    r = aclose()
                    if hasattr(r, "__await__"):
                        await r
            except Exception:
                pass
