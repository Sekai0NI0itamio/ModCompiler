import asyncio
import json
from pathlib import Path
from typing import Any, Dict, List, Optional

from ..core.utils import drop_nones, sanitize_id

MAX_HISTORY_MESSAGES = 40

SESSIONS_DIR = Path("sessions")
SESSIONS_DIR.mkdir(exist_ok=True, parents=True)

_session_locks: dict[str, asyncio.Lock] = {}
_session_locks_lock = asyncio.Lock()


def session_dir_for(app_id: str) -> Path:
    safe_app = sanitize_id(app_id or "default")
    d = SESSIONS_DIR / safe_app
    d.mkdir(parents=True, exist_ok=True)
    return d


def session_file_path(app_id: str, session_id: str) -> Path:
    safe_session = sanitize_id(session_id)
    return session_dir_for(app_id) / f"{safe_session}.json"


async def get_session_lock(app_id: str, session_id: str) -> asyncio.Lock:
    key = f"{sanitize_id(app_id)}:{sanitize_id(session_id)}"
    async with _session_locks_lock:
        lock = _session_locks.get(key)
        if lock is None:
            lock = asyncio.Lock()
            _session_locks[key] = lock
        return lock


def _sync_load_session(path: Path) -> List[dict]:
    if not path.exists():
        return []
    try:
        with path.open("r", encoding="utf-8") as f:
            data = json.load(f)
            if isinstance(data, list):
                return data
            return []
    except Exception:
        return []


def _sync_save_session(path: Path, messages: List[dict]) -> None:
    tmp = path.with_suffix(".json.tmp")
    with tmp.open("w", encoding="utf-8") as f:
        json.dump(messages, f, ensure_ascii=False, indent=2)
    tmp.replace(path)


async def load_session(app_id: str, session_id: str) -> List[dict]:
    path = session_file_path(app_id, session_id)
    loop = asyncio.get_running_loop()
    return await loop.run_in_executor(None, _sync_load_session, path)


async def save_session(app_id: str, session_id: str, messages: List[dict]) -> None:
    path = session_file_path(app_id, session_id)
    loop = asyncio.get_running_loop()
    await loop.run_in_executor(None, _sync_save_session, path, messages)


def _compute_overlap(existing: List[dict], new: List[dict]) -> int:
    max_k = min(len(existing), len(new))
    for k in range(max_k, 0, -1):
        if existing[-k:] == new[:k]:
            return k
    return 0


async def append_messages_to_session(
    app_id: str,
    session_id: str,
    new_messages: List[dict],
    system_message: Optional[str] = None,
) -> None:
    if not new_messages:
        return

    lock = await get_session_lock(app_id, session_id)
    async with lock:
        msgs = await load_session(app_id, session_id)

        if system_message and isinstance(system_message, str) and system_message.strip():
            if msgs:
                if msgs[0].get("role") == "system":
                    if msgs[0].get("content") != system_message:
                        msgs[0] = {"role": "system", "content": system_message}
                else:
                    msgs.insert(0, {"role": "system", "content": system_message})
            else:
                msgs = [{"role": "system", "content": system_message}]

        cleaned: List[dict] = []
        for m in new_messages:
            if not isinstance(m, dict):
                continue
            role = m.get("role")
            if not role:
                continue
            cleaned.append(drop_nones(m))

        if not cleaned:
            return

        overlap = _compute_overlap(msgs, cleaned)
        msgs.extend(cleaned[overlap:])

        if len(msgs) > MAX_HISTORY_MESSAGES:
            msgs = msgs[-MAX_HISTORY_MESSAGES:]

        await save_session(app_id, session_id, msgs)


def list_session_files(app_id: Optional[str] = None) -> List[dict]:
    files = []
    if app_id:
        safe_app = sanitize_id(app_id)
        app_dir = SESSIONS_DIR / safe_app
        if not app_dir.exists() or not app_dir.is_dir():
            return []
        for f in app_dir.glob("*.json"):
            if f.is_file():
                try:
                    mtime = f.stat().st_mtime
                except Exception:
                    mtime = 0.0
                files.append({"path": f, "app_id": safe_app, "session_id": f.stem, "mtime": mtime})
    else:
        for app_dir in SESSIONS_DIR.iterdir():
            if not app_dir.is_dir():
                continue
            safe_app = app_dir.name
            for f in app_dir.glob("*.json"):
                if f.is_file():
                    try:
                        mtime = f.stat().st_mtime
                    except Exception:
                        mtime = 0.0
                    files.append({"path": f, "app_id": safe_app, "session_id": f.stem, "mtime": mtime})
    return files


def count_turns(messages: List[dict]) -> int:
    count = 0
    n = len(messages)
    for i, msg in enumerate(messages):
        if msg.get("role") == "user":
            for j in range(i + 1, n):
                if messages[j].get("role") == "assistant":
                    count += 1
                    break
    return count
