from typing import Any, Dict, List, Optional, Union

from pydantic import BaseModel

from ..storage.sessions import MAX_HISTORY_MESSAGES


class ChatHistoryItem(BaseModel):
    role: str
    content: Optional[Any] = None

    name: Optional[str] = None
    tool_call_id: Optional[str] = None
    tool_calls: Optional[List[Dict[str, Any]]] = None
    function_call: Optional[Dict[str, Any]] = None

    model_config = {"extra": "allow"}


class ChatRequest(BaseModel):
    user_prompt: Optional[str] = None
    model: str

    # NEW: which provider to route to
    hoster: Optional[str] = None

    system_prompt: Optional[str] = None
    system_notes: Optional[Union[str, List[str]]] = None
    session_id: Optional[str] = None
    app_id: Optional[str] = "default"
    include_history: Optional[bool] = True
    max_history: Optional[int] = MAX_HISTORY_MESSAGES

    history: Optional[List[ChatHistoryItem]] = None

    extra_body: Optional[Dict[str, Any]] = None

    tools: Optional[List[Dict[str, Any]]] = None
    tool_choice: Optional[Union[str, Dict[str, Any]]] = None


class SessionHistoryRequest(BaseModel):
    session_id: str
    app_id: Optional[str] = "default"


class StopRequest(BaseModel):
    request_id: str
