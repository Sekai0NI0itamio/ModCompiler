import asyncio
import json
import re
import traceback
import uuid
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List, Optional

from fastapi import APIRouter, HTTPException
from fastapi.responses import JSONResponse, StreamingResponse

from ..core.cancel import create_cancel_event, pop_cancel_event, set_cancel_event
from ..core.streaming import safe_stream_close, safe_aclose
from ..core.tool_calls import accumulate_tool_calls, chunk_choice0_delta_and_finish_reason, finalize_tool_calls
from ..core.utils import debug_print
from ..hosters.registry import DEFAULT_HOSTER, HosterRegistry
from ..storage.sessions import (
    append_messages_to_session,
    count_turns,
    list_session_files,
    load_session,
)
from .models import ChatRequest, SessionHistoryRequest, StopRequest
from .recent_requests import (
    get_most_recent_request as rr_get_most_recent,
    mark_recent_request_finished,
    record_new_request,
    update_recent_request_preview,
)

router = APIRouter()

THINKING_RE = re.compile(r"^Thinking\.{3}(?: \([0-9]+(?:\.[0-9]+)?s elapsed\))?$", re.IGNORECASE)

_hosters = HosterRegistry()


def _history_item_to_message(item: Any) -> Optional[dict]:
    try:
        if hasattr(item, "model_dump"):
            data = item.model_dump(exclude_none=True)
        elif hasattr(item, "dict"):
            data = item.dict(exclude_none=True)
        elif isinstance(item, dict):
            data = {k: v for k, v in item.items() if v is not None}
        else:
            return None

        role = data.get("role")
        if not role:
            return None

        msg: Dict[str, Any] = {"role": role}
        if "content" in data:
            msg["content"] = data.get("content")

        if data.get("name") is not None:
            msg["name"] = data.get("name")
        if data.get("tool_call_id") is not None:
            msg["tool_call_id"] = data.get("tool_call_id")
        if data.get("tool_calls") is not None:
            msg["tool_calls"] = data.get("tool_calls")
        if data.get("function_call") is not None:
            msg["function_call"] = data.get("function_call")

        for k, v in data.items():
            if k in msg:
                continue
            if k in ("role",):
                continue
            msg[k] = v

        from ..core.utils import drop_nones

        return drop_nones(msg)
    except Exception:
        return None


@router.post("/session/history")
async def get_session_history(request: SessionHistoryRequest):
    session_history = await load_session(request.app_id, request.session_id)
    if not session_history:
        raise HTTPException(status_code=404, detail="Session history not found.")
    return JSONResponse(content={"session_id": request.session_id, "messages": session_history})


@router.get("/session/history/latest")
async def get_latest_session_history(app_id: Optional[str] = None, include_full: Optional[bool] = False):
    files = list_session_files(app_id)
    if not files:
        if app_id:
            raise HTTPException(status_code=404, detail=f"No sessions found for app_id '{app_id}'.")
        raise HTTPException(status_code=404, detail="No sessions found.")

    latest = max(files, key=lambda x: x["mtime"])
    safe_app = latest["app_id"]
    session_id = latest["session_id"]
    mtime = latest["mtime"]

    messages = await load_session(safe_app, session_id)

    last_assistant = None
    last_user = None
    for idx in range(len(messages) - 1, -1, -1):
        role = messages[idx].get("role")
        if role == "assistant":
            last_assistant = messages[idx].get("content")
            for j in range(idx - 1, -1, -1):
                if messages[j].get("role") == "user":
                    last_user = messages[j].get("content")
                    break
            break

    if last_assistant is None:
        for idx in range(len(messages) - 1, -1, -1):
            if messages[idx].get("role") == "user":
                last_user = messages[idx].get("content")
                break

    result = {
        "session_id": session_id,
        "app_id": safe_app,
        "file_mtime_utc": datetime.fromtimestamp(mtime, timezone.utc).isoformat(),
        "last_user": last_user,
        "last_assistant": last_assistant,
    }
    if include_full:
        result["messages"] = messages

    return JSONResponse(content=result)


@router.get("/requests/most_recent")
async def get_most_recent_request():
    rec = await rr_get_most_recent()
    if not rec:
        raise HTTPException(status_code=404, detail="No in-memory requests recorded.")
    return JSONResponse(content=rec)


@router.post("/stop")
async def stop_stream(req: StopRequest):
    debug_print(f"[STOP] Received stop request for {req.request_id}")
    ok = await set_cancel_event(req.request_id)
    if ok:
        debug_print(f"[STOP] Successfully set cancel event for {req.request_id}")
        return JSONResponse({"status": "stopping", "request_id": req.request_id})
    debug_print(f"[STOP] Request ID {req.request_id} not found or already finished")
    raise HTTPException(status_code=404, detail="request_id not found or already finished")


@router.get("/api/conversations/recent")
async def get_recent_conversations(count: Optional[int] = 10, single: Optional[bool] = False):
    try:
        max_count = int(count) if count is not None else 10
    except Exception:
        raise HTTPException(status_code=400, detail="Invalid 'count' parameter")
    if max_count < 0:
        raise HTTPException(status_code=400, detail="'count' must be non-negative")

    files = list_session_files(None)
    if not files:
        return JSONResponse(content={"sessions": []})

    async def _process_file(fdict: dict):
        path: Path = fdict.get("path")
        app_id = fdict.get("app_id")
        session_id = fdict.get("session_id")
        messages = await load_session(app_id, session_id)
        msg_count = count_turns(messages)

        try:
            st = path.stat()
            created_ts = getattr(st, "st_ctime", None) or fdict.get("mtime", 0)
            last_ts = getattr(st, "st_mtime", None) or fdict.get("mtime", 0)
        except Exception:
            created_ts = fdict.get("mtime", 0)
            last_ts = fdict.get("mtime", 0)

        created_iso = datetime.fromtimestamp(created_ts, timezone.utc).isoformat()
        last_iso = datetime.fromtimestamp(last_ts, timezone.utc).isoformat()

        return {
            "sessionId": session_id,
            "createdAt": created_iso,
            "lastMessageAt": last_iso,
            "messageCount": msg_count,
            "_last_ts": last_ts,
        }

    results = await asyncio.gather(*[_process_file(f) for f in files])
    if single:
        results = [r for r in results if r.get("messageCount") == 1]

    results.sort(key=lambda r: r.get("_last_ts", 0), reverse=True)

    trimmed = []
    for r in results[:max_count]:
        trimmed.append(
            {
                "sessionId": r["sessionId"],
                "createdAt": r["createdAt"],
                "lastMessageAt": r["lastMessageAt"],
                "messageCount": r["messageCount"],
            }
        )

    return JSONResponse(content={"sessions": trimmed})


@router.post("/chat")
async def stream_chat(request: ChatRequest):
    debug_print(
        f"[REQUEST] Received chat request - Model: {request.model}, App: {request.app_id}, Session: {request.session_id}, Hoster: {request.hoster or DEFAULT_HOSTER}"
    )

    if not request.model or not request.model.strip():
        raise HTTPException(status_code=400, detail="Field 'model' must be provided and non-empty.")

    hoster_name = (request.hoster or "").strip().lower() or DEFAULT_HOSTER
    try:
        hoster = _hosters.get(hoster_name)
    except KeyError:
        raise HTTPException(status_code=400, detail=f"Unknown hoster '{hoster_name}'")

    await hoster.keyring.maybe_reset_if_new_beijing_day()

    usable_keys = await hoster.keyring.usable_keys_snapshot()
    if not usable_keys:
        raise HTTPException(status_code=500, detail=f"No usable {hoster_name} API keys configured.")

    app_id = request.app_id or "default"

    if request.session_id and isinstance(request.session_id, str) and request.session_id.strip():
        session_id = request.session_id.strip()
        created_new = False
    else:
        session_id = uuid.uuid4().hex
        created_new = True

    request_id = uuid.uuid4().hex

    session_history: List[dict] = []
    if request.include_history:
        session_history = await load_session(app_id, session_id)
        if request.max_history and isinstance(request.max_history, int):
            session_history = session_history[-request.max_history:]

    incoming_history_messages: List[dict] = []
    if request.history:
        for item in request.history:
            msg = _history_item_to_message(item)
            if msg:
                session_history.append(msg)
                incoming_history_messages.append(msg)

    if request.user_prompt:
        session_history.append({"role": "user", "content": request.user_prompt})

    async def generate():
        nonlocal usable_keys

        cancel_event = await create_cancel_event(request_id)
        await record_new_request(request_id, app_id, session_id, request.user_prompt)

        try:
            yield json.dumps(
                {
                    "status": "start",
                    "session_id": session_id,
                    "app_id": app_id,
                    "created_new": created_new,
                    "request_id": request_id,
                }
            ) + "\n"
            await asyncio.sleep(0)

            finished = False
            assistant_text_accum = ""
            assistant_tool_calls_final: List[Dict[str, Any]] = []
            finish_reason_final: Optional[str] = None
            last_error_message = None

            # For stress-based systems, use queue-based waiting
            # For rotational, iterate through usable keys
            if hoster.keyring.tag_system.value == "stress_based":
                # Stress-based: wait for available key, process sequentially
                while not cancel_event.is_set() and not finished:
                    # Wait for an available key (blocks until one is available)
                    key = await hoster.keyring.wait_for_available_key(timeout_seconds=30)
                    if key is None:
                        # Timeout or cancellation
                        break
                    
                    # Verify key is still usable (it should be, but double-check)
                    if not await hoster.keyring.is_usable(key):
                        continue
                    
                    retries = 0
                    while retries < hoster.keyring.max_retries_per_key:
                        if cancel_event.is_set():
                            break

                        assistant_text_accum = ""
                        assistant_tool_calls_final = []
                        finish_reason_final = None
                        tool_calls_accum: Dict[int, Dict[str, Any]] = {}

                        response = None
                        client = None
                        request_registered = False
                        try:
                            # Register this request for stress-based tracking (Nvidia)
                            await hoster.keyring.register_request(key)
                            request_registered = True

                            messages: List[dict] = []

                            if request.system_prompt and isinstance(request.system_prompt, str) and request.system_prompt.strip():
                                if (
                                    session_history
                                    and len(session_history) > 0
                                    and session_history[0].get("role") == "system"
                                    and session_history[0].get("content") == request.system_prompt
                                ):
                                    pass
                                else:
                                    messages.append({"role": "system", "content": request.system_prompt})

                            if request.system_notes:
                                if isinstance(request.system_notes, list):
                                    for note in request.system_notes:
                                        if isinstance(note, str) and note.strip():
                                            messages.append({"role": "system", "content": note})
                                elif isinstance(request.system_notes, str) and request.system_notes.strip():
                                    messages.append({"role": "system", "content": request.system_notes})

                            if session_history:
                                if (
                                    request.system_prompt
                                    and session_history
                                    and session_history[0].get("role") == "system"
                                    and session_history[0].get("content") != request.system_prompt
                                ):
                                    messages.extend(session_history[1:])
                                else:
                                    messages.extend(session_history)

                            stream = hoster.stream_chat_completions(
                                api_key=key,
                                model=request.model,
                                messages=messages,
                                extra_body=request.extra_body,
                                tools=request.tools,
                                tool_choice=request.tool_choice,
                            )

                            chunk_count = 0
                            async for chunk in stream:
                                if cancel_event.is_set():
                                    raise asyncio.CancelledError()

                                chunk_count += 1

                                delta, finish_reason = chunk_choice0_delta_and_finish_reason(chunk)
                                if finish_reason is not None:
                                    finish_reason_final = finish_reason

                                content = (getattr(delta, "content", None) if delta is not None else None) or (delta.get("content") if isinstance(delta, dict) else "") or ""
                                stripped = content.strip()
                                if stripped and THINKING_RE.fullmatch(stripped):
                                    continue

                                if content:
                                    assistant_text_accum += content
                                    await update_recent_request_preview(request_id, assistant_text_accum)
                                    yield json.dumps({"event": "content", "content": content}) + "\n"
                                    await asyncio.sleep(0)

                                tool_calls_delta = (getattr(delta, "tool_calls", None) if delta is not None else None) or (delta.get("tool_calls") if isinstance(delta, dict) else None)
                                if tool_calls_delta:
                                    current_tool_calls = accumulate_tool_calls(tool_calls_accum, tool_calls_delta)
                                    yield json.dumps(
                                        {
                                            "event": "tool_calls",
                                            "tool_calls": current_tool_calls,
                                            "request_id": request_id,
                                        }
                                    ) + "\n"
                                    await asyncio.sleep(0)

                            assistant_tool_calls_final = finalize_tool_calls(tool_calls_accum)

                            finished = True
                            
                            # Release the key for stress-based systems (before break)
                            if hoster.keyring.tag_system.value == "stress_based":
                                await hoster.keyring.release_key(key)
                            
                            break

                        except asyncio.CancelledError:
                            raise

                        except Exception as err:
                            err_text = str(err).lower()
                            last_error_message = str(err)
                            
                            # Print error message when request fails
                            print(f"[ERROR] Request failed for model '{request.model}' with key: {str(err)}", flush=True)

                            # More specific check for model-related errors
                            model_error_patterns = [
                                "model not found", "invalid model", "unknown model", 
                                "does not exist", "model not exist", "model unavailable",
                                "is not a valid model", "unrecognized model"
                            ]
                            is_model_error = any(pattern in err_text for pattern in model_error_patterns)
                            
                            if is_model_error:
                                print(f"[DEBUG] Model error detected: {is_model_error}", flush=True)
                                yield json.dumps(
                                    {"error": f"Model '{request.model}' appears invalid or not found: {str(err)}"}
                                ) + "\n"
                                yield json.dumps({"status": "end"}) + "\n"
                                await asyncio.sleep(0)
                                await mark_recent_request_finished(request_id, status="failed")
                                return

                            if "limit" in err_text or "quota" in err_text or "rate limit" in err_text:
                                is_rate_limit = ("rate limit" in err_text or "rate_limit" in err_text or 
                                               "quota" in err_text or 
                                               (err_text.count("limit") > 0 and "delimiter" not in err_text))
                                if is_rate_limit:
                                    print(f"[ERROR] Rate limit/quota exceeded - marking key as used up. Error: {str(err)}", flush=True)
                                    await hoster.keyring.mark_used_up(key)
                                break

                            if "unsupported parameter" in err_text or "unknown parameter" in err_text:
                                print(f"[ERROR] Unsupported/unknown parameter error: {str(err)}", flush=True)
                                retries = hoster.keyring.max_retries_per_key
                                break

                            retries += 1
                            if retries >= hoster.keyring.max_retries_per_key:
                                print(f"[ERROR] Max retries ({hoster.keyring.max_retries_per_key}) reached for key", flush=True)
                                break
                            await asyncio.sleep(0.5)
                            continue
                    
                    if finished:
                        break
            else:
                # Rotational: iterate through usable keys (original behavior)
                for key_idx, key in enumerate(usable_keys):
                    if cancel_event.is_set():
                        break

                    if not await hoster.keyring.is_usable(key):
                        continue

                    retries = 0

                    while retries < hoster.keyring.max_retries_per_key:
                        if cancel_event.is_set():
                            break

                        assistant_text_accum = ""
                        assistant_tool_calls_final = []
                        finish_reason_final = None
                        tool_calls_accum: Dict[int, Dict[str, Any]] = {}

                        response = None
                        client = None
                        request_registered = False
                        try:
                            # Register this request for stress-based tracking (Nvidia)
                            await hoster.keyring.register_request(key)
                            request_registered = True

                            messages: List[dict] = []

                            if request.system_prompt and isinstance(request.system_prompt, str) and request.system_prompt.strip():
                                if (
                                    session_history
                                    and len(session_history) > 0
                                    and session_history[0].get("role") == "system"
                                    and session_history[0].get("content") == request.system_prompt
                                ):
                                    pass
                                else:
                                    messages.append({"role": "system", "content": request.system_prompt})

                            if request.system_notes:
                                if isinstance(request.system_notes, list):
                                    for note in request.system_notes:
                                        if isinstance(note, str) and note.strip():
                                            messages.append({"role": "system", "content": note})
                                elif isinstance(request.system_notes, str) and request.system_notes.strip():
                                    messages.append({"role": "system", "content": request.system_notes})

                            if session_history:
                                if (
                                    request.system_prompt
                                    and session_history
                                    and session_history[0].get("role") == "system"
                                    and session_history[0].get("content") != request.system_prompt
                                ):
                                    messages.extend(session_history[1:])
                                else:
                                    messages.extend(session_history)

                            stream = hoster.stream_chat_completions(
                                api_key=key,
                                model=request.model,
                                messages=messages,
                                extra_body=request.extra_body,
                                tools=request.tools,
                                tool_choice=request.tool_choice,
                            )

                            chunk_count = 0
                            async for chunk in stream:
                                if cancel_event.is_set():
                                    raise asyncio.CancelledError()

                                chunk_count += 1

                                delta, finish_reason = chunk_choice0_delta_and_finish_reason(chunk)
                                if finish_reason is not None:
                                    finish_reason_final = finish_reason

                                content = (getattr(delta, "content", None) if delta is not None else None) or (delta.get("content") if isinstance(delta, dict) else "") or ""
                                stripped = content.strip()
                                if stripped and THINKING_RE.fullmatch(stripped):
                                    continue

                                if content:
                                    assistant_text_accum += content
                                    await update_recent_request_preview(request_id, assistant_text_accum)
                                    yield json.dumps({"event": "content", "content": content}) + "\n"
                                    await asyncio.sleep(0)

                                tool_calls_delta = (getattr(delta, "tool_calls", None) if delta is not None else None) or (delta.get("tool_calls") if isinstance(delta, dict) else None)
                                if tool_calls_delta:
                                    current_tool_calls = accumulate_tool_calls(tool_calls_accum, tool_calls_delta)
                                    yield json.dumps(
                                        {
                                            "event": "tool_calls",
                                            "tool_calls": current_tool_calls,
                                            "request_id": request_id,
                                        }
                                    ) + "\n"
                                    await asyncio.sleep(0)

                            assistant_tool_calls_final = finalize_tool_calls(tool_calls_accum)

                            finished = True
                            
                            # Release the key for stress-based systems (before break)
                            if hoster.keyring.tag_system.value == "stress_based":
                                await hoster.keyring.release_key(key)
                            
                            break

                        except asyncio.CancelledError:
                            raise

                        except Exception as err:
                            err_text = str(err).lower()
                            last_error_message = str(err)
                            
                            # Print error message when request fails
                            print(f"[ERROR] Request failed for model '{request.model}' with key index {key_idx}: {str(err)}", flush=True)

                            # More specific check for model-related errors
                            # Must match phrases like "model not found", "invalid model", etc.
                            # Don't just check for "model" substring (e.g., "free-models-per-day" has "model")
                            model_error_patterns = [
                                "model not found", "invalid model", "unknown model", 
                                "does not exist", "model not exist", "model unavailable",
                                "is not a valid model", "unrecognized model"
                            ]
                            is_model_error = any(pattern in err_text for pattern in model_error_patterns)
                            
                            if is_model_error:
                                print(f"[DEBUG] Model error detected: {is_model_error}", flush=True)
                                yield json.dumps(
                                    {"error": f"Model '{request.model}' appears invalid or not found: {str(err)}"}
                                ) + "\n"
                                yield json.dumps({"status": "end"}) + "\n"
                                await asyncio.sleep(0)
                                await mark_recent_request_finished(request_id, status="failed")
                                return

                            if "limit" in err_text or "quota" in err_text or "rate limit" in err_text:
                                # Auto-mark key as finished if error contains "limit" in any form
                                # Also make sure we're not matching "delimiter" as "limit"
                                is_rate_limit = ("rate limit" in err_text or "rate_limit" in err_text or 
                                               "quota" in err_text or 
                                               (err_text.count("limit") > 0 and "delimiter" not in err_text))
                                if is_rate_limit:
                                    print(f"[ERROR] Rate limit/quota exceeded - marking key as used up. Error: {str(err)}", flush=True)
                                    await hoster.keyring.mark_used_up(key)
                                    usable_keys = [k for k in usable_keys if await hoster.keyring.is_usable(k)]
                                break

                            if "unsupported parameter" in err_text or "unknown parameter" in err_text:
                                print(f"[ERROR] Unsupported/unknown parameter error: {str(err)}", flush=True)
                                retries = hoster.keyring.max_retries_per_key
                                break

                            retries += 1
                            if retries >= hoster.keyring.max_retries_per_key:
                                print(f"[ERROR] Max retries ({hoster.keyring.max_retries_per_key}) reached for key index {key_idx}", flush=True)
                                break
                            await asyncio.sleep(0.5)
                            continue

                    if finished:
                        break

            if cancel_event.is_set():
                finished = False

            if not finished:
                if cancel_event.is_set():
                    if request.include_history and assistant_text_accum and assistant_text_accum.strip():
                        try:
                            new_msgs: List[dict] = []
                            if incoming_history_messages:
                                new_msgs.extend(incoming_history_messages)
                            if request.user_prompt is not None:
                                new_msgs.append({"role": "user", "content": request.user_prompt})
                            new_msgs.append({"role": "assistant", "content": assistant_text_accum})
                            await append_messages_to_session(app_id, session_id, new_msgs, request.system_prompt)
                        except Exception:
                            pass

                    yield json.dumps({"status": "cancelled", "request_id": request_id}) + "\n"
                    await asyncio.sleep(0)
                    await mark_recent_request_finished(request_id, status="cancelled")
                else:
                    print(f"[ERROR] All keys failed or exhausted. Last error: {last_error_message}")
                    error_output = {"error": "All keys failed or were exhausted."}
                    if last_error_message:
                        error_output["last_error"] = last_error_message
                    yield json.dumps(error_output) + "\n"
                    await asyncio.sleep(0)
                    await mark_recent_request_finished(request_id, status="failed")
            else:
                if request.include_history:
                    try:
                        new_msgs: List[dict] = []

                        if incoming_history_messages:
                            new_msgs.extend(incoming_history_messages)

                        if request.user_prompt is not None:
                            new_msgs.append({"role": "user", "content": request.user_prompt})

                        assistant_msg: Dict[str, Any] = {"role": "assistant", "content": assistant_text_accum}
                        if assistant_tool_calls_final:
                            assistant_msg["tool_calls"] = assistant_tool_calls_final
                        new_msgs.append(assistant_msg)

                        await append_messages_to_session(app_id, session_id, new_msgs, request.system_prompt)

                    except Exception:
                        yield json.dumps({"warning": "Failed to persist session"}) + "\n"
                        await asyncio.sleep(0)

                await mark_recent_request_finished(request_id, status="finished")

            yield json.dumps(
                {
                    "status": "end",
                    "session_id": session_id,
                    "app_id": app_id,
                    "request_id": request_id,
                    "finish_reason": finish_reason_final,
                }
            ) + "\n"
            await asyncio.sleep(0)

        except Exception as e:
            debug_print(f"[REQUEST {request_id}] Unexpected error: {str(e)}")
            debug_print(f"[REQUEST {request_id}] Traceback: {traceback.format_exc()}")
            yield json.dumps({"error": f"Internal server error: {str(e)}", "request_id": request_id}) + "\n"

        finally:
            await pop_cancel_event(request_id)

    return StreamingResponse(generate(), media_type="application/x-ndjson")
