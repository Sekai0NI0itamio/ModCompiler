import asyncio
from datetime import datetime, timezone
from typing import List, Optional

from ..core.utils import sanitize_id

_recent_requests: List[dict] = []
_recent_requests_lock = asyncio.Lock()


async def record_new_request(request_id: str, app_id: str, session_id: str, user_prompt: Optional[str]):
    rec = {
        "request_id": request_id,
        "session_id": session_id,
        "app_id": sanitize_id(app_id or "default"),
        "start_time": datetime.now(timezone.utc).isoformat(),
        "user_prompt": user_prompt,
        "assistant_preview": "",
        "status": "running",
        "last_update_time": None,
        "finished_time": None,
    }
    async with _recent_requests_lock:
        _recent_requests.append(rec)


async def update_recent_request_preview(request_id: str, assistant_preview: str):
    async with _recent_requests_lock:
        for rec in reversed(_recent_requests):
            if rec["request_id"] == request_id:
                rec["assistant_preview"] = assistant_preview
                rec["last_update_time"] = datetime.now(timezone.utc).isoformat()
                break


async def mark_recent_request_finished(request_id: str, status: str = "finished"):
    async with _recent_requests_lock:
        for rec in reversed(_recent_requests):
            if rec["request_id"] == request_id:
                rec["status"] = status
                rec["finished_time"] = datetime.now(timezone.utc).isoformat()
                break


async def get_most_recent_request():
    async with _recent_requests_lock:
        if not _recent_requests:
            return None
        latest_rec = max(_recent_requests, key=lambda r: r.get("start_time") or "")
        return latest_rec
