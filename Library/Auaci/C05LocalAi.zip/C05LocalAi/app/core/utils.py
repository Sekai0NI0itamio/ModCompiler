import os
import re
import sys
from typing import Any, Dict, Optional

DEBUG_ENV_VAR = "C04POE_DEBUG"


def is_debug_mode() -> bool:
    return os.getenv(DEBUG_ENV_VAR, "").strip().lower() in {"1", "true", "yes", "on"}


def debug_print(*args, **kwargs) -> None:
    if is_debug_mode():
        kwargs.setdefault("file", sys.stderr)
        kwargs.setdefault("flush", True)
        print(*args, **kwargs)


def drop_nones(d: Dict[str, Any]) -> Dict[str, Any]:
    return {k: v for k, v in d.items() if v is not None}


def sanitize_id(x: str) -> str:
    return re.sub(r"[^A-Za-z0-9_\-]", "_", x)


def maybe_get(obj: Any, key: str, default=None):
    if obj is None:
        return default
    if isinstance(obj, dict):
        return obj.get(key, default)
    return getattr(obj, key, default)
