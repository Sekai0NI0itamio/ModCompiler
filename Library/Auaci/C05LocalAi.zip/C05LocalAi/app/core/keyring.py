import asyncio
from dataclasses import dataclass
from datetime import datetime, timedelta, timezone
from enum import Enum
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

from .utils import debug_print


class TagSystemType(Enum):
    """Tag system types for key management."""
    ROTATIONAL = "rotational"  # Poe, OpenRouter - simple key rotation
    STRESS_BASED = "stress_based"  # Nvidia - max N requests per time window


@dataclass
class StressBasedConfig:
    """Configuration for stress-based key management (e.g., Nvidia)."""
    max_requests_per_minute: int = 2
    time_window_seconds: int = 60


class KeyRing:
    hoster: str
    keys: List[str]
    max_retries_per_key: int = 3
    tag_system: TagSystemType = TagSystemType.ROTATIONAL
    
    # Stress-based configuration
    stress_config: Optional[StressBasedConfig] = None
    
    def __init__(self, hoster: str, keys: List[str]):
        self.hoster = hoster
        self.keys = keys
        self._lock = asyncio.Lock()
        self._original_key_order = list(self.keys)
        self._key_order = list(self.keys)
        self._key_status: Dict[str, bool] = {k: True for k in self.keys}
        
        # Stress-based tracking: {key: [timestamp1, timestamp2, ...]}
        self._key_request_times: Dict[str, List[datetime]] = {}
        
        # Track active requests (in progress) for stress-based systems
        self._active_requests: Dict[str, int] = {}
        
        self._last_reset_beijing_date: Optional[str] = None
        self._last_reset_lock = asyncio.Lock()
        
        # Queue for pending requests when all keys are at capacity
        self._pending_requests: asyncio.Queue = asyncio.Queue()
        
        # Initialize stress tracking for all keys
        if self.tag_system == TagSystemType.STRESS_BASED:
            for key in self.keys:
                self._key_request_times[key] = []
                self._active_requests[key] = 0
    
    def _get_key_info(self, key: str) -> Dict[str, Any]:
        """Get detailed info about a key's current status."""
        config = self.stress_config or StressBasedConfig()
        now = datetime.now(timezone.utc)
        window = timedelta(seconds=config.time_window_seconds)
        max_requests = config.max_requests_per_minute
        
        valid_times = [
            t for t in self._key_request_times.get(key, [])
            if now - t <= window
        ]
        completed = len(valid_times)
        active = self._active_requests.get(key, 0)
        capacity_left = max(0, max_requests - completed - active)
        
        return {
            "completed": completed,
            "active": active,
            "capacity_left": capacity_left,
            "max": max_requests,
            "available": capacity_left > 0,
            "status": self._key_status.get(key, False)
        }
    
    async def get_best_key(self) -> Optional[str]:
        """
        Get the best key based on tag system.
        For stress-based: returns the least stressed key (with most remaining capacity).
        """
        if not self._key_order:
            return None
        
        # Filter to only usable keys first
        usable_keys = []
        for key in self._key_order:
            info = self._get_key_info(key)
            if info["available"] and info["status"]:
                usable_keys.append((key, info))
        
        if not usable_keys:
            return None
        
        if self.tag_system == TagSystemType.STRESS_BASED:
            # Sort by capacity left (most available first)
            usable_keys.sort(key=lambda x: x[1]["capacity_left"], reverse=True)
            return usable_keys[0][0] if usable_keys else None
        else:
            # For rotational, just return first usable key
            return usable_keys[0][0] if usable_keys else None
    
    async def get_available_keys_info(self) -> List[Dict[str, Any]]:
        """Get info about all available keys."""
        results = []
        for key in self._key_order:
            info = self._get_key_info(key)
            info["key"] = key[:12] + "..." if len(key) > 12 else key
            results.append(info)
        return results
    
    async def wait_for_available_key(self, timeout_seconds: Optional[float] = None) -> Optional[str]:
        """
        Wait until a key becomes available for stress-based systems.
        Polls every second to check for available keys.
        
        Returns the key to use, or None if timeout or cancellation.
        """
        if self.tag_system != TagSystemType.STRESS_BASED:
            # For non-stress-based, just get best key directly
            return await self.get_best_key()
        
        config = self.stress_config or StressBasedConfig()
        start_time = datetime.now(timezone.utc)
        check_interval = 1.0  # Check every second
        checks = 0
        
        while True:
            checks += 1
            
            # Get all available keys info
            available_info = await self.get_available_keys_info()
            available_keys = [k for k in available_info if k["available"] and k["status"]]
            
            debug_print(f"[KEYRING:{self.hoster}] Check #{checks}: Found {len(available_keys)} available keys out of {len(available_info)} total")
            for info in available_info:
                status = "✓" if info["available"] else "✗"
                debug_print(f"[KEYRING:{self.hoster}]   Key {info['key']}: {status} (completed={info['completed']}, active={info['active']}, capacity_left={info['capacity_left']})")
            
            if available_keys:
                # Sort by capacity left to get least stressed
                available_keys.sort(key=lambda x: x["capacity_left"], reverse=True)
                best_key_info = available_keys[0]
                key = best_key_info["key"]
                
                # Find the full key from shortened version
                full_key = None
                for k in self._key_order:
                    if k.startswith(key[:12] if len(key) > 12 else key):
                        full_key = k
                        break
                
                if full_key:
                    debug_print(f"[KEYRING:{self.hoster}] Selected key {key} (capacity_left={best_key_info['capacity_left']})")
                    
                    # Mark this key as having an active request
                    async with self._lock:
                        self._active_requests[full_key] = self._active_requests.get(full_key, 0) + 1
                    
                    return full_key
            
            # No keys available - check timeout
            if timeout_seconds is not None:
                elapsed = (datetime.now(timezone.utc) - start_time).total_seconds()
                if elapsed >= timeout_seconds:
                    debug_print(f"[KEYRING:{self.hoster}] Timeout after {elapsed:.1f}s ({checks} checks) - no keys available")
                    return None
            
            # Wait before next check
            debug_print(f"[KEYRING:{self.hoster}] No keys available - waiting {check_interval}s before next check...")
            await asyncio.sleep(check_interval)
    
    async def register_request(self, key: str):
        """Register a request for a key (for stress-based tracking)."""
        if self.tag_system != TagSystemType.STRESS_BASED:
            return
        
        async with self._lock:
            if key not in self._key_request_times:
                self._key_request_times[key] = []
            
            # Get key info before registering
            info_before = self._get_key_info(key)
            
            self._key_request_times[key].append(datetime.now(timezone.utc))
            
            # Get key info after registering
            info_after = self._get_key_info(key)
            
            debug_print(f"[KEYRING:{self.hoster}] Registered request for key {key[:12]}... (completed: {info_before['completed']} → {info_after['completed']}, active: {info_after['active']})")
    
    async def release_key(self, key: str):
        """Release a key after request completes."""
        if self.tag_system != TagSystemType.STRESS_BASED:
            return
        
        async with self._lock:
            self._active_requests[key] = max(0, self._active_requests.get(key, 0) - 1)
        
        # Get key info after releasing
        info = self._get_key_info(key)
        debug_print(f"[KEYRING:{self.hoster}] Released key {key[:12]}... (active: {info['active']}, capacity_left: {info['capacity_left']})")
        
        # Check if there are pending requests that can now proceed
        if info["capacity_left"] > 0:
            debug_print(f"[KEYRING:{self.hoster}] Key {key[:12]}... now has capacity - pending requests can proceed")
    
    async def _process_pending_requests(self):
        """
        Process pending requests in queue when a key becomes available.
        Called when a request completes and releases a key slot.
        Polls every second to check for available keys.
        """
        if self._pending_requests.empty():
            return
        
        debug_print(f"[KEYRING:{self.hoster}] Processing pending requests (queue size: {self._pending_requests.qsize()})")
        
        # Continuously check for available keys and assign them
        while not self._pending_requests.empty():
            # Find keys with available capacity
            async with self._lock:
                available_keys = []
                for key in self._key_order:
                    if not self._key_status.get(key, False):
                        continue
                    info = self._get_key_info(key)
                    if info["available"]:
                        available_keys.append((key, info["capacity_left"]))
                
                if not available_keys:
                    debug_print(f"[KEYRING:{self.hoster}] No keys currently available for pending requests")
                    break
                
                # Sort by capacity left (least stressed first)
                available_keys.sort(key=lambda x: x[1], reverse=True)
                
                # Assign first available key to next pending request
                try:
                    queue_entry = self._pending_requests.get_nowait()
                    if queue_entry["cancelled"]:
                        continue
                    
                    key = available_keys[0][0]
                    capacity = available_keys[0][1]
                    
                    queue_entry["key"] = key
                    queue_entry["event"].set()
                    
                    debug_print(f"[KEYRING:{self.hoster}] Assigned key {key[:12]}... to pending request (capacity_left: {capacity})")
                    
                except asyncio.QueueEmpty:
                    break
    
    def _beijing_now(self) -> datetime:
        return datetime.now(timezone.utc).astimezone(timezone(timedelta(hours=8)))

    async def maybe_reset_if_new_beijing_day(self):
        async with self._last_reset_lock:
            now_bj = self._beijing_now()
            bj_date_str = now_bj.strftime("%Y-%m-%d")
            if self._last_reset_beijing_date == bj_date_str:
                return
            if now_bj.hour < 8:
                return

            async with self._lock:
                self._key_order = list(self._original_key_order)
                self._key_status = {k: True for k in self._key_order}
                
                # Reset stress-based tracking
                if self.tag_system == TagSystemType.STRESS_BASED:
                    for key in self.keys:
                        self._key_request_times[key] = []
                        self._active_requests[key] = 0

            self._last_reset_beijing_date = bj_date_str
            debug_print(f"[KEYRING:{self.hoster}] Reset key order at {now_bj.isoformat()} (Beijing time)")

    async def mark_used_up(self, key: str):
        async with self._lock:
            if key in self._key_status:
                self._key_status[key] = False
                debug_print(f"[KEYRING:{self.hoster}] Marked key as used up: {key[:8]}...")

    async def mark_available(self, key: str):
        async with self._lock:
            if key in self._key_status:
                self._key_status[key] = True
                debug_print(f"[KEYRING:{self.hoster}] Marked key as available: {key[:8]}...")

    async def usable_keys_snapshot(self) -> List[str]:
        async with self._lock:
            if self.tag_system == TagSystemType.STRESS_BASED:
                # For stress-based, filter by both status, rate limits, and active requests
                usable = []
                now = datetime.now(timezone.utc)
                config = self.stress_config or StressBasedConfig()
                window = timedelta(seconds=config.time_window_seconds)
                max_requests = config.max_requests_per_minute
                
                for key in self._key_order:
                    if not self._key_status.get(key, False):
                        continue
                    
                    # Get valid timestamps within the time window
                    valid_times = [
                        t for t in self._key_request_times.get(key, [])
                        if now - t <= window
                    ]
                    completed = len(valid_times)
                    active = self._active_requests.get(key, 0)
                    
                    # Key is usable if we haven't exceeded capacity
                    if (completed + active) < max_requests:
                        usable.append(key)
                
                debug_print(f"[KEYRING:{self.hoster}] Found {len(usable)} usable keys (stress-based) out of {len(self._key_order)}")
                return usable
            else:
                # Rotational - just check status
                usable = [k for k in self._key_order if self._key_status.get(k, False)]
                debug_print(f"[KEYRING:{self.hoster}] Found {len(usable)} usable keys (rotational) out of {len(self._key_order)}")
                return usable

    async def is_usable(self, key: str) -> bool:
        async with self._lock:
            if not self._key_status.get(key, False):
                return False
            
            if self.tag_system == TagSystemType.STRESS_BASED:
                # Check rate limits considering active requests
                config = self.stress_config or StressBasedConfig()
                now = datetime.now(timezone.utc)
                window = timedelta(seconds=config.time_window_seconds)
                max_requests = config.max_requests_per_minute
                
                # Count completed requests in window
                valid_times = [
                    t for t in self._key_request_times.get(key, [])
                    if now - t <= window
                ]
                completed = len(valid_times)
                active = self._active_requests.get(key, 0)
                
                # Key is usable if we haven't exceeded capacity
                return (completed + active) < max_requests
            
            return True

    async def get_key_stats(self, key: str) -> Dict[str, Any]:
        """Get statistics for a key (useful for debugging)."""
        async with self._lock:
            config = self.stress_config or StressBasedConfig()
            now = datetime.now(timezone.utc)
            window = timedelta(seconds=config.time_window_requests_per_minute)
            max_requests = config.max_requests_per_minute
            
            valid_times = [
                t for t in self._key_request_times.get(key, [])
                if now - t <= window
            ]
            
            # Calculate when the key will have space available
            wait_time = 0
            if len(valid_times) >= max_requests and valid_times:
                oldest_in_window = min(valid_times)
                wait_time = max(0, int((oldest_in_window + window - now).total_seconds()))
            
            return {
                "key_available": await self.is_usable(key),
                "current_requests": len(valid_times),
                "max_requests": max_requests,
                "wait_time_seconds": wait_time,
                "is_marked_used_up": not self._key_status.get(key, False)
            }

    async def register_request(self, key: str):
        """Register a request for a key (for stress-based tracking)."""
        if self.tag_system != TagSystemType.STRESS_BASED:
            return
        
        async with self._lock:
            if key not in self._key_request_times:
                self._key_request_times[key] = []
            self._key_request_times[key].append(datetime.now(timezone.utc))
            debug_print(f"[KEYRING:{self.hoster}] Registered request for key {key[:8]}... ({len(self._key_request_times[key])} requests in window)")
        
        # Process pending requests after registering (outside lock to avoid deadlock)
        await self._process_pending_requests()

    async def cleanup_expired_tags(self):
        """Remove expired request timestamps from all keys."""
        if self.tag_system != TagSystemType.STRESS_BASED:
            return
        
        async with self._lock:
            config = self.stress_config or StressBasedConfig()
            now = datetime.now(timezone.utc)
            window = timedelta(seconds=config.time_window_seconds)
            
            cleaned = 0
            for key in self._key_request_times:
                before = len(self._key_request_times[key])
                self._key_request_times[key] = [
                    t for t in self._key_request_times[key]
                    if now - t <= window
                ]
                cleaned += before - len(self._key_request_times[key])
            
            if cleaned > 0:
                debug_print(f"[KEYRING:{self.hoster}] Cleaned up {cleaned} expired request tags")

    async def get_best_key(self) -> Optional[str]:
        """
        Get the best key based on the tag system.
        For rotational: returns the first usable key in order
        For stress-based: returns the key with the fewest requests in the current window
        """
        async with self._lock:
            if self.tag_system == TagSystemType.STRESS_BASED:
                usable = await self.usable_keys_snapshot()
                if not usable:
                    return None
                
                # Get key with fewest requests
                now = datetime.now(timezone.utc)
                config = self.stress_config or StressBasedConfig()
                window = timedelta(seconds=config.time_window_seconds)
                
                best_key = None
                min_requests = float('inf')
                
                for key in usable:
                    valid_times = [
                        t for t in self._key_request_times.get(key, [])
                        if now - t <= window
                    ]
                    if len(valid_times) < min_requests:
                        min_requests = len(valid_times)
                        best_key = key
                
                return best_key
            else:
                # Rotational - return first usable
                for key in self._key_order:
                    if await self.is_usable(key):
                        return key
                return None

    def set_stress_config(self, max_requests_per_minute: int, time_window_seconds: int = 60):
        """Configure stress-based key management."""
        # Check if already configured with the same values
        if (self.tag_system == TagSystemType.STRESS_BASED and 
            self.stress_config and 
            self.stress_config.max_requests_per_minute == max_requests_per_minute and
            self.stress_config.time_window_seconds == time_window_seconds):
            return  # Already configured with same values
        
        self.tag_system = TagSystemType.STRESS_BASED
        self.stress_config = StressBasedConfig(
            max_requests_per_minute=max_requests_per_minute,
            time_window_seconds=time_window_seconds
        )
        # Initialize tracking for all keys
        for key in self.keys:
            if key not in self._key_request_times:
                self._key_request_times[key] = []
        debug_print(f"[KEYRING:{self.hoster}] Configured stress-based system: {max_requests_per_minute} requests per {time_window_seconds}s")


def load_keys_from_txt(path: Path) -> List[str]:
    if not path.exists():
        return []
    lines = path.read_text(encoding="utf-8").splitlines()
    keys: List[str] = []
    for ln in lines:
        s = ln.strip()
        if not s or s.startswith("#"):
            continue
        keys.append(s)
    return keys
