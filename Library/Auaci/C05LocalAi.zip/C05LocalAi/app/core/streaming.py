import asyncio
from typing import Any, Awaitable

from openai import AsyncOpenAI


async def safe_aclose(client: AsyncOpenAI):
    """Close AsyncOpenAI client safely."""
    try:
        aclose = getattr(client, "aclose", None)
        if callable(aclose):
            res = aclose()
            if asyncio.iscoroutine(res) or isinstance(res, Awaitable):
                await res
            return
        close_fn = getattr(client, "close", None)
        if callable(close_fn):
            res = close_fn()
            if asyncio.iscoroutine(res) or isinstance(res, Awaitable):
                await res
    except Exception:
        pass


async def safe_stream_close(stream_obj: Any):
    """Attempt to close a streaming response gracefully if it supports aclose()/close()."""
    if stream_obj is None:
        return
    try:
        aclose = getattr(stream_obj, "aclose", None)
        if callable(aclose):
            r = aclose()
            if asyncio.iscoroutine(r) or isinstance(r, Awaitable):
                await r
            return
        close_fn = getattr(stream_obj, "close", None)
        if callable(close_fn):
            r = close_fn()
            if asyncio.iscoroutine(r) or isinstance(r, Awaitable):
                await r
    except Exception:
        pass
