import asyncio

_cancel_events: dict[str, asyncio.Event] = {}
_cancel_events_lock = asyncio.Lock()


async def create_cancel_event(request_id: str) -> asyncio.Event:
    ev = asyncio.Event()
    async with _cancel_events_lock:
        _cancel_events[request_id] = ev
    return ev


async def pop_cancel_event(request_id: str) -> None:
    async with _cancel_events_lock:
        _cancel_events.pop(request_id, None)


async def set_cancel_event(request_id: str) -> bool:
    async with _cancel_events_lock:
        ev = _cancel_events.get(request_id)
    if ev is None:
        return False
    ev.set()
    return True
