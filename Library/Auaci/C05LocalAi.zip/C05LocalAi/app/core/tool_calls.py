from typing import Any, Dict, List, Optional, Tuple

from .utils import maybe_get


def chunk_choice0_delta_and_finish_reason(chunk: Any) -> Tuple[Any, Optional[str]]:
    """Returns: (delta_obj_or_dict, finish_reason_or_None)."""
    try:
        choices = maybe_get(chunk, "choices", None)
        if choices and len(choices) > 0:
            choice0 = choices[0]
            delta = maybe_get(choice0, "delta", None)
            finish_reason = maybe_get(choice0, "finish_reason", None)
            return delta, finish_reason
    except Exception:
        pass

    if isinstance(chunk, dict):
        choices = chunk.get("choices") or []
        if choices:
            choice0 = choices[0] if isinstance(choices[0], dict) else {}
            delta = choice0.get("delta")
            finish_reason = choice0.get("finish_reason")
            return delta, finish_reason

    return None, None


def finalize_tool_calls(tool_calls_accum: Dict[int, Dict[str, Any]]) -> List[Dict[str, Any]]:
    if not tool_calls_accum:
        return []
    out: List[Dict[str, Any]] = []
    for idx in sorted(tool_calls_accum.keys()):
        entry = tool_calls_accum[idx]
        if not entry.get("type"):
            entry["type"] = "function"
        fn = entry.get("function") or {}
        if fn.get("arguments") is None:
            fn["arguments"] = ""
        entry["function"] = fn
        out.append(entry)
    return out


def accumulate_tool_calls(tool_calls_accum: Dict[int, Dict[str, Any]], tool_calls_delta: Any) -> List[Dict[str, Any]]:
    """Accumulate streaming tool call deltas into OpenAI-style tool_calls entries."""
    if not tool_calls_delta:
        return []

    for tc in tool_calls_delta:
        idx = maybe_get(tc, "index", 0)
        try:
            idx = int(idx)
        except Exception:
            idx = 0

        entry = tool_calls_accum.get(idx)
        if entry is None:
            entry = {
                "id": None,
                "type": None,
                "function": {"name": None, "arguments": ""},
            }
            tool_calls_accum[idx] = entry

        tc_id = maybe_get(tc, "id", None)
        if tc_id:
            entry["id"] = tc_id

        tc_type = maybe_get(tc, "type", None)
        if tc_type:
            entry["type"] = tc_type

        fn = maybe_get(tc, "function", None)
        if fn:
            fn_name = maybe_get(fn, "name", None)
            if fn_name:
                entry["function"]["name"] = fn_name
            fn_args_piece = maybe_get(fn, "arguments", None)
            if fn_args_piece:
                entry["function"]["arguments"] += str(fn_args_piece)

    return finalize_tool_calls(tool_calls_accum)
