#!/usr/bin/env python3
"""Backwards-compatible entrypoint.

This project was refactored into the `app/` package.
Run this file to start the server (same as before).

New feature: multi-hoster support.
- Default hoster: poe
- Specify hoster in POST /chat JSON body: {"hoster": "openrouter", ...}

API keys are now loaded from:
- keys/poe.txt
- keys/openrouter.txt
(one key per line)
"""

from app.main import main


if __name__ == "__main__":
    main()
