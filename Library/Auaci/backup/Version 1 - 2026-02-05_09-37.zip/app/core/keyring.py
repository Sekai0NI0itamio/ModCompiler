import asyncio
from dataclasses import dataclass
from datetime import datetime, timedelta, timezone
from enum import Enum
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

from .utils import debug_print


class TagSystemType(Enum):
    """Tag system types for key management."""
    ROTATIONAL = "rotational"  # Poe, OpenRouter - simple key rotation
    STRESS_BASED = "stress_based"  # Nvidia - max N requests per time window


@dataclass
class StressBasedConfig:
    """Configuration for stress-based key management (e.g., Nvidia)."""
    max_requests_per_minute: int = 2
    time_window_seconds: int = 60


# Path to the used-up keys file (same directory as main.py/project root)
DEFAULT_USED_UP_FILE = Path("KeysUsedUp.txt")

# Refresh hour in Beijing time (8 AM)
REFRESH_HOUR_BEIJING = 8


def _beijing_now() -> datetime:
    """Get current time in Beijing timezone (UTC+8)."""
    return datetime.now(timezone.utc).astimezone(timezone(timedelta(hours=8)))


def _get_next_refresh_time_bj() -> datetime:
    """
    Calculate the next 8 AM Beijing time from now.
    If current time is before 8 AM today, returns today at 8 AM.
    If current time is at or after 8 AM today, returns tomorrow at 8 AM.
    """
    now_bj = _beijing_now()
    today_8am = now_bj.replace(hour=REFRESH_HOUR_BEIJING, minute=0, second=0, microsecond=0)
    
    if now_bj < today_8am:
        return today_8am
    else:
        return (today_8am + timedelta(days=1))


def _format_datetime_bj(dt: datetime) -> str:
    """Format datetime in Beijing time as string."""
    # Convert to Beijing timezone if not already
    if dt.tzinfo is None:
        dt = dt.replace(tzinfo=timezone.utc)
    bj_dt = dt.astimezone(timezone(timedelta(hours=8)))
    return bj_dt.strftime("%Y-%m-%d %H:%M:%S")


def reset_used_up_file(file_path: Optional[Path] = None) -> None:
    """
    Reset the KeysUsedUp.txt file by deleting it (if exists) or creating empty.
    Called when --reset flag is used.
    """
    if file_path is None:
        file_path = DEFAULT_USED_UP_FILE
    
    if file_path.exists():
        file_path.unlink()
        debug_print(f"[KEYRING] Deleted KeysUsedUp.txt for reset")
    # Create fresh file with headers
    _initialize_used_up_file(file_path)


def _initialize_used_up_file(file_path: Optional[Path] = None) -> None:
    """
    Initialize the KeysUsedUp.txt file with header comments.
    Creates the file if it doesn't exist.
    """
    if file_path is None:
        file_path = DEFAULT_USED_UP_FILE
    
    now_bj = _beijing_now()
    next_refresh = _get_next_refresh_time_bj()
    
    header = f"""# Key Usage Tracker
# Created: {_format_datetime_bj(now_bj)} (Beijing Time)
# Next refresh: {_format_datetime_bj(next_refresh)} (Beijing Time)
# Format: hoster:key (one per line, lines starting with # are comments)
"""
    
    try:
        if not file_path.exists():
            file_path.write_text(header, encoding="utf-8")
            debug_print(f"[KEYRING] Created new KeysUsedUp.txt file")
    except Exception as e:
        debug_print(f"[KEYRING] Warning: Could not create KeysUsedUp.txt: {e}")


def _parse_used_up_file(file_path: Path) -> Tuple[Optional[datetime], List[Tuple[str, str]]]:
    """
    Parse the KeysUsedUp.txt file.
    Returns (next_refresh_datetime, list of (hoster, key) tuples).
    Skips comment lines and empty lines.
    If file doesn't exist, returns (None, []).
    """
    if not file_path.exists():
        return None, []
    
    try:
        content = file_path.read_text(encoding="utf-8")
        lines = content.splitlines()
        
        next_refresh = None
        entries = []
        
        for line in lines:
            line = line.strip()
            
            # Skip empty lines and comments
            if not line or line.startswith("#"):
                continue
            
            # Parse hoster:key format
            if ":" in line:
                parts = line.split(":", 1)
                if len(parts) == 2:
                    hoster = parts[0].strip().lower()
                    key = parts[1].strip()
                    if hoster and key:
                        entries.append((hoster, key))
            
            # Look for next refresh time in comments
            if "next refresh" in line.lower() and ":" in line:
                # Try to parse the datetime
                try:
                    # Format: # Next refresh: YYYY-MM-DD HH:MM:SS (Beijing Time)
                    date_str = line.split(": ", 1)[-1].split(" (")[0]
                    next_refresh = datetime.strptime(date_str, "%Y-%m-%d %H:%M:%S")
                    # Make it timezone aware (Beijing)
                    next_refresh = next_refresh.replace(tzinfo=timezone(timedelta(hours=8)))
                except (ValueError, IndexError):
                    pass
        
        return next_refresh, entries
    
    except Exception as e:
        debug_print(f"[KEYRING] Warning: Could not parse KeysUsedUp.txt: {e}")
        return None, []


class KeyRing:
    hoster: str
    keys: List[str]
    max_retries_per_key: int = 3
    tag_system: TagSystemType = TagSystemType.ROTATIONAL
    
    # Stress-based configuration
    stress_config: Optional[StressBasedConfig] = None
    
    def __init__(self, hoster: str, keys: List[str], used_up_file: Optional[Path] = None):
        self.hoster = hoster
        self.keys = keys
        self.used_up_file = used_up_file or DEFAULT_USED_UP_FILE
        self._lock = asyncio.Lock()
        self._original_key_order = list(self.keys)
        self._key_order = list(self.keys)
        self._key_status: Dict[str, bool] = {k: True for k in self.keys}
        
        # Stress-based tracking: {key: [timestamp1, timestamp2, ...]}
        self._key_request_times: Dict[str, List[datetime]] = {}
        
        # Track active requests (in progress) for stress-based systems
        self._active_requests: Dict[str, int] = {}
        
        self._last_reset_beijing_date: Optional[str] = None
        self._last_reset_lock = asyncio.Lock()
        
        # Queue for pending requests when all keys are at capacity
        self._pending_requests: asyncio.Queue = asyncio.Queue()
        
        # Track if we've loaded used-up keys from file for this session
        self._used_up_loaded: bool = False
        self._last_file_check: Optional[datetime] = None
        
        # Initialize stress tracking for all keys
        if self.tag_system == TagSystemType.STRESS_BASED:
            for key in self.keys:
                self._key_request_times[key] = []
                self._active_requests[key] = 0
    
    def _get_key_info(self, key: str) -> Dict[str, Any]:
        """Get detailed info about a key's current status."""
        config = self.stress_config or StressBasedConfig()
        now = datetime.now(timezone.utc)
        window = timedelta(seconds=config.time_window_seconds)
        max_requests = config.max_requests_per_minute
        
        valid_times = [
            t for t in self._key_request_times.get(key, [])
            if now - t <= window
        ]
        completed = len(valid_times)
        active = self._active_requests.get(key, 0)
        capacity_left = max(0, max_requests - completed - active)
        
        return {
            "completed": completed,
            "active": active,
            "capacity_left": capacity_left,
            "max": max_requests,
            "available": capacity_left > 0,
            "status": self._key_status.get(key, False)
        }
    
    async def get_best_key(self) -> Optional[str]:
        """
        Get the best key based on tag system.
        For stress-based: returns the least stressed key (with most remaining capacity).
        """
        if not self._key_order:
            return None
        
        # Filter to only usable keys first
        usable_keys = []
        for key in self._key_order:
            info = self._get_key_info(key)
            if info["available"] and info["status"]:
                usable_keys.append((key, info))
        
        if not usable_keys:
            return None
        
        # For stress-based, pick the key with most capacity left
        if self.tag_system == TagSystemType.STRESS_BASED:
            usable_keys.sort(key=lambda x: x[1]["capacity_left"], reverse=True)
            return usable_keys[0][0] if usable_keys else None
        else:
            # For rotational, just return first usable
            for key, _ in usable_keys:
                return key
            return None
    
    async def _load_used_up_keys_from_file(self) -> None:
        """Load used-up keys from the KeysUsedUp.txt file and mark them as unavailable."""
        if not self.used_up_file.exists():
            return
        
        async with self._lock:
            _, entries = _parse_used_up_file(self.used_up_file)
            
            loaded_count = 0
            for entry_hoster, key in entries:
                # Only process entries for this hoster
                if entry_hoster != self.hoster.lower():
                    continue
                
                # Only mark as used-up if the key exists in our current keys list
                if key in self._key_status:
                    self._key_status[key] = False
                    loaded_count += 1
            
            if loaded_count > 0:
                debug_print(f"[KEYRING:{self.hoster}] Loaded {loaded_count} used-up keys from file")
    
    async def _check_and_refresh_file(self) -> bool:
        """
        Check if the used-up file needs to be refreshed (8 AM Beijing time).
        If refresh time has passed, clears the file and resets all keys.
        Returns True if a refresh occurred, False otherwise.
        """
        if not self.used_up_file.exists():
            # Initialize file if it doesn't exist
            _initialize_used_up_file(self.used_up_file)
            return False
        
        try:
            next_refresh, _ = _parse_used_up_file(self.used_up_file)
            
            # If no next_refresh found, default to checking against current time
            if next_refresh is None:
                next_refresh = _get_next_refresh_time_bj()
            
            now_bj = _beijing_now()
            
            if now_bj >= next_refresh:
                # Time to refresh!
                async with self._lock:
                    # Clear the file and reinitialize with new timestamps
                    _initialize_used_up_file(self.used_up_file)
                    
                    # Reset all keys to available
                    for key in self._key_status:
                        self._key_status[key] = True
                    
                    # Reset stress-based tracking if applicable
                    if self.tag_system == TagSystemType.STRESS_BASED:
                        for key in self.keys:
                            self._key_request_times[key] = []
                            self._active_requests[key] = 0
                
                debug_print(f"[KEYRING:{self.hoster}] Refreshed keys at {_format_datetime_bj(now_bj)} (Beijing time)")
                return True
            
        except Exception as e:
            debug_print(f"[KEYRING:{self.hoster}] Error checking/refresh file: {e}")
        
        return False
    
    async def check_and_refresh_used_up_file(self) -> None:
        """
        Main method to check and potentially refresh the used-up file.
        Should be called at the start of each request.
        Loads persisted keys if not loaded yet, then checks if refresh is needed.
        """
        now = datetime.now(timezone.utc)
        
        # First time: load persisted used-up keys
        if not self._used_up_loaded:
            await self._load_used_up_keys_from_file()
            self._used_up_loaded = True
            self._last_file_check = now
        
        # Check if we need to refresh (throttle to once per minute max)
        if self._last_file_check is None or (now - self._last_file_check) >= timedelta(minutes=1):
            await self._check_and_refresh_file()
            self._last_file_check = now
    
    async def _append_used_up_to_file(self, key: str) -> None:
        """Append a used-up key to the file."""
        if not self.used_up_file:
            return
        
        try:
            # Ensure file exists
            if not self.used_up_file.exists():
                _initialize_used_up_file(self.used_up_file)
            
            # Append the key entry
            entry = f"{self.hoster}:{key}\n"
            
            # Atomic write: write to temp file then rename
            temp_path = self.used_up_file.with_suffix(".tmp")
            current_content = self.used_up_file.read_text(encoding="utf-8")
            temp_path.write_text(current_content + entry, encoding="utf-8")
            temp_path.replace(self.used_up_file)
            
            debug_print(f"[KEYRING:{self.hoster}] Persisted used-up key to file: {key[:12]}...")
        
        except Exception as e:
            debug_print(f"[KEYRING:{self.hoster}] Warning: Could not persist used-up key: {e}")
    
    async def register_request(self, key: str):
        """Register a request for a key (for stress-based tracking)."""
        if self.tag_system != TagSystemType.STRESS_BASED:
            return
        
        async with self._lock:
            if key not in self._key_request_times:
                self._key_request_times[key] = []
            
            # Get key info before registering
            info_before = self._get_key_info(key)
            
            self._key_request_times[key].append(datetime.now(timezone.utc))
            
            # Get key info after registering
            info_after = self._get_key_info(key)
            
            debug_print(f"[KEYRING:{self.hoster}] Registered request for key {key[:12]}... (completed: {info_before['completed']} → {info_after['completed']}, active: {info_after['active']})")
    
    async def release_key(self, key: str):
        """Release a key after request completes."""
        if self.tag_system != TagSystemType.STRESS_BASED:
            return
        
        async with self._lock:
            self._active_requests[key] = max(0, self._active_requests.get(key, 0) - 1)
        
        # Get key after releasing
        info = self._get_key_info(key)
        debug_print(f"[KEYRING:{self.hoster}] Released key {key[:12]}... (active: {info['active']}, capacity_left: {info['capacity_left']})")
        
        # Check if there are pending requests that can now proceed
        if info["capacity_left"] > 0:
            debug_print(f"[KEYRING:{self.hoster}] Key {key[:12]}... now has capacity - pending requests can proceed")
    
    async def _process_pending_requests(self):
        """
        Process pending requests in queue when a key becomes available.
        Called when a request completes and releases a key slot.
        Polls every second to check for available keys.
        """
        if self._pending_requests.empty():
            return
        
        debug_print(f"[KEYRING:{self.hoster}] Processing pending requests (queue size: {self._pending_requests.qsize()})")
        
        # Continuously check for available keys and assign them
        while not self._pending_requests.empty():
            # Find keys with available capacity
            async with self._lock:
                available_keys = []
                for key in self._key_order:
                    if not self._key_status.get(key, False):
                        continue
                    info = self._get_key_info(key)
                    if info["available"]:
                        available_keys.append((key, info["capacity_left"]))
                
                if not available_keys:
                    debug_print(f"[KEYRING:{self.hoster}] No keys currently available for pending requests")
                    break
                
                # Sort by capacity left (least stressed first)
                available_keys.sort(key=lambda x: x[1], reverse=True)
                
                # Assign first available key to next pending request
                try:
                    queue_entry = self._pending_requests.get_nowait()
                    if queue_entry["cancelled"]:
                        continue
                    
                    key = available_keys[0][0]
                    capacity = available_keys[0][1]
                    
                    queue_entry["key"] = key
                    queue_entry["event"].set()
                    
                    debug_print(f"[KEYRING:{self.hoster}] Assigned key {key[:12]}... to pending request (capacity_left: {capacity})")
                    
                except asyncio.QueueEmpty:
                    break
    
    async def maybe_reset_if_new_beijing_day(self):
        """Legacy method - kept for compatibility. Now handled by check_and_refresh_used_up_file."""
        # This method is now a no-op as the functionality is handled by check_and_refresh_used_up_file
        pass

    async def mark_used_up(self, key: str):
        """Mark a key as used up - persists to file and updates in-memory state."""
        async with self._lock:
            if key in self._key_status:
                self._key_status[key] = False
                debug_print(f"[KEYRING:{self.hoster}] Marked key as used up: {key[:8]}...")
        
        # Persist to file outside the lock to avoid blocking
        await self._append_used_up_to_file(key)

    async def mark_available(self, key: str):
        """Mark a key as available - updates in-memory state only (file is not modified)."""
        async with self._lock:
            if key in self._key_status:
                self._key_status[key] = True
                debug_print(f"[KEYRING:{self.hoster}] Marked key as available: {key[:8]}...")

    async def usable_keys_snapshot(self) -> List[str]:
        async with self._lock:
            if self.tag_system == TagSystemType.STRESS_BASED:
                # For stress-based, filter by both status, rate limits, and active requests
                usable = []
                now = datetime.now(timezone.utc)
                config = self.stress_config or StressBasedConfig()
                window = timedelta(seconds=config.time_window_seconds)
                max_requests = config.max_requests_per_minute
                
                for key in self._key_order:
                    if not self._key_status.get(key, False):
                        continue
                    
                    # Get valid timestamps within the time window
                    valid_times = [
                        t for t in self._key_request_times.get(key, [])
                        if now - t <= window
                    ]
                    completed = len(valid_times)
                    active = self._active_requests.get(key, 0)
                    
                    # Key is usable if we haven't exceeded capacity
                    if (completed + active) < max_requests:
                        usable.append(key)
                
                debug_print(f"[KEYRING:{self.hoster}] Found {len(usable)} usable keys (stress-based) out of {len(self._key_order)}")
                return usable
            else:
                # Rotational - just check status
                usable = [k for k in self._key_order if self._key_status.get(k, False)]
                debug_print(f"[KEYRING:{self.hoster}] Found {len(usable)} usable keys (rotational) out of {len(self._key_order)}")
                return usable

    async def is_usable(self, key: str) -> bool:
        async with self._lock:
            if not self._key_status.get(key, False):
                return False
            
            if self.tag_system == TagSystemType.STRESS_BASED:
                # Check rate limits considering active requests
                config = self.stress_config or StressBasedConfig()
                now = datetime.now(timezone.utc)
                window = timedelta(seconds=config.time_window_seconds)
                max_requests = config.max_requests_per_minute
                
                # Count completed requests in window
                valid_times = [
                    t for t in self._key_request_times.get(key, [])
                    if now - t <= window
                ]
                completed = len(valid_times)
                active = self._active_requests.get(key, 0)
                
                # Key is usable if we haven't exceeded capacity
                return (completed + active) < max_requests
            
            return True

    async def get_key_stats(self, key: str) -> Dict[str, Any]:
        """Get statistics for a key (useful for debugging)."""
        async with self._lock:
            config = self.stress_config or StressBasedConfig()
            now = datetime.now(timezone.utc)
            window = timedelta(seconds=config.time_window_requests_per_minute)
            max_requests = config.max_requests_per_minute
            
            valid_times = [
                t for t in self._key_request_times.get(key, [])
                if now - t <= window
            ]
            
            # Calculate when the key will have space available
            wait_time = 0
            if len(valid_times) >= max_requests and valid_times:
                oldest_in_window = min(valid_times)
                wait_time = max(0, int((oldest_in_window + window - now).total_seconds()))
            
            return {
                "key_available": await self.is_usable(key),
                "current_requests": len(valid_times),
                "max_requests": max_requests,
                "wait_time_seconds": wait_time,
                "is_marked_used_up": not self._key_status.get(key, False)
            }

    async def register_request(self, key: str):
        """Register a request for a key (for stress-based tracking)."""
        if self.tag_system != TagSystemType.STRESS_BASED:
            return
        
        async with self._lock:
            if key not in self._key_request_times:
                self._key_request_times[key] = []
            self._key_request_times[key].append(datetime.now(timezone.utc))
            debug_print(f"[KEYRING:{self.hoster}] Registered request for key {key[:8]}... ({len(self._key_request_times[key])} requests in window)")
        
        # Process pending requests after registering (outside lock to avoid deadlock)
        await self._process_pending_requests()

    async def cleanup_expired_tags(self):
        """Remove expired request timestamps from all keys."""
        if self.tag_system != TagSystemType.STRESS_BASED:
            return
        
        async with self._lock:
            config = self.stress_config or StressBasedConfig()
            now = datetime.now(timezone.utc)
            window = timedelta(seconds=config.time_window_seconds)
            
            cleaned = 0
            for key in self._key_request_times:
                before = len(self._key_request_times[key])
                self._key_request_times[key] = [
                    t for t in self._key_request_times[key]
                    if now - t <= window
                ]
                cleaned += before - len(self._key_request_times[key])
            
            if cleaned > 0:
                debug_print(f"[KEYRING:{self.hoster}] Cleaned up {cleaned} expired request tags")

    async def get_best_key(self) -> Optional[str]:
        """
        Get the best key based on the tag system.
        For rotational: returns the first usable key in order
        For stress-based: returns the key with the fewest requests in the current window
        """
        async with self._lock:
            if self.tag_system == TagSystemType.STRESS_BASED:
                usable = await self.usable_keys_snapshot()
                if not usable:
                    return None
                
                # Get key with fewest requests
                now = datetime.now(timezone.utc)
                config = self.stress_config or StressBasedConfig()
                window = timedelta(seconds=config.time_window_seconds)
                
                best_key = None
                min_requests = float('inf')
                
                for key in usable:
                    valid_times = [
                        t for t in self._key_request_times.get(key, [])
                        if now - t <= window
                    ]
                    if len(valid_times) < min_requests:
                        min_requests = len(valid_times)
                        best_key = key
                
                return best_key
            else:
                # Rotational - return first usable
                for key in self._key_order:
                    if await self.is_usable(key):
                        return key
                return None

    def set_stress_config(self, max_requests_per_minute: int, time_window_seconds: int = 60):
        """Configure stress-based key management."""
        # Check if already configured with the same values
        if (self.tag_system == TagSystemType.STRESS_BASED and 
            self.stress_config and 
            self.stress_config.max_requests_per_minute == max_requests_per_minute and
            self.stress_config.time_window_seconds == time_window_seconds):
            return  # Already configured with same values
        
        self.tag_system = TagSystemType.STRESS_BASED
        self.stress_config = StressBasedConfig(
            max_requests_per_minute=max_requests_per_minute,
            time_window_seconds=time_window_seconds
        )
        # Initialize tracking for all keys
        for key in self.keys:
            if key not in self._key_request_times:
                self._key_request_times[key] = []
        debug_print(f"[KEYRING:{self.hoster}] Configured stress-based system: {max_requests_per_minute} requests per {time_window_seconds}s")


def load_keys_from_txt(path: Path) -> List[str]:
    if not path.exists():
        return []
    lines = path.read_text(encoding="utf-8").splitlines()
    keys: List[str] = []
    for ln in lines:
        s = ln.strip()
        if not s or s.startswith("#"):
            continue
        keys.append(s)
    return keys
