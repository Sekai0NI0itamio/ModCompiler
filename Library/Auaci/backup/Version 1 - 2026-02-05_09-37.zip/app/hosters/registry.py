from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Dict

from ..core.keyring import KeyRing, TagSystemType, load_keys_from_txt, DEFAULT_USED_UP_FILE
from ..core.utils import debug_print
from .base import Hoster
from .nvidia import NvidiaHoster
from .openrouter import OpenRouterHoster
from .poe import PoeHoster


DEFAULT_HOSTER = "poe"

# Default stress-based configuration for Nvidia
NVIDIA_STRESS_CONFIG = {
    "max_requests_per_minute": 2,
    "time_window_seconds": 60,
}


@dataclass
class HosterRegistry:
    key_dir: Path = Path("keys")
    used_up_file: Path = DEFAULT_USED_UP_FILE

    def __post_init__(self):
        self._hosters: Dict[str, Hoster] = {}

    def _load_keyring(self, hoster: str) -> KeyRing:
        key_path = self.key_dir / f"{hoster}.txt"
        keys = load_keys_from_txt(key_path)
        if not keys:
            debug_print(f"[HOSTER] No keys found for '{hoster}' in {key_path}")
        
        # Create KeyRing with the used-up keys file
        keyring = KeyRing(hoster=hoster, keys=keys, used_up_file=self.used_up_file)
        
        # Configure stress-based system for Nvidia
        if hoster == "nvidia":
            keyring.set_stress_config(
                max_requests_per_minute=NVIDIA_STRESS_CONFIG["max_requests_per_minute"],
                time_window_seconds=NVIDIA_STRESS_CONFIG["time_window_seconds"]
            )
        
        return keyring

    def get(self, hoster: str) -> Hoster:
        hoster = (hoster or "").strip().lower() or DEFAULT_HOSTER
        if hoster in self._hosters:
            return self._hosters[hoster]

        if hoster == "poe":
            inst = PoeHoster(self._load_keyring("poe"))
        elif hoster == "openrouter":
            inst = OpenRouterHoster(self._load_keyring("openrouter"))
        elif hoster == "nvidia":
            inst = NvidiaHoster(self._load_keyring("nvidia"))
        else:
            raise KeyError(f"Unknown hoster '{hoster}'")

        self._hosters[hoster] = inst
        return inst
