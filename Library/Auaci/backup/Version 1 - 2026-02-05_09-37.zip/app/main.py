import argparse
import asyncio
import os
import sys
from contextlib import asynccontextmanager
from pathlib import Path
from typing import Optional

from fastapi import FastAPI
import uvicorn

from .api.routes import router
from .core.utils import DEBUG_ENV_VAR, debug_print
from .hosters.registry import HosterRegistry


# Background task for cleanup
cleanup_task: Optional[asyncio.Task] = None
registry: Optional[HosterRegistry] = None


async def periodic_tag_cleanup():
    """Periodically clean up expired tags from all keyrings."""
    global registry
    while True:
        try:
            await asyncio.sleep(30)  # Run every 30 seconds
            if registry is None:
                registry = HosterRegistry()
            
            for hoster_name in ["poe", "openrouter", "nvidia"]:
                try:
                    hoster = registry.get(hoster_name)
                    await hoster.keyring.cleanup_expired_tags()
                except Exception:
                    pass
        except asyncio.CancelledError:
            break
        except Exception as e:
            debug_print(f"[CLEANUP] Error during tag cleanup: {e}")


@asynccontextmanager
async def lifespan(app: FastAPI):
    """Manage application lifespan - start/stop background tasks."""
    global cleanup_task
    
    # Start background cleanup task
    cleanup_task = asyncio.create_task(periodic_tag_cleanup())
    debug_print("[MAIN] Started background tag cleanup task")
    
    yield
    
    # Cleanup on shutdown
    if cleanup_task:
        cleanup_task.cancel()
        try:
            await asyncio.wait_for(cleanup_task, timeout=2.0)
        except asyncio.TimeoutError:
            pass
        except asyncio.CancelledError:
            pass
        debug_print("[MAIN] Stopped background tag cleanup task")


app = FastAPI(lifespan=lifespan)
app.include_router(router)


def main():
    parser = argparse.ArgumentParser(description="FastAPI streaming proxy (multi-hoster: poe/openrouter/nvidia).")
    parser.add_argument("--ekau", action="store_true", help="Warm each API key before starting the server.")
    parser.add_argument("--debug", action="store_true", help="Enable debug logging.")
    parser.add_argument("--reset", action="store_true", help="Clear KeysUsedUp.txt and reset all keys before starting.")
    parser.add_argument("--host", default="0.0.0.0", help="Host to bind the server to (default: 0.0.0.0).")
    parser.add_argument("--port", type=int, default=8129, help="Port to bind the server to (default: 8129).")
    parser.add_argument("--no-reload", action="store_true", help="Disable auto-reload on code changes.")
    args = parser.parse_args()

    if args.debug:
        os.environ[DEBUG_ENV_VAR] = "1"
    else:
        os.environ.pop(DEBUG_ENV_VAR, None)

    if args.debug:
        debug_print("[MAIN] Debug mode enabled")

    # Handle --reset flag: clear the KeysUsedUp.txt file before starting
    if args.reset:
        from .core.keyring import reset_used_up_file
        reset_used_up_file()
        debug_print("[MAIN] --reset: Cleared KeysUsedUp.txt file")

    # NOTE: warmup not reimplemented yet; keep flag for CLI compatibility.
    if args.ekau:
        debug_print("[MAIN] --ekau is currently a no-op in the refactor")

    reload_enabled = not args.no_reload

    module_name = "app.main"

    project_root = str(Path(__file__).resolve().parent.parent)
    if project_root not in sys.path:
        sys.path.insert(0, project_root)

    debug_print(f"[MAIN] Starting server on {args.host}:{args.port} (reload={reload_enabled})")

    uvicorn.run(
        f"{module_name}:app",
        host=args.host,
        port=args.port,
        reload=reload_enabled,
        reload_dirs=[project_root],
        log_level="debug" if args.debug else "info",
    )


if __name__ == "__main__":
    main()
