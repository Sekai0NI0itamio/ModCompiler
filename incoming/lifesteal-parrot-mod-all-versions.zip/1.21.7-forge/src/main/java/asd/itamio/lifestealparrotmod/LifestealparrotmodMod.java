package asd.itamio.lifestealparrotmod;

import com.mojang.logging.LogUtils;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.player.Player;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.event.entity.living.LivingDeathEvent;
import net.minecraftforge.eventbus.api.Event.BUS;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;
import net.minecraftforge.fml.event.lifecycle.FMLCommonSetupEvent;
import org.slf4j.Logger;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

@Mod(LifestealparrotmodMod.MODID)
public final class LifestealparrotmodMod {
    public static final String MODID = "lifestealparrotmod";
    private static final Logger LOGGER = LogUtils.getLogger();
    private static final Map<UUID, Integer> HEART_COUNTS = new HashMap<>();
    private static final int MIN_HEARTS = 0;
    private static final int DEFAULT_HEARTS = 20;

    public LifestealparrotmodMod(FMLJavaModLoadingContext context) {
        IEventBus modEventBus = context.getModEventBus();
        modEventBus.addListener(this::commonSetup);
        MinecraftForge.EVENT_BUS.addListener(LifestealparrotmodMod::onLivingDeath);
    }

    private void commonSetup(final FMLCommonSetupEvent event) {
        LOGGER.info("Lifesteal Mod initialized");
    }

    private static void onLivingDeath(LivingDeathEvent event) {
        if (!(event.getEntity() instanceof ServerPlayer victim)) return;

        UUID victimUUID = victim.getUUID();
        int hearts = HEART_COUNTS.getOrDefault(victimUUID, DEFAULT_HEARTS);

        // Death: lose heart
        hearts--;
        HEART_COUNTS.put(victimUUID, hearts);
        updateMaxHealth(victim, hearts);

        if (hearts <= MIN_HEARTS) {
            victim.getServer().getPlayerList().getBannedPlayers().add(
                new net.minecraft.server.players.BanListEntry(victim.getGameProfile(), null, "Permadeath: ran out of hearts", null, "Lifesteal Mod"));
            victim.connection.disconnect(net.minecraft.network.chat.Component.literal("Permadeath: ran out of hearts"));
            return;
        }

        // Check for player kill
        if (event.getSource().getEntity() instanceof ServerPlayer killer) {
            if (!killer.getUUID().equals(victimUUID)) {
                int kHearts = HEART_COUNTS.getOrDefault(killer.getUUID(), DEFAULT_HEARTS) + 1;
                HEART_COUNTS.put(killer.getUUID(), kHearts);
                updateMaxHealth(killer, kHearts);
            }
        }
    }

    private static void updateMaxHealth(ServerPlayer player, int hearts) {
        player.getAttributes().getInstance(net.minecraft.world.entity.ai.attributes.Attributes.MAX_HEALTH)
            .setBaseValue(Math.max(1, hearts));
        player.setHealth(player.getMaxHealth());
    }
}