package asd.itamio.lifestealparrotmod;

import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.NbtIo;

import java.io.File;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

public class HeartStorage {
    private static final HeartStorage INSTANCE = new HeartStorage();
    private final Map<UUID, Integer> cache = new HashMap<>();

    private HeartStorage() {}

    public static HeartStorage getInstance() {
        return INSTANCE;
    }

    public int load(String playerUUID, File playerFile) {
        UUID uuid = UUID.fromString(playerUUID);
        if (playerFile.exists()) {
            try {
                CompoundTag tag = NbtIo.read(playerFile.toPath());
                if (tag != null && tag.contains("hearts")) {
                    int h = tag.getInt("hearts");
                    this.cache.put(uuid, h);
                    return h;
                }
            } catch (IOException e) {
                LifestealparrotmodMod.LOGGER.error("[HeartSystem] Failed to load: {}", e.getMessage());
            }
        }
        return -1;
    }

    public void save(String playerUUID, File playerFile, int hearts) {
        UUID uuid = UUID.fromString(playerUUID);
        this.cache.put(uuid, hearts);
        CompoundTag tag = new CompoundTag();
        tag.putInt("hearts", hearts);
        try {
            NbtIo.write(tag, playerFile.toPath());
        } catch (IOException e) {
            LifestealparrotmodMod.LOGGER.error("[HeartSystem] Failed to save: {}", e.getMessage());
        }
    }

    public boolean has(UUID uuid) {
        return this.cache.containsKey(uuid);
    }

    public int getHearts(UUID uuid) {
        Integer h = this.cache.get(uuid);
        return h != null ? h : -1;
    }

    public void setHearts(UUID uuid, int hearts) {
        this.cache.put(uuid, hearts);
    }

    public void remove(UUID uuid) {
        this.cache.remove(uuid);
    }
}