package asd.itamio.lifestealparrotmod;

import net.neoforged.bus.api.IEventBus;
import net.neoforged.fml.common.Mod;
import net.neoforged.neoforge.common.NeoForge;

@Mod("heartsystem")
public class HeartSystemMod {
    public static final String MOD_ID = "heartsystem";
    public static HeartConfig config;

    public HeartSystemMod(IEventBus modEventBus) {
        config = new HeartConfig();
        HeartEventHandler handler = new HeartEventHandler();
        NeoForge.EVENT_BUS.register(handler);
    }
}