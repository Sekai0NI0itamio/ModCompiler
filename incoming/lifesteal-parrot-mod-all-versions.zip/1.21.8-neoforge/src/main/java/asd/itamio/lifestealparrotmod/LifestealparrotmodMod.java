package asd.itamio.lifestealparrotmod;

import net.neoforged.bus.api.IEventBus;
import net.neoforged.fml.common.Mod;

@Mod("lifestealparrotmod")
public final class LifestealparrotmodMod {
    public static final String MOD_ID = "lifestealparrotmod";

    public LifestealparrotmodMod(IEventBus modEventBus) {
    }
}