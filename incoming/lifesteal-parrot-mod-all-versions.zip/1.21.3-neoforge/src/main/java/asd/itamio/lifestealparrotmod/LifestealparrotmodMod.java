package asd.itamio.lifestealparrotmod;

import net.neoforged.bus.api.IEventBus;
import net.neoforged.fml.common.Mod;
import net.neoforged.neoforge.common.NeoForge;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

@Mod("lifestealparrotmod")
public class LifestealparrotmodMod {
    public static final String MOD_ID = "lifestealparrotmod";
    public static final Logger LOGGER = LogManager.getLogger();
    public static HeartConfig CONFIG;

    public LifestealparrotmodMod(IEventBus modEventBus) {
        CONFIG = new HeartConfig(modEventBus);
        NeoForge.EVENT_BUS.register(new HeartEventHandler());
    }
}