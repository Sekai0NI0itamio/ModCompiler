package asd.itamio.lifestealparrotmod;

import net.neoforged.bus.api.IEventBus;
import net.neoforged.fml.common.Mod;
import net.neoforged.neoforge.common.NeoForge;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@Mod("lifestealparrotmod")
public final class LifestealparrotmodMod {
    public static final String MOD_ID = "lifestealparrotmod";
    public static final Logger logger = LoggerFactory.getLogger(LifestealparrotmodMod.class);
    public static HeartConfig config;

    public LifestealparrotmodMod(IEventBus modEventBus) {
        config = new HeartConfig();
        NeoForge.EVENT_BUS.register(new HeartEventHandler());
    }
}