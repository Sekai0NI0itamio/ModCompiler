package asd.itamio.lifestealparrotmod;

import com.mojang.logging.LogUtils;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.storage.LevelResource;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.event.entity.living.LivingDeathEvent;
import net.minecraftforge.event.entity.player.PlayerEvent;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.event.lifecycle.FMLCommonSetupEvent;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;
import net.minecraftforge.fml.loading.FMLPaths;
import org.slf4j.Logger;

import java.io.*;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

@Mod(LifestealparrotmodMod.MODID)
public class LifestealparrotmodMod {
    public static final String MODID = "lifestealparrotmod";
    private static final Logger LOGGER = LogUtils.getLogger();
    private static final Map<UUID, Integer> playerHearts = new HashMap<>();
    private static final int MIN_HEARTS = 0;
    private static final int DEFAULT_HEARTS = 20;

    public LifestealparrotmodMod(FMLJavaModLoadingContext context) {
        IEventBus modEventBus = context.getModEventBus();
        modEventBus.addListener(this::commonSetup);
        MinecraftForge.EVENT_BUS.register(this);
    }

    private void commonSetup(final FMLCommonSetupEvent event) {
        LOGGER.info("Lifesteal Mod initialized");
    }

    @SubscribeEvent
    public void onPlayerJoin(PlayerEvent.PlayerLoggedInEvent event) {
        if (event.getEntity() instanceof ServerPlayer player) {
            loadHearts(player);
            updateMaxHealth(player);
        }
    }

    @SubscribeEvent
    public void onPlayerDeath(LivingDeathEvent event) {
        if (event.getEntity() instanceof ServerPlayer victim) {
            int hearts = getHearts(victim.getUUID());
            hearts = Math.max(MIN_HEARTS, hearts - 1);
            setHearts(victim.getUUID(), hearts);
            updateMaxHealth(victim);

            if (hearts <= MIN_HEARTS) {
                banPlayer(victim);
            }

            if (event.getSource().getEntity() instanceof ServerPlayer killer) {
                if (!killer.getUUID().equals(victim.getUUID())) {
                    int kHearts = getHearts(killer.getUUID()) + 1;
                    setHearts(killer.getUUID(), kHearts);
                    updateMaxHealth(killer);
                }
            }
        }
    }

    private int getHearts(UUID uuid) {
        return playerHearts.getOrDefault(uuid, DEFAULT_HEARTS);
    }

    private void setHearts(UUID uuid, int hearts) {
        playerHearts.put(uuid, hearts);
        saveHearts(uuid, hearts);
    }

    private void updateMaxHealth(Player player) {
        if (player instanceof ServerPlayer) {
            int hearts = getHearts(player.getUUID());
            player.setMaxHealth(hearts * 2.0F);
            player.setHealth(player.getMaxHealth());
        }
    }

    private void banPlayer(ServerPlayer player) {
        player.getServer().getPlayerList().getBans().add(
            new net.minecraft.server.players.BanList.UserBanEntry(
                player.getGameProfile(), null, "Permadeath: ran out of hearts", null, "Lifesteal Mod"
            )
        );
        player.connection.disconnect(net.minecraft.network.chat.Component.literal("Permadeath: ran out of hearts"));
    }

    private Path getHeartsFile() {
        return FMLPaths.GAMEDIR.get().resolve("saves").resolve("lifesteal_hearts.dat");
    }

    private void saveHearts(UUID uuid, int hearts) {
        try {
            Path path = getHeartsFile();
            Files.createDirectories(path.getParent());
            Map<UUID, Integer> all = loadAllHearts();
            all.put(uuid, hearts);
            try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(path.toFile()))) {
                oos.writeObject(all);
            }
        } catch (Exception e) {
            LOGGER.error("Failed to save hearts", e);
        }
    }

    private void loadHearts(ServerPlayer player) {
        try {
            Map<UUID, Integer> all = loadAllHearts();
            int hearts = all.getOrDefault(player.getUUID(), DEFAULT_HEARTS);
            playerHearts.put(player.getUUID(), hearts);
        } catch (Exception e) {
            LOGGER.error("Failed to load hearts", e);
        }
    }

    @SuppressWarnings("unchecked")
    private Map<UUID, Integer> loadAllHearts() {
        Path path = getHeartsFile();
        if (!Files.exists(path)) return new HashMap<>();
        try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream(path.toFile()))) {
            return (Map<UUID, Integer>) ois.readObject();
        } catch (Exception e) {
            LOGGER.error("Failed to load hearts file", e);
            return new HashMap<>();
        }
    }
}