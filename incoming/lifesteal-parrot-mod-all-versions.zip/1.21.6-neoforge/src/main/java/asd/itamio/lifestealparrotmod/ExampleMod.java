package asd.itamio.lifestealparrotmod;

import com.mojang.authlib.GameProfile;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.server.players.UserBanList;
import net.minecraft.server.players.UserBanListEntry;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.ai.attributes.AttributeInstance;
import net.minecraft.world.entity.ai.attributes.AttributeModifier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.player.Player;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.fml.common.Mod;
import net.neoforged.fml.config.ModConfig;
import net.neoforged.neoforge.common.ModConfigSpec;
import net.neoforged.neoforge.common.NeoForge;
import net.neoforged.neoforge.event.entity.living.LivingDeathEvent;
import net.neoforged.neoforge.event.entity.player.PlayerEvent;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.File;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

@Mod("lifestealparrotmod")
public class ExampleMod {
    public static final String MOD_ID = "lifestealparrotmod";
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);
    public static HeartConfig CONFIG;

    public ExampleMod(IEventBus modEventBus) {
        CONFIG = new HeartConfig(modEventBus);
        NeoForge.EVENT_BUS.addListener(this::onLivingDeath);
        NeoForge.EVENT_BUS.addListener(this::onPlayerLoad);
        NeoForge.EVENT_BUS.addListener(this::onPlayerSave);
        NeoForge.EVENT_BUS.addListener(this::onPlayerClone);
    }

    private void onPlayerLoad(PlayerEvent.LoadFromFile event) {
        Player player = event.getEntity();
        if (!player.level().isClientSide()) {
            String uuidStr = event.getPlayerUUID();
            File file = event.getPlayerFile("heartsystem");
            int loaded = HeartStorage.get().load(uuidStr, file);
            if (loaded < 0) {
                HeartStorage.get().setHearts(UUID.fromString(uuidStr), CONFIG.startHearts.get());
            }
        }
    }

    private void onPlayerSave(PlayerEvent.SaveToFile event) {
        Player player = event.getEntity();
        if (!player.level().isClientSide()) {
            String uuidStr = event.getPlayerUUID();
            UUID uuid = UUID.fromString(uuidStr);
            File file = event.getPlayerFile("heartsystem");
            int hearts = HeartStorage.get().getHearts(uuid);
            if (hearts < 0) {
                hearts = CONFIG.startHearts.get();
            }
            HeartStorage.get().save(uuidStr, file, hearts);
        }
    }

    private void onPlayerClone(PlayerEvent.Clone event) {
        Player newPlayer = event.getEntity();
        if (!newPlayer.level().isClientSide()) {
            if (event.isWasDeath()) {
                UUID uuid = newPlayer.getUUID();
                if (HeartStorage.get().has(uuid)) {
                    if (newPlayer instanceof ServerPlayer serverPlayer) {
                        int hearts = HeartStorage.get().getHearts(uuid);
                        HeartData.applyMaxHealth(serverPlayer, hearts);
                    }
                }
            }
        }
    }

    private void onLivingDeath(LivingDeathEvent event) {
        if (!event.getEntity().level().isClientSide() && event.getEntity() instanceof ServerPlayer deadPlayer) {
            UUID deadUUID = deadPlayer.getUUID();
            int hearts = HeartStorage.get().getHearts(deadUUID);
            if (hearts < 0) {
                hearts = CONFIG.startHearts.get();
            }
            hearts--;
            int min = CONFIG.minHearts.get();
            if (hearts <= min) {
                HeartStorage.get().setHearts(deadUUID, min);
                MinecraftServer server = deadPlayer.getServer();
                if (server != null) {
                    server.getPlayerList().broadcastSystemMessage(
                            Component.literal("§c[HeartSystem] " + deadPlayer.getName().getString() + " has been permanently banned (0 hearts)."),
                            false
                    );
                    UserBanList banList = server.getPlayerList().getBans();
                    banList.add(new UserBanListEntry(
                            new GameProfile(deadUUID, deadPlayer.getName().getString()),
                            null, null, null, "Permadeath: ran out of hearts"
                    ));
                }
                deadPlayer.connection.disconnect(Component.literal("§cYou have been permanently banned.\nYou ran out of hearts."));
            } else {
                HeartStorage.get().setHearts(deadUUID, hearts);
                deadPlayer.sendSystemMessage(Component.literal("§c[HeartSystem] You lost a heart! Hearts remaining: " + hearts));
            }

            DamageSource source = event.getSource();
            Entity killer = source.getEntity();
            if (killer instanceof ServerPlayer killerPlayer) {
                UUID killerUUID = killerPlayer.getUUID();
                int killerHearts = HeartStorage.get().getHearts(killerUUID);
                if (killerHearts < 0) {
                    killerHearts = CONFIG.startHearts.get();
                }
                int max = CONFIG.maxHearts.get();
                if (killerHearts < max) {
                    killerHearts++;
                    HeartStorage.get().setHearts(killerUUID, killerHearts);
                    HeartData.applyMaxHealth(killerPlayer, killerHearts);
                    killerPlayer.sendSystemMessage(Component.literal("§a[HeartSystem] You gained a heart! Hearts: " + killerHearts));
                } else {
                    killerPlayer.sendSystemMessage(Component.literal("§e[HeartSystem] You killed a player but are already at max hearts (" + max + ")."));
                }
            }
        }
    }

    // --- Inner classes ---

    public static class HeartConfig {
        public final ModConfigSpec.IntValue startHearts;
        public final ModConfigSpec.IntValue maxHearts;
        public final ModConfigSpec.IntValue minHearts;

        public HeartConfig(IEventBus modEventBus) {
            ModConfigSpec.Builder builder = new ModConfigSpec.Builder();
            builder.comment("Heart System Configuration");
            startHearts = builder.comment("Hearts a new player starts with (1 heart = 2 HP)")
                    .defineInRange("startHearts", 10, 1, 100);
            maxHearts = builder.comment("Maximum hearts a player can have")
                    .defineInRange("maxHearts", 20, 1, 100);
            minHearts = builder.comment("Minimum hearts before permadeath")
                    .defineInRange("minHearts", 0, 0, 99);
            ModConfigSpec spec = builder.build();
            modEventBus.register(spec);
        }
    }

    public static class HeartData {
        private static final ResourceLocation MODIFIER_ID = ResourceLocation.fromNamespaceAndPath(MOD_ID, "maxhealth");

        public static void applyMaxHealth(ServerPlayer player, int hearts) {
            AttributeInstance attr = player.getAttribute(Attributes.MAX_HEALTH);
            if (attr != null) {
                attr.removeModifier(MODIFIER_ID);
                double delta = (double) hearts * 2.0 - 20.0;
                AttributeModifier mod = new AttributeModifier(MODIFIER_ID, delta, AttributeModifier.Operation.ADD_VALUE);
                attr.addPermanentModifier(mod);
                float newMax = hearts * 2.0F;
                if (player.getHealth() > newMax) {
                    player.setHealth(newMax);
                }
            }
        }
    }

    public static class HeartStorage {
        private static final HeartStorage INSTANCE = new HeartStorage();
        private final Map<UUID, Integer> cache = new HashMap<>();

        public static HeartStorage get() {
            return INSTANCE;
        }

        private HeartStorage() {}

        public int load(String playerUUID, File playerFile) {
            UUID uuid = UUID.fromString(playerUUID);
            if (playerFile.exists()) {
                try {
                    var tag = net.minecraft.nbt.NbtIo.read(playerFile.toPath());
                    if (tag != null && tag.contains("hearts")) {
                        int h = tag.getInt("hearts").orElse(-1);
                        cache.put(uuid, h);
                        return h;
                    }
                } catch (IOException e) {
                    LOGGER.error("[HeartSystem] Failed to load: {}", e.getMessage());
                }
            }
            return -1;
        }

        public void save(String playerUUID, File playerFile, int hearts) {
            UUID uuid = UUID.fromString(playerUUID);
            cache.put(uuid, hearts);
            var tag = new net.minecraft.nbt.CompoundTag();
            tag.putInt("hearts", hearts);
            try {
                net.minecraft.nbt.NbtIo.write(tag, playerFile.toPath());
            } catch (IOException e) {
                LOGGER.error("[HeartSystem] Failed to save: {}", e.getMessage());
            }
        }

        public boolean has(UUID uuid) {
            return cache.containsKey(uuid);
        }

        public int getHearts(UUID uuid) {
            Integer h = cache.get(uuid);
            return h != null ? h : -1;
        }

        public void setHearts(UUID uuid, int hearts) {
            cache.put(uuid, hearts);
        }

        public void remove(UUID uuid) {
            cache.remove(uuid);
        }
    }
}