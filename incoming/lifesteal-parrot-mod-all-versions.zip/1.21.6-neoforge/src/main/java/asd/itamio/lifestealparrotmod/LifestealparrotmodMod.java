package asd.itamio.lifestealparrotmod;

import net.neoforged.bus.api.IEventBus;
import net.neoforged.fml.ModContainer;
import net.neoforged.fml.ModList;
import net.neoforged.fml.common.Mod;
import net.neoforged.fml.config.ModConfig;
import net.neoforged.fml.event.lifecycle.FMLCommonSetupEvent;
import net.neoforged.neoforge.common.NeoForge;

@Mod("lifestealparrotmod")
public final class LifestealparrotmodMod {
    public static final String MOD_ID = "lifestealparrotmod";
    public static HeartConfig CONFIG;

    public LifestealparrotmodMod(IEventBus modEventBus, ModContainer container) {
        ModList.get().getModContainerById(MOD_ID).ifPresent(c -> {
            CONFIG = new HeartConfig();
            container.registerConfig(ModConfig.Type.SERVER, HeartConfig.SPEC);
        });
        modEventBus.addListener(this::commonSetup);
    }

    private void commonSetup(FMLCommonSetupEvent event) {
        NeoForge.EVENT_BUS.register(new HeartEventHandler());
    }
}