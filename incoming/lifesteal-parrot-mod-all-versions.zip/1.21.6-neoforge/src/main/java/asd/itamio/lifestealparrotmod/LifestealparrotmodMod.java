package asd.itamio.lifestealparrotmod;

import net.neoforged.bus.api.IEventBus;
import net.neoforged.fml.common.Mod;
import net.neoforged.fml.javafmlmod.FMLJavaModLoadingContext;
import net.neoforged.neoforge.common.NeoForge;
import net.neoforged.neoforge.event.entity.living.LivingDeathEvent;
import net.neoforged.neoforge.event.entity.player.PlayerEvent;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

@Mod("lifestealparrotmod")
public final class LifestealparrotmodMod {
    public static final String MOD_ID = "lifestealparrotmod";
    public static final Logger LOGGER = LogManager.getLogger();
    public static HeartConfig CONFIG;

    public LifestealparrotmodMod(IEventBus modEventBus) {
        CONFIG = new HeartConfig(FMLJavaModLoadingContext.get());

        HeartEventHandler handler = new HeartEventHandler();

        modEventBus.addListener(handler::onPlayerLoad);
        modEventBus.addListener(handler::onPlayerSave);
        modEventBus.addListener(handler::onPlayerClone);

        NeoForge.EVENT_BUS.addListener(handler::onLivingDeath);
    }
}