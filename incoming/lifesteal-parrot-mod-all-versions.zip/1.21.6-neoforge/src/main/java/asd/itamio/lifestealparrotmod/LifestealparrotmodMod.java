package asd.itamio.lifestealparrotmod;

import net.neoforged.bus.api.IEventBus;
import net.neoforged.fml.ModLoadingContext;
import net.neoforged.fml.common.Mod;
import net.neoforged.fml.config.ModConfig;
import net.neoforged.neoforge.common.NeoForge;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@Mod("lifestealparrotmod")
public final class LifestealparrotmodMod {
    public static final String MOD_ID = "lifestealparrotmod";
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);
    public static HeartConfig CONFIG;

    public LifestealparrotmodMod(IEventBus modEventBus) {
        // Build and register config (server only)
        CONFIG = new HeartConfig();
        ModLoadingContext.get().registerConfig(ModConfig.Type.SERVER, CONFIG.getSpec());

        // Register event handler on the NeoForge event bus
        NeoForge.EVENT_BUS.register(new HeartEventHandler());
    }
}