package asd.itamio.lifestealparrotmod;

import net.neoforged.bus.api.IEventBus;
import net.neoforged.fml.ModLoadingContext;
import net.neoforged.fml.common.Mod;
import net.neoforged.fml.config.ModConfig;
import net.neoforged.neoforge.common.ModConfigSpec;
import net.neoforged.neoforge.common.NeoForge;
import net.neoforged.neoforge.event.entity.living.LivingDeathEvent;
import net.neoforged.neoforge.event.entity.player.PlayerEvent;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@Mod("lifestealparrotmod")
public class LifestealparrotmodMod {
    public static final String MOD_ID = "lifestealparrotmod";
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);
    public static HeartConfig config;
    public static HeartStorage storage;

    public LifestealparrotmodMod(IEventBus modEventBus) {
        // Register configuration
        ModConfigSpec.Builder builder = new ModConfigSpec.Builder();
        config = new HeartConfig(builder);
        ModLoadingContext.get().getActiveContainer().registerConfig(ModConfig.Type.SERVER, builder.build());

        // Create storage instance
        storage = HeartStorage.getInstance();

        // Register event handler
        HeartEventHandler handler = new HeartEventHandler();
        NeoForge.EVENT_BUS.addListener(handler::onPlayerLoad);
        NeoForge.EVENT_BUS.addListener(handler::onPlayerSave);
        NeoForge.EVENT_BUS.addListener(handler::onPlayerClone);
        NeoForge.EVENT_BUS.addListener(handler::onLivingDeath);
    }
}