package asd.itamio.lifestealparrotmod;

import net.neoforged.bus.api.IEventBus;
import net.neoforged.fml.common.Mod;
import net.neoforged.fml.javafmlmod.FMLJavaModLoadingContext;
import net.neoforged.neoforge.common.NeoForge;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

@Mod("lifestealparrotmod")
public final class LifestealparrotmodMod {
    public static final String MOD_ID = "lifestealparrotmod";
    public static final Logger LOGGER = LogManager.getLogger();
    public static HeartConfig CONFIG;

    public LifestealparrotmodMod(FMLJavaModLoadingContext context) {
        CONFIG = new HeartConfig(context);
        HeartEventHandler handler = new HeartEventHandler();
        NeoForge.EVENT_BUS.register(handler);
    }
}