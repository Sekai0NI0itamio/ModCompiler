package asd.itamio.lifestealparrotmod;

import net.neoforged.bus.api.IEventBus;
import net.neoforged.fml.common.Mod;
import net.neoforged.neoforge.common.NeoForge;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@Mod(LifestealparrotmodMod.MOD_ID)
public final class LifestealparrotmodMod {
    public static final String MOD_ID = "lifestealparrotmod";
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);
    public static HeartConfig config;

    public LifestealparrotmodMod(IEventBus modEventBus) {
        config = new HeartConfig(modEventBus);
        HeartEventHandler handler = new HeartEventHandler();
        NeoForge.EVENT_BUS.addListener(handler::onPlayerLoad);
        NeoForge.EVENT_BUS.addListener(handler::onPlayerSave);
        NeoForge.EVENT_BUS.addListener(handler::onPlayerClone);
        NeoForge.EVENT_BUS.addListener(handler::onLivingDeath);
    }
}