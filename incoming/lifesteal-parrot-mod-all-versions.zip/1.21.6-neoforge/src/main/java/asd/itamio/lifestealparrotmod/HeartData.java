package asd.itamio.lifestealparrotmod;

import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.ai.attributes.AttributeInstance;
import net.minecraft.world.entity.ai.attributes.AttributeModifier;
import net.minecraft.world.entity.ai.attributes.Attributes;

public class HeartData {
    private static final ResourceLocation MODIFIER_ID =
            ResourceLocation.fromNamespaceAndPath("lifestealparrotmod", "maxhealth");

    public static void applyMaxHealth(ServerPlayer player, int hearts) {
        AttributeInstance attr = player.getAttribute(Attributes.MAX_HEALTH);
        if (attr != null) {
            attr.removeModifier(MODIFIER_ID);
            double delta = (double) hearts * 2.0 - 20.0;
            AttributeModifier mod = new AttributeModifier(MODIFIER_ID, delta, AttributeModifier.Operation.ADD_VALUE);
            attr.addPermanentModifier(mod);
            float newMax = (float) (hearts * 2);
            if (player.getHealth() > newMax) {
                player.setHealth(newMax);
            }
        }
    }
}