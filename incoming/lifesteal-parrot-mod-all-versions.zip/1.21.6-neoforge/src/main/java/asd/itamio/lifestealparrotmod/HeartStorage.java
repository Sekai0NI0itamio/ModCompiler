package asd.itamio.lifestealparrotmod;

import java.io.*;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

public class HeartStorage {
    private static final HeartStorage INSTANCE = new HeartStorage();
    private final Map<UUID, Integer> hearts = new HashMap<>();

    public static HeartStorage get() { return INSTANCE; }

    public int getHearts(UUID uuid) {
        return hearts.getOrDefault(uuid, -1);
    }

    public void setHearts(UUID uuid, int h) {
        hearts.put(uuid, h);
    }

    public boolean has(UUID uuid) {
        return hearts.containsKey(uuid);
    }

    public int load(String uuidStr, File file) {
        UUID uuid = UUID.fromString(uuidStr);
        if (file.exists()) {
            try (DataInputStream dis = new DataInputStream(new BufferedInputStream(new FileInputStream(file)))) {
                int h = dis.readInt();
                hearts.put(uuid, h);
                return h;
            } catch (IOException e) {
                LifestealparrotmodMod.LOGGER.error("Failed to load heart data for {}", uuidStr, e);
            }
        }
        return -1;
    }

    public void save(String uuidStr, File file, int h) {
        try (DataOutputStream dos = new DataOutputStream(new BufferedOutputStream(new FileOutputStream(file)))) {
            dos.writeInt(h);
        } catch (IOException e) {
            LifestealparrotmodMod.LOGGER.error("Failed to save heart data for {}", uuidStr, e);
        }
        hearts.put(UUID.fromString(uuidStr), h);
    }
}