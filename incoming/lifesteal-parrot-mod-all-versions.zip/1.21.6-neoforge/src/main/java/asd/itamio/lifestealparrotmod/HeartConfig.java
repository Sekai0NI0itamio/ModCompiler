package asd.itamio.lifestealparrotmod;

import net.neoforged.neoforge.common.ModConfigSpec;

public class HeartConfig {
    private final ModConfigSpec.IntValue startHearts;
    private final ModConfigSpec.IntValue maxHearts;
    private final ModConfigSpec.IntValue minHearts;
    private final ModConfigSpec spec;

    public HeartConfig() {
        ModConfigSpec.Builder builder = new ModConfigSpec.Builder();
        builder.comment("Heart System Configuration");
        this.startHearts = builder
                .comment("Hearts a new player starts with (1 heart = 2 HP)")
                .defineInRange("startHearts", 10, 1, 100);
        this.maxHearts = builder
                .comment("Maximum hearts a player can have")
                .defineInRange("maxHearts", 20, 1, 100);
        this.minHearts = builder
                .comment("Minimum hearts before permadeath")
                .defineInRange("minHearts", 0, 0, 99);
        this.spec = builder.build();
    }

    public ModConfigSpec getSpec() {
        return spec;
    }

    public int getStartHearts() {
        return startHearts.get();
    }

    public int getMaxHearts() {
        return maxHearts.get();
    }

    public int getMinHearts() {
        return minHearts.get();
    }
}