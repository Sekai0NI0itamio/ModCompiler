package asd.itamio.lifestealparrotmod;

import net.neoforged.neoforge.common.ModConfigSpec;

public class HeartConfig {
    public static final ModConfigSpec.IntValue START_HEARTS;
    public static final ModConfigSpec.IntValue MAX_HEARTS;
    public static final ModConfigSpec.IntValue MIN_HEARTS;
    public static final ModConfigSpec SPEC;

    static {
        ModConfigSpec.Builder BUILDER = new ModConfigSpec.Builder();
        START_HEARTS = BUILDER.comment("Hearts a new player starts with (1 heart = 2 HP)").defineInRange("startHearts", 10, 1, 100);
        MAX_HEARTS = BUILDER.comment("Maximum hearts a player can have").defineInRange("maxHearts", 20, 1, 100);
        MIN_HEARTS = BUILDER.comment("Minimum hearts before permadeath").defineInRange("minHearts", 0, 0, 99);
        SPEC = BUILDER.build();
    }

    public int getStartHearts() { return START_HEARTS.get(); }
    public int getMaxHearts() { return MAX_HEARTS.get(); }
    public int getMinHearts() { return MIN_HEARTS.get(); }
}