package asd.itamio.lifestealparrotmod;

import com.mojang.authlib.GameProfile;
import net.minecraft.network.chat.Component;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.server.players.UserBanList;
import net.minecraft.server.players.UserBanListEntry;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.player.Player;
import net.neoforged.neoforge.event.entity.living.LivingDeathEvent;
import net.neoforged.neoforge.event.entity.player.PlayerEvent;

import java.io.File;
import java.util.UUID;

public class HeartEventHandler {

    public HeartEventHandler() {
        // No additional setup needed; registered via NeoForge.EVENT_BUS
    }

    @net.neoforged.bus.api.SubscribeEvent
    public void onPlayerLoad(PlayerEvent.LoadFromFile event) {
        Player player = event.getEntity();
        if (!player.level().isClientSide()) {
            String uuidStr = event.getPlayerUUID();
            File file = event.getPlayerFile("lifestealparrotmod");
            int loaded = HeartStorage.get().load(uuidStr, file);
            if (loaded < 0) {
                HeartStorage.get().setHearts(UUID.fromString(uuidStr), LifestealparrotmodMod.CONFIG.getStartHearts());
            }
        }
    }

    @net.neoforged.bus.api.SubscribeEvent
    public void onPlayerSave(PlayerEvent.SaveToFile event) {
        Player player = event.getEntity();
        if (!player.level().isClientSide()) {
            String uuidStr = event.getPlayerUUID();
            UUID uuid = UUID.fromString(uuidStr);
            File file = event.getPlayerFile("lifestealparrotmod");
            int hearts = HeartStorage.get().getHearts(uuid);
            if (hearts < 0) {
                hearts = LifestealparrotmodMod.CONFIG.getStartHearts();
            }
            HeartStorage.get().save(uuidStr, file, hearts);
        }
    }

    @net.neoforged.bus.api.SubscribeEvent
    public void onPlayerClone(PlayerEvent.Clone event) {
        Player newPlayer = event.getEntity();
        if (!newPlayer.level().isClientSide()) {
            if (event.isWasDeath()) {
                UUID uuid = newPlayer.getUUID();
                if (HeartStorage.get().has(uuid)) {
                    if (newPlayer instanceof ServerPlayer serverPlayer) {
                        int hearts = HeartStorage.get().getHearts(uuid);
                        HeartData.applyMaxHealth(serverPlayer, hearts);
                    }
                }
            }
        }
    }

    @net.neoforged.bus.api.SubscribeEvent
    public void onLivingDeath(LivingDeathEvent event) {
        if (!event.getEntity().level().isClientSide()) {
            if (event.getEntity() instanceof ServerPlayer deadPlayer) {
                UUID deadUUID = deadPlayer.getUUID();
                int hearts = HeartStorage.get().getHearts(deadUUID);
                if (hearts < 0) {
                    hearts = LifestealparrotmodMod.CONFIG.getStartHearts();
                }

                hearts--;
                int min = LifestealparrotmodMod.CONFIG.getMinHearts();
                if (hearts <= min) {
                    HeartStorage.get().setHearts(deadUUID, min);
                    MinecraftServer server = deadPlayer.getServer();
                    if (server != null) {
                        server.getPlayerList()
                            .broadcastSystemMessage(
                                Component.literal("§c[Lifesteal] " + deadPlayer.getName().getString() + " has been permanently banned (0 hearts)."),
                                false
                            );
                        UserBanList banList = server.getPlayerList().getBans();
                        banList.add(
                            new UserBanListEntry(
                                new GameProfile(deadUUID, deadPlayer.getName().getString()),
                                null, null, null, "Permadeath: ran out of hearts"
                            )
                        );
                    }
                    deadPlayer.connection.disconnect(Component.literal("§cYou have been permanently banned.\nYou ran out of hearts."));
                } else {
                    HeartStorage.get().setHearts(deadUUID, hearts);
                    deadPlayer.sendSystemMessage(Component.literal("§c[Lifesteal] You lost a heart! Hearts remaining: " + hearts));
                }

                // Killer gains a heart
                DamageSource source = event.getSource();
                Entity killer = source.getEntity();
                if (killer instanceof ServerPlayer killerPlayer) {
                    UUID killerUUID = killerPlayer.getUUID();
                    int killerHearts = HeartStorage.get().getHearts(killerUUID);
                    if (killerHearts < 0) {
                        killerHearts = LifestealparrotmodMod.CONFIG.getStartHearts();
                    }
                    int max = LifestealparrotmodMod.CONFIG.getMaxHearts();
                    if (killerHearts < max) {
                        killerHearts++;
                        HeartStorage.get().setHearts(killerUUID, killerHearts);
                        HeartData.applyMaxHealth(killerPlayer, killerHearts);
                        killerPlayer.sendSystemMessage(Component.literal("§a[Lifesteal] You gained a heart! Hearts: " + killerHearts));
                    } else {
                        killerPlayer.sendSystemMessage(Component.literal("§e[Lifesteal] You killed a player but are already at max hearts (" + max + ")."));
                    }
                }
            }
        }
    }
}