package asd.itamio.lifestealparrotmod;

import com.mojang.authlib.GameProfile;
import net.minecraft.network.chat.Component;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.server.players.UserBanList;
import net.minecraft.server.players.UserBanListEntry;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.neoforged.bus.api.EventPriority;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.neoforge.event.entity.living.LivingDeathEvent;
import net.neoforged.neoforge.event.entity.player.PlayerEvent;

import java.util.UUID;

public class HeartEventHandler {
    @SubscribeEvent
    public void onPlayerLoad(PlayerEvent.LoadFromFile event) {
        Player player = event.getEntity();
        if (!player.level().isClientSide()) {
            UUID uuid = event.getPlayerUUID();
            int loaded = HeartStorage.get().load(uuid.toString(), event.getPlayerFile("heartsystem"));
            if (loaded < 0) {
                HeartStorage.get().setHearts(uuid, LifestealparrotmodMod.CONFIG.getStartHearts());
            }
        }
    }

    @SubscribeEvent
    public void onPlayerSave(PlayerEvent.SaveToFile event) {
        Player player = event.getEntity();
        if (!player.level().isClientSide()) {
            UUID uuid = event.getPlayerUUID();
            int hearts = HeartStorage.get().getHearts(uuid);
            if (hearts < 0) hearts = LifestealparrotmodMod.CONFIG.getStartHearts();
            HeartStorage.get().save(uuid.toString(), event.getPlayerFile("heartsystem"), hearts);
        }
    }

    @SubscribeEvent
    public void onPlayerClone(PlayerEvent.Clone event) {
        if (!event.getEntity().level().isClientSide() && event.isWasDeath()) {
            UUID uuid = event.getEntity().getUUID();
            if (HeartStorage.get().has(uuid)) {
                int hearts = HeartStorage.get().getHearts(uuid);
                if (event.getEntity() instanceof ServerPlayer serverPlayer) {
                    HeartData.applyMaxHealth(serverPlayer, hearts);
                }
            }
        }
    }

    @SubscribeEvent(priority = EventPriority.NORMAL)
    public void onLivingDeath(LivingDeathEvent event) {
        if (event.getEntity().level().isClientSide()) return;
        LivingEntity entity = event.getEntity();
        if (!(entity instanceof ServerPlayer deadPlayer)) return;

        UUID deadUUID = deadPlayer.getUUID();
        int hearts = HeartStorage.get().getHearts(deadUUID);
        if (hearts < 0) hearts = LifestealparrotmodMod.CONFIG.getStartHearts();
        --hearts;

        int min = LifestealparrotmodMod.CONFIG.getMinHearts();
        if (hearts <= min) {
            HeartStorage.get().setHearts(deadUUID, min);
            MinecraftServer server = deadPlayer.getServer();
            if (server != null) {
                Component msg = Component.literal("§c[HeartSystem] " + deadPlayer.getName().getString() + " has been permanently banned (0 hearts).");
                server.getPlayerList().getPlayers().forEach(p -> p.sendSystemMessage(msg));
                UserBanList banList = server.getPlayerList().getBans();
                banList.add(new UserBanListEntry(new GameProfile(deadUUID, deadPlayer.getName().getString()), null, null, null, "Permadeath: ran out of hearts"));
            }
            deadPlayer.connection.disconnect(Component.literal("§cYou have been permanently banned.\nYou ran out of hearts."));
        } else {
            HeartStorage.get().setHearts(deadUUID, hearts);
            deadPlayer.sendSystemMessage(Component.literal("§c[HeartSystem] You lost a heart! Hearts remaining: " + hearts));
        }

        DamageSource source = event.getSource();
        Entity killer = source.getEntity();
        if (killer instanceof ServerPlayer killerPlayer && !killerPlayer.getUUID().equals(deadUUID)) {
            UUID killerUUID = killerPlayer.getUUID();
            int killerHearts = HeartStorage.get().getHearts(killerUUID);
            if (killerHearts < 0) killerHearts = LifestealparrotmodMod.CONFIG.getStartHearts();
            int max = LifestealparrotmodMod.CONFIG.getMaxHearts();
            if (killerHearts < max) {
                HeartStorage.get().setHearts(killerUUID, ++killerHearts);
                HeartData.applyMaxHealth(killerPlayer, killerHearts);
                killerPlayer.sendSystemMessage(Component.literal("§a[HeartSystem] You gained a heart! Hearts: " + killerHearts));
            } else {
                killerPlayer.sendSystemMessage(Component.literal("§e[HeartSystem] You killed a player but are already at max hearts (" + max + ")."));
            }
        }
    }
}