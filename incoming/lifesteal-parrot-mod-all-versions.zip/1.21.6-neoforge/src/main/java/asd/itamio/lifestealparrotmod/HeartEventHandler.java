package asd.itamio.lifestealparrotmod;

import com.mojang.authlib.GameProfile;
import java.io.File;
import java.util.Date;
import java.util.UUID;
import net.minecraft.network.chat.Component;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.server.players.UserBanList;
import net.minecraft.server.players.UserBanListEntry;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.player.Player;
import net.neoforged.neoforge.event.entity.living.LivingDeathEvent;
import net.neoforged.neoforge.event.entity.player.PlayerEvent;

public class HeartEventHandler {

    public void onPlayerLoad(PlayerEvent.LoadFromFile event) {
        Player player = event.getEntity();
        if (!player.level().isClientSide()) {
            String uuidStr = event.getPlayerUUID();
            File file = event.getPlayerFile("heartsystem");
            int loaded = LifestealparrotmodMod.storage.load(uuidStr, file);
            if (loaded < 0) {
                LifestealparrotmodMod.storage.setHearts(UUID.fromString(uuidStr), LifestealparrotmodMod.config.getStartHearts());
            }
        }
    }

    public void onPlayerSave(PlayerEvent.SaveToFile event) {
        Player player = event.getEntity();
        if (!player.level().isClientSide()) {
            String uuidStr = event.getPlayerUUID();
            UUID uuid = UUID.fromString(uuidStr);
            File file = event.getPlayerFile("heartsystem");
            int hearts = LifestealparrotmodMod.storage.getHearts(uuid);
            if (hearts < 0) {
                hearts = LifestealparrotmodMod.config.getStartHearts();
            }
            LifestealparrotmodMod.storage.save(uuidStr, file, hearts);
        }
    }

    public void onPlayerClone(PlayerEvent.Clone event) {
        Player newPlayer = event.getEntity();
        if (!newPlayer.level().isClientSide()) {
            if (event.isWasDeath()) {
                UUID uuid = newPlayer.getUUID();
                if (LifestealparrotmodMod.storage.has(uuid)) {
                    if (newPlayer instanceof ServerPlayer) {
                        int hearts = LifestealparrotmodMod.storage.getHearts(uuid);
                        HeartData.applyMaxHealth((ServerPlayer) newPlayer, hearts);
                    }
                }
            }
        }
    }

    public void onLivingDeath(LivingDeathEvent event) {
        if (!event.getEntity().level().isClientSide()) {
            if (event.getEntity() instanceof ServerPlayer deadPlayer) {
                UUID deadUUID = deadPlayer.getUUID();
                int hearts = LifestealparrotmodMod.storage.getHearts(deadUUID);
                if (hearts < 0) {
                    hearts = LifestealparrotmodMod.config.getStartHearts();
                }

                hearts--;
                int min = LifestealparrotmodMod.config.getMinHearts();
                if (hearts <= min) {
                    // Ban the player permanently
                    MinecraftServer server = deadPlayer.getServer();
                    if (server != null) {
                        GameProfile profile = deadPlayer.getGameProfile();
                        UserBanList banList = server.getPlayerList().getBans();
                        UserBanListEntry entry = new UserBanListEntry(profile, null, "Permadeath", null, "ran out of hearts");
                        banList.add(entry);
                        deadPlayer.connection.disconnect(Component.literal("Permadeath: ran out of hearts"));
                    }
                    // Prevent saving hearts below min (optional, but set to min anyway)
                    hearts = min;
                } else {
                    // Apply new heart count
                    HeartData.applyMaxHealth(deadPlayer, hearts);
                }

                // Update storage
                LifestealparrotmodMod.storage.setHearts(deadUUID, hearts);

                // Check if the killer is a player and give them a heart
                DamageSource source = event.getSource();
                Entity killer = source.getEntity();
                if (killer instanceof ServerPlayer killerPlayer) {
                    UUID killerUUID = killerPlayer.getUUID();
                    int killerHearts = LifestealparrotmodMod.storage.getHearts(killerUUID);
                    if (killerHearts < 0) {
                        killerHearts = LifestealparrotmodMod.config.getStartHearts();
                    }
                    int max = LifestealparrotmodMod.config.getMaxHearts();
                    if (killerHearts < max) {
                        killerHearts++;
                        LifestealparrotmodMod.storage.setHearts(killerUUID, killerHearts);
                        HeartData.applyMaxHealth(killerPlayer, killerHearts);
                    }
                }
            }
        }
    }
}