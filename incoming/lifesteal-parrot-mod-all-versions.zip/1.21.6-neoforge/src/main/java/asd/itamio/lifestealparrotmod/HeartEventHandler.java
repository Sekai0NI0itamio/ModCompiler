package asd.itamio.lifestealparrotmod;

import com.mojang.authlib.GameProfile;
import net.minecraft.network.chat.Component;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.server.players.UserBanList;
import net.minecraft.server.players.UserBanListEntry;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.player.Player;
import net.neoforged.neoforge.event.entity.living.LivingDeathEvent;
import net.neoforged.neoforge.event.entity.player.PlayerEvent;

import java.io.File;
import java.util.Date;
import java.util.UUID;

public class HeartEventHandler {

    public void onPlayerLoad(PlayerEvent.LoadFromFile event) {
        Player player = event.getEntity();
        if (player.level().isClientSide()) return;
        String uuidStr = event.getPlayerUUID();
        File file = event.getPlayerFile("heartsystem");
        int loaded = HeartStorage.get().load(uuidStr, file);
        if (loaded < 0) {
            HeartStorage.get().setHearts(UUID.fromString(uuidStr), LifestealparrotmodMod.CONFIG.getStartHearts());
        }
    }

    public void onPlayerSave(PlayerEvent.SaveToFile event) {
        Player player = event.getEntity();
        if (player.level().isClientSide()) return;
        String uuidStr = event.getPlayerUUID();
        UUID uuid = UUID.fromString(uuidStr);
        File file = event.getPlayerFile("heartsystem");
        int hearts = HeartStorage.get().getHearts(uuid);
        if (hearts < 0) {
            hearts = LifestealparrotmodMod.CONFIG.getStartHearts();
        }
        HeartStorage.get().save(uuidStr, file, hearts);
    }

    public void onPlayerClone(PlayerEvent.Clone event) {
        Player newPlayer = event.getEntity();
        if (newPlayer.level().isClientSide()) return;
        if (event.isWasDeath()) {
            UUID uuid = newPlayer.getUUID();
            if (HeartStorage.get().has(uuid)) {
                if (newPlayer instanceof ServerPlayer sp) {
                    int hearts = HeartStorage.get().getHearts(uuid);
                    HeartData.applyMaxHealth(sp, hearts);
                }
            }
        }
    }

    public void onLivingDeath(LivingDeathEvent event) {
        if (event.getEntity().level().isClientSide()) return;
        if (!(event.getEntity() instanceof ServerPlayer deadPlayer)) return;

        UUID deadUUID = deadPlayer.getUUID();
        int hearts = HeartStorage.get().getHearts(deadUUID);
        if (hearts < 0) {
            hearts = LifestealparrotmodMod.CONFIG.getStartHearts();
        }

        hearts--;
        int min = LifestealparrotmodMod.CONFIG.getMinHearts();
        if (hearts < min) hearts = min; // clamp

        HeartStorage.get().setHearts(deadUUID, hearts);

        // Ban if at or below minimum
        if (hearts <= min) {
            MinecraftServer server = deadPlayer.getServer();
            if (server != null) {
                UserBanList banList = server.getPlayerList().getBans();
                GameProfile profile = deadPlayer.getGameProfile();
                UserBanListEntry entry = new UserBanListEntry(profile, null, "Permadeath", null,
                        "Permadeath: ran out of hearts");
                banList.add(entry);
                deadPlayer.connection.disconnect(Component.literal("Permadeath: ran out of hearts"));
            }
        }

        // Apply health change to dead player
        HeartData.applyMaxHealth(deadPlayer, hearts);

        // Killer gains a heart
        DamageSource source = event.getSource();
        if (source.getEntity() instanceof ServerPlayer killer && killer != deadPlayer) {
            UUID killerUUID = killer.getUUID();
            int killerHearts = HeartStorage.get().getHearts(killerUUID);
            if (killerHearts < 0) {
                killerHearts = LifestealparrotmodMod.CONFIG.getStartHearts();
            }
            killerHearts++;
            int max = LifestealparrotmodMod.CONFIG.getMaxHearts();
            if (killerHearts > max) killerHearts = max;
            HeartStorage.get().setHearts(killerUUID, killerHearts);
            HeartData.applyMaxHealth(killer, killerHearts);
        }
    }
}