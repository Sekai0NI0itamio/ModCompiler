package asd.itamio.lifestealparrotmod;

import net.fabricmc.fabric.api.entity.event.v1.ServerLivingEvents;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.ServerLevel;

public class LifestealEventHandler {
    public LifestealEventHandler() {
        ServerLivingEvents.LIVING_DEATH.register(this::onLivingDeath);
    }

    private void onLivingDeath(LivingEntity entity, Entity source) {
        if (entity instanceof ServerPlayer player) {
            // Lose a heart on death
            int hearts = HeartStorage.get().getHearts(player.getUUID());
            hearts--;
            HeartStorage.get().setHearts(player.getUUID(), hearts);
            // Check for permadeath
            if (hearts <= 0) {
                // Ban player
                ServerLevel level = (ServerLevel) player.level();
                level.getServer().getPlayerList().getBans().add(new UserBanListEntry(player.getGameProfile(), null, null, null, "Permadeath: ran out of hearts"));
                player.connection.disconnect(Component.literal("You have been permanently banned."));
            }
        }
        if (source instanceof ServerPlayer killer) {
            // Gain a heart on kill
            int hearts = HeartStorage.get().getHearts(killer.getUUID());
            hearts++;
            HeartStorage.get().setHearts(killer.getUUID(), hearts);
            // Update max health
            AttributeInstance attr = killer.getAttribute(Attributes.MAX_HEALTH);
            if (attr != null) {
                attr.removeModifier(LifestealparrotmodMod.MOD_ID);
                attr.addPermanentModifier(new AttributeModifier(LifestealparrotmodMod.MOD_ID, "heartsystem.maxhealth", (double) hearts * 2.0 - 20.0, Operation.ADD_VALUE));
            }
        }
    }
}