package asd.itamio.lifestealparrotmod;

import net.fabricmc.api.ClientModInitializer;

public class ExampleModClient implements ClientModInitializer {
	@Override
	public void onInitializeClient() {
		// This entrypoint is suitable for setting up client-specific logic.
		// No client logic needed for this server-side mod.
	}
}