package asd.itamio.lifestevalparrotmod;

import java.util.UUID;
import java.util.Objects;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.ai.attributes.AttributeInstance;
import net.minecraft.core.registries.BuiltInRegistries;  // needed for modifier?? no — we use vanilla
import net.minecraft.world.entity.ai.attributes.Attributes;

import net.minecraft.world.entity.ai.attributes.AttributeModifier;
import net.minecraft.world.entity.ai.attributes.AttributeModifier.Operation;

public class HeartData {
    private static final UUID MODIFIER_UUID = UUID.fromString("a1b2c3d4-…");  // example UUID

    public static void applyMaxHealth(ServerPlayer player, int hearts) {
        AttributeInstance attr = player.getAttribute(Attributes.MAX_HEALTH);
        if (attr != null) {
            if (attr.getModifier(MODIFIER_UUID) != null) {
                attr.removeModifier(MODIFIER_UUID);
            }
            AttributeModifier mod = new AttributeModifier(
                UUID.fromString("…),
                "heartsystem.maxhealth",
                hearts * 2.0 - 20.0,
                Operation.ADD_VALUE
            );
            attr.addPermanentModifier(mod);
            float newMax = hearts * 2;
            if (player.getHealth() > newMax) {
                players.setHealth(newMax);
            }
        }
        player.setMaxHeartValue(hearts);
    }
}