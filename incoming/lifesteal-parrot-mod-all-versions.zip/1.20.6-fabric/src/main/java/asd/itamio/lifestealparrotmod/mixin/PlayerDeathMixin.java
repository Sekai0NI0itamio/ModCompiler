package asd.itamio.lifestealparrotmod.mixin;

import asd.itamio.lifestealparrotmod.HeartConfig;
import asd.itamio.lifestealparrotmod.HeartData;
import asd.itamio.lifestealparrotmod.HeartStorage;
import asd.itamio.lifestealparrotmod.LifestealparrotmodMod;
import com.mojang.authlib.GameProfile;
import net.minecraft.entity.Entity;
import net.minecraft.entity.damage.DamageSource;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.network.packet.s2c.play.DisconnectS2CPacket;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.text.Text;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.util.UUID;

@Mixin(PlayerEntity.class)
public class PlayerDeathMixin {
    @Inject(method = "onDeath", at = @At("HEAD"))
    private void onPlayerDeath(DamageSource source, CallbackInfo ci) {
        PlayerEntity self = (PlayerEntity) (Object) this;
        if (!self.getWorld().isClient) {
            if (self instanceof ServerPlayerEntity deadPlayer) {
                HeartConfig config = LifestealparrotmodMod.config;
                if (config != null) {
                    UUID deadUUID = deadPlayer.getUuid();
                    int hearts = HeartStorage.get().getHearts(deadUUID);
                    if (hearts < 0) {
                        hearts = config.getStartHearts();
                    }

                    hearts--;
                    int min = config.getMinHearts();
                    if (hearts <= min) {
                        HeartStorage.get().setHearts(deadUUID, min);
                        MinecraftServer server = deadPlayer.getServer();
                        if (server != null) {
                            Text banMessage = Text.literal("§c[Lifesteal] " + deadPlayer.getName().getString() + " has been permanently banned (0 hearts).");
                            server.getPlayerManager().getPlayerList().forEach(p -> p.sendMessage(banMessage, false));
                            
                            GameProfile profile = new GameProfile(deadUUID, deadPlayer.getName().getString());
                            server.getPlayerManager().getUserBanList().add(profile);
                            
                            deadPlayer.networkHandler.sendPacket(
                                new DisconnectS2CPacket(Text.literal("§cYou have been permanently banned.\nYou ran out of hearts."))
                            );
                        }
                    } else {
                        HeartStorage.get().setHearts(deadUUID, hearts);
                        deadPlayer.sendMessage(Text.literal("§c[Lifesteal] You lost a heart! Hearts remaining: " + hearts), false);
                    }

                    Entity killer = source.getAttacker();
                    if (killer instanceof ServerPlayerEntity killerPlayer) {
                        UUID killerUUID = killerPlayer.getUuid();
                        int killerHearts = HeartStorage.get().getHearts(killerUUID);
                        if (killerHearts < 0) {
                            killerHearts = config.getStartHearts();
                        }

                        int max = config.getMaxHearts();
                        if (killerHearts < max) {
                            HeartStorage.get().setHearts(killerUUID, ++killerHearts);
                            HeartData.applyMaxHealth(killerPlayer, killerHearts);
                            killerPlayer.sendMessage(Text.literal("§a[Lifesteal] You gained a heart! Hearts: " + killerHearts), false);
                        } else {
                            killerPlayer.sendMessage(
                                Text.literal("§e[Lifesteal] You killed a player but are already at max hearts (" + max + ")."), false
                            );
                        }
                    }
                }
            }
        }
    }
}