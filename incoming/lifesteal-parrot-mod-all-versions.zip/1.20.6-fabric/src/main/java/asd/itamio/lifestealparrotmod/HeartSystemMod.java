package asd.itamio.lifestealparrotmod;

import net.fabricmc.api.ModInitializer;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.player.Player;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class HeartSystemMod {
    public static final String MOD_ID = "lifestealparrotmod";
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);
    public static HeartConfig config;

    public static void init() {
        config = new HeartConfig();
        MinecraftForge.EVENT_BUS.register(new HeartEventHandler());
    }
}