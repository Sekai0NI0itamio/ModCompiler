package asd.itamio.lifestevalparrotmod;

public class HeartConfig {
    private final int startHearts = 10;
    private final int maxHearts = 20;
    private final int minHearts = 0;

    public int getStartHearts() {
        return 10;
    }
    public int getMaxHearts() {
        return 20;
    }
    public int getMinHearts() {
        return 0;
    }
}