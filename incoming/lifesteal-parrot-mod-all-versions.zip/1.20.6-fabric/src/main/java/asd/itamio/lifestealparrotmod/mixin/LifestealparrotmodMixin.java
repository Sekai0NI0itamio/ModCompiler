package asd.itamio.lifestealparrotmod.mixin;

import net.minecraft.server.network.ServerPlayerEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(ServerPlayerEntity.class)
public class LifestealparrotmodMixin {
    @Inject(method = "onDeath", at = @At("TAIL"))
    private void onDeath(CallbackInfo ci) {
        // Events handled via Fabric API
    }
}