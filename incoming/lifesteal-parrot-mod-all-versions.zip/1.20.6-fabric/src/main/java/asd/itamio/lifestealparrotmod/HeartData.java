package asd.itamio.lifestealparrotmod;

import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.server.network.ServerPlayerEntity;

public class HeartData {

    /**
     * Apply the given number of hearts (health points) to a player.
     * Each heart = 2 health points.
     */
    public static void applyMaxHealth(ServerPlayerEntity player, int hearts) {
        double health = hearts * 2.0;
        // Set max health attribute
        player.getAttributeInstance(EntityAttributes.GENERIC_MAX_HEALTH).setBaseValue(health);
        // If current health > new max, reduce it
        if (player.getHealth() > health) {
            player.setHealth((float) health);
        }
    }
}