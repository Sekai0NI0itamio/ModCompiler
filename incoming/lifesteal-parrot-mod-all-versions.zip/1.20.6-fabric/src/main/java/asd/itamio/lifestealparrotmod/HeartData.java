package asd.itamio.lifestealparrotmod;

import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.entity.attribute.AttributeInstance;
import net.minecraft.entity.attribute.AttributeModifier;
import net.minecraft.entity.attribute.EntityAttributes;
import java.util.UUID;

public class HeartData {
    private static final UUID MODIFIER_UUID = UUID.fromString("a1b2c3d4-e5f6-7890-abcd-ef1234567890");
    private static final String MODIFIER_NAME = "heartsystem.maxhealth";

    public static void applyMaxHealth(PlayerEntity player, int hearts) {
        AttributeInstance attr = player.getAttributeInstance(EntityAttributes.MAX_HEALTH);
        if (attr != null) {
            if (attr.getModifier(MODIFIER_UUID) != null) {
                attr.removeModifier(MODIFIER_UUID);
            }

            double delta = (double)hearts * 2.0 - 20.0;
            AttributeModifier mod = new AttributeModifier(MODIFIER_UUID, MODIFIER_NAME, delta, AttributeModifier.Operation.ADD_VALUE);
            attr.addPermanentModifier(mod);
            float newMax = (float)(hearts * 2);
            if (player.getHealth() > newMax) {
                player.setHealth(newMax);
            }
        }
    }
}