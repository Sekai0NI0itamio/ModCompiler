package asd.itamio.lifestealparrotmod;

import net.minecraft.server.network.ServerPlayerEntity;

public class HeartData {
    public static void applyMaxHealth(ServerPlayerEntity player, int hearts) {
        ExampleMod.applyMaxHealth(player, hearts);
    }
}