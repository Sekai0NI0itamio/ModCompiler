package asd.itamio.lifestealparrotmod;

// Utility class no longer needed; functionality moved to ExampleMod.applyMaxHealth
// Keep as placeholder for compatibility if any other class references it
import net.minecraft.server.network.ServerPlayerEntity;

public class HeartData {
    public static void applyMaxHealth(ServerPlayerEntity player, int hearts) {
        ExampleMod.applyMaxHealth(player, hearts);
    }
}