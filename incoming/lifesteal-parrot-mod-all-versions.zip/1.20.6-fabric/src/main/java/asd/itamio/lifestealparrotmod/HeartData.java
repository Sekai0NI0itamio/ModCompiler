package asd.itamio.lifestealparrotmod;

import net.minecraft.entity.attribute.AttributeContainer;
import net.minecraft.entity.attribute.AttributeInstance;
import net.minecraft.entity.attribute.AttributeModifier;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.server.network.ServerPlayerEntity;

import java.util.UUID;

public class HeartData {
	private static final UUID MODIFIER_UUID = UUID.fromString("a1b2c3d4-e5f6-7890-abcd-ef1234567890");
	private static final String MODIFIER_NAME = "lifestealparrotmod.maxhealth";

	public static void applyMaxHealth(ServerPlayerEntity player, int hearts) {
		AttributeContainer container = player.getAttributes();
		AttributeInstance attr = container.getCustomInstance(EntityAttributes.GENERIC_MAX_HEALTH);
		if (attr != null) {
			// Remove old modifier if present
			if (attr.getModifier(MODIFIER_UUID) != null) {
				attr.removeModifier(MODIFIER_UUID);
			}

			// Calculate delta: base max health is 20.0 (10 hearts). Each heart adds 2.0 HP.
			double delta = hearts * 2.0 - 20.0;
			AttributeModifier mod = new AttributeModifier(MODIFIER_UUID, MODIFIER_NAME, delta, AttributeModifier.Operation.ADD_VALUE);
			attr.addPersistentModifier(mod);

			// Clamp current health if needed
			float newMax = hearts * 2.0f;
			if (player.getHealth() > newMax) {
				player.setHealth(newMax);
			}
		}
	}
}