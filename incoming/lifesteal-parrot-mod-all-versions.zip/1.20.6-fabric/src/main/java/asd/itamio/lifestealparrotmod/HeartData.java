package asd.itamio.lifestealparrotmod;

import net.minecraft.entity.attribute.EntityAttributeInstance;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.server.network.ServerPlayerEntity;
import java.util.UUID;

public class HeartData {
    private static final UUID MODIFIER_UUID = UUID.fromString("a1b2c3d4-e5f6-7890-abcd-ef1234567890");
    private static final String MODIFIER_NAME = "lifesteal.maxhealth";

    public static void applyMaxHealth(ServerPlayerEntity player, int hearts) {
        EntityAttributeInstance attr = player.getAttributeInstance(EntityAttributes.GENERIC_MAX_HEALTH);
        if (attr != null) {
            if (attr.getModifier(MODIFIER_UUID) != null) {
                attr.removeModifier(MODIFIER_UUID);
            }

            double delta = (hearts * 2.0) - 20.0;
            net.minecraft.entity.attribute.EntityAttributeModifier mod = 
                new net.minecraft.entity.attribute.EntityAttributeModifier(
                    MODIFIER_UUID, MODIFIER_NAME, delta, 
                    net.minecraft.entity.attribute.EntityAttributeModifier.Operation.ADD_VALUE
                );
            attr.addPersistentModifier(mod);

            float newMax = hearts * 2.0f;
            if (player.getHealth() > newMax) {
                player.setHealth(newMax);
            }
        }
    }
}