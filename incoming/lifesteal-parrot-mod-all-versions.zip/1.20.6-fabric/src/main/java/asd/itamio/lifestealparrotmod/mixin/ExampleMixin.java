package asd.itamio.lifestealparrotmod.mixin;

import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.entity.damage.DamageSource;
import net.minecraft.text.Text;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import asd.itamio.lifestealparrotmod.HeartEventHandler;

@Mixin(ServerPlayerEntity.class)
public class ExampleMixin {
	@Inject(method = "onDeath", at = @At("TAIL"))
	private void onPlayerDeath(DamageSource source, CallbackInfo ci) {
		ServerPlayerEntity player = (ServerPlayerEntity) (Object) this;
		// Only process if the player is actually dead (health <= 0)
		if (player.getHealth() <= 0.0f) {
			HeartEventHandler.onPlayerDeath(player, source);
		}
	}
}