package asd.itamio.lifestealparrotmod;

import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.server.network.ServerPlayerEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.util.UUID;

@Mixin(PlayerEntity.class)
public abstract class ExampleMixin {

    @Unique
    private int lifestealHearts = -1;

    @Inject(method = "readCustomDataFromNbt", at = @At("TAIL"))
    private void onReadNbt(NbtCompound nbt, CallbackInfo ci) {
        if (nbt.contains("lifestealHearts")) {
            lifestealHearts = nbt.getInt("lifestealHearts");
        } else {
            lifestealHearts = -1;
        }
        // Sync to storage and apply health if server
        PlayerEntity player = (PlayerEntity) (Object) this;
        if (!player.getWorld().isClient && player instanceof ServerPlayerEntity serverPlayer) {
            UUID uuid = serverPlayer.getUuid();
            if (lifestealHearts >= 0) {
                HeartStorage.setHearts(uuid, lifestealHearts);
                ExampleMod.applyMaxHealth(serverPlayer, lifestealHearts);
            } else {
                int start = HeartConfig.getStartHearts();
                HeartStorage.setHearts(uuid, start);
                ExampleMod.applyMaxHealth(serverPlayer, start);
            }
        }
    }

    @Inject(method = "writeCustomDataToNbt", at = @At("TAIL"))
    private void onWriteNbt(NbtCompound nbt, CallbackInfo ci) {
        PlayerEntity player = (PlayerEntity) (Object) this;
        UUID uuid = player.getUuid();
        int hearts = HeartStorage.getHearts(uuid);
        if (hearts < 0) {
            hearts = HeartConfig.getStartHearts();
        }
        nbt.putInt("lifestealHearts", hearts);
    }
}