package asd.itamio.lifestealparrotmod;

import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.nbt.NbtCompound;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.util.UUID;

@Mixin(PlayerEntity.class)
public abstract class ExampleMixin {

    @Unique
    private int lifestealHearts = -1;

    @Inject(method = "readCustomDataFromNbt", at = @At("TAIL"))
    private void onReadNbt(NbtCompound nbt, CallbackInfo ci) {
        if (nbt.contains("lifestealHearts")) {
            lifestealHearts = nbt.getInt("lifestealHearts");
        } else {
            lifestealHearts = -1;
        }
        // Sync to static storage for server logic
        if (!((PlayerEntity)(Object)this).getWorld().isClient) {
            UUID uuid = ((PlayerEntity)(Object)this).getUuid();
            if (lifestealHearts >= 0) {
                HeartStorage.setHearts(uuid, lifestealHearts);
            } else {
                // New player, set default hearts
                HeartStorage.setHearts(uuid, HeartConfig.getStartHearts());
            }
        }
    }

    @Inject(method = "writeCustomDataToNbt", at = @At("TAIL"))
    private void onWriteNbt(NbtCompound nbt, CallbackInfo ci) {
        UUID uuid = ((PlayerEntity)(Object)this).getUuid();
        int hearts = HeartStorage.getHearts(uuid);
        if (hearts < 0) {
            hearts = HeartConfig.getStartHearts();
        }
        nbt.putInt("lifestealHearts", hearts);
    }
}