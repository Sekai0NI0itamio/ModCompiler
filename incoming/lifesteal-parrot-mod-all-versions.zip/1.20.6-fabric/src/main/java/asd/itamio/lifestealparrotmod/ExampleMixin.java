package asd.itamio.lifestealparrotmod;

import net.minecraft.nbt.CompoundTag;
import net.minecraft.world.entity.player.Player;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(Player.class)
public abstract class ExampleMixin {

    @Unique
    private int lifestealHearts = -1;

    @Inject(method = "readAdditionalSaveData", at = @At("TAIL"))
    private void onReadNbt(CompoundTag nbt, CallbackInfo ci) {
        if (nbt.contains("lifestealHearts")) {
            lifestealHearts = nbt.getInt("lifestealHearts");
        } else {
            lifestealHearts = -1;
        }
        // Sync to static storage for server logic
        if (!((Player)(Object)this).level().isClientSide) {
            java.util.UUID uuid = ((Player)(Object)this).getUUID();
            if (lifestealHearts >= 0) {
                HeartStorage.setHearts(uuid, lifestealHearts);
            } else {
                // New player, set default hearts
                HeartStorage.setHearts(uuid, HeartConfig.getStartHearts());
            }
        }
    }

    @Inject(method = "addAdditionalSaveData", at = @At("TAIL"))
    private void onWriteNbt(CompoundTag nbt, CallbackInfo ci) {
        java.util.UUID uuid = ((Player)(Object)this).getUUID();
        int hearts = HeartStorage.getHearts(uuid);
        if (hearts < 0) {
            hearts = HeartConfig.getStartHearts();
        }
        nbt.putInt("lifestealHearts", hearts);
    }
}