package asd.itamio.lifestealparrotmod;

import com.mojang.authlib.GameProfile;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.damage.DamageSource;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.ban.UserBanList;
import net.minecraft.server.ban.UserBanListEntry;
import net.minecraft.text.Text;
import net.minecraft.world.World;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.LocalCapture;

import java.util.UUID;

@Mixin(LivingEntity.class)
public abstract class ExampleMixin {
    @Inject(method = "onDeath", at = @At("HEAD"))
    private void onDeath(DamageSource source, CallbackInfo ci, LocalCapture captor) {
        LivingEntity entity = (LivingEntity) (Object) this;
        if (!entity.getWorld().isClient && entity instanceof ServerPlayerEntity deadPlayer) {
            handlePlayerDeath(deadPlayer, source);
        }
    }

    @Unique
    private void handlePlayerDeath(ServerPlayerEntity deadPlayer, DamageSource source) {
        MinecraftServer server = deadPlayer.getServer();
        if (server == null) return;

        ExampleMod.getStorage().load(server);
        UUID deadUUID = deadPlayer.getUuid();
        int hearts = ExampleMod.getStorage().getHearts(deadUUID);
        if (hearts < 0) {
            hearts = ExampleMod.CONFIG.getStartHearts();
        }
        hearts--;
        int min = ExampleMod.CONFIG.getMinHearts();
        if (hearts <= min) {
            // Permadeath – ban player
            ExampleMod.getStorage().setHearts(deadUUID, min);
            ExampleMod.getStorage().save(server);

            // Broadcast message
            Text msg = Text.literal("§c[HeartSystem] " + deadPlayer.getName().getString() + " has been permanently banned (0 hearts).");
            server.getPlayerManager().getPlayerList().forEach(p -> p.sendMessage(msg, false));

            // Add to ban list
            UserBanList banList = server.getPlayerManager().getUserBanList();
            GameProfile profile = new GameProfile(deadUUID, deadPlayer.getName().getString());
            UserBanListEntry entry = new UserBanListEntry(profile, null, "HeartSystem", null, "Permadeath: ran out of hearts");
            banList.add(entry);

            // Disconnect
            deadPlayer.networkHandler.disconnect(Text.literal("§cYou have been permanently banned.\nYou ran out of hearts."));
        } else {
            ExampleMod.getStorage().setHearts(deadUUID, hearts);
            deadPlayer.sendMessage(Text.literal("§c[HeartSystem] You lost a heart! Hearts remaining: " + hearts), false);

            // Killer gains a heart
            Entity killer = source.getAttacker();
            if (killer instanceof ServerPlayerEntity killerPlayer) {
                UUID killerUUID = killerPlayer.getUuid();
                int killerHearts = ExampleMod.getStorage().getHearts(killerUUID);
                if (killerHearts < 0) {
                    killerHearts = ExampleMod.CONFIG.getStartHearts();
                }
                int max = ExampleMod.CONFIG.getMaxHearts();
                if (killerHearts < max) {
                    killerHearts++;
                    ExampleMod.getStorage().setHearts(killerUUID, killerHearts);
                    ExampleMod.HeartData.applyMaxHealth(killerPlayer, killerHearts);
                    killerPlayer.sendMessage(Text.literal("§a[HeartSystem] You gained a heart! Hearts: " + killerHearts), false);
                } else {
                    killerPlayer.sendMessage(Text.literal("§e[HeartSystem] You killed a player but are already at max hearts (" + max + ")."), false);
                }
            }
        }
        ExampleMod.getStorage().save(server);
    }

    @Inject(method = "tick", at = @At("HEAD"))
    private void tick(CallbackInfo ci) {
        // No action needed here; respawn handled separately
    }
}