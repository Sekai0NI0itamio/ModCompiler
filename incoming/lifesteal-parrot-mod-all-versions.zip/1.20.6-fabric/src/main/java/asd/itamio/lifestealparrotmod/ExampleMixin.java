package asd.itamio.lifestealparrotmod;

import com.mojang.authlib.GameProfile;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.damage.DamageSource;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.players.UserBanList;
import net.minecraft.server.players.UserBanListEntry;
import net.minecraft.text.Text;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.util.Date;
import java.util.UUID;

@Mixin(LivingEntity.class)
public abstract class ExampleMixin {

    @Inject(method = "onDeath", at = @At("HEAD"))
    private void onDeath(DamageSource source, CallbackInfo ci) {
        LivingEntity entity = (LivingEntity) (Object) this;
        if (!entity.getWorld().isClient && entity instanceof ServerPlayerEntity player) {
            handlePlayerDeath(player, source);
        }
    }

    @Unique
    private void handlePlayerDeath(ServerPlayerEntity deadPlayer, DamageSource source) {
        MinecraftServer server = deadPlayer.getServer();
        if (server == null) return;

        ExampleMod.getStorage().load(server);
        UUID deadUUID = deadPlayer.getUuid();

        // Get current hearts, default to start hearts if not yet set
        int hearts = ExampleMod.getStorage().getHearts(deadUUID);
        if (hearts < 0) {
            hearts = ExampleMod.CONFIG.getStartHearts();
        }
        hearts--;

        int min = ExampleMod.CONFIG.getMinHearts();
        if (hearts <= min) {
            // Permadeath – ban player
            ExampleMod.getStorage().setHearts(deadUUID, min);
            ExampleMod.getStorage().save(server);

            // Broadcast message
            Text msg = Text.literal("§c[HeartSystem] " + deadPlayer.getName().getString() + " has been permanently banned (0 hearts).");
            server.getPlayerManager().getPlayerList().forEach(p -> p.sendMessage(msg, false));

            // Add to ban list
            UserBanList banList = server.getPlayerManager().getUserBanList();
            GameProfile profile = new GameProfile(deadUUID, deadPlayer.getName().getString());
            UserBanListEntry entry = new UserBanListEntry(profile, null, "HeartSystem", null, "Permadeath: ran out of hearts");
            banList.add(entry);

            // Disconnect player
            deadPlayer.networkHandler.disconnect(Text.literal("§cYou have been permanently banned.\nYou ran out of hearts."));
        } else {
            ExampleMod.getStorage().setHearts(deadUUID, hearts);
            ExampleMod.getStorage().save(server);
            deadPlayer.sendMessage(Text.literal("§c[HeartSystem] You lost a heart! Hearts remaining: " + hearts), false);

            // Killer gains a heart if killed by another player
            Entity killer = source.getAttacker();
            if (killer instanceof ServerPlayerEntity killerPlayer) {
                UUID killerUUID = killerPlayer.getUuid();
                int killerHearts = ExampleMod.getStorage().getHearts(killerUUID);
                if (killerHearts < 0) {
                    killerHearts = ExampleMod.CONFIG.getStartHearts();
                }
                killerHearts++;
                int max = ExampleMod.CONFIG.getMaxHearts();
                if (killerHearts > max) {
                    killerHearts = max;
                }
                ExampleMod.getStorage().setHearts(killerUUID, killerHearts);
                killerPlayer.sendMessage(Text.literal("§a[HeartSystem] You gained a heart! Hearts: " + killerHearts), false);

                // Also sync max health for both players
                updateMaxHealth(deadPlayer, hearts);
                updateMaxHealth(killerPlayer, killerHearts);
            } else {
                updateMaxHealth(deadPlayer, hearts);
            }
            ExampleMod.getStorage().save(server);
        }
    }

    @Unique
    private void updateMaxHealth(ServerPlayerEntity player, int hearts) {
        // Set max health to hearts (2 health points per heart)
        float maxHealth = hearts * 2.0f;
        player.getAttributeInstance(net.minecraft.entity.attribute.EntityAttributes.GENERIC_MAX_HEALTH).setBaseValue(maxHealth);
        if (player.getHealth() > maxHealth) {
            player.setHealth(maxHealth);
        }
    }
}