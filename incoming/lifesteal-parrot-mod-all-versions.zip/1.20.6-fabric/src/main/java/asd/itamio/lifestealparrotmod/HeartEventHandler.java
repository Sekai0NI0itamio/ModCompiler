package asd.itamio.lifestealparrotmod;

import net.minecraft.entity.damage.DamageSource;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.text.Text;
import net.minecraft.server.players.UserBanList;
import net.minecraft.server.players.UserBanListEntry;
import com.mojang.authlib.GameProfile;

public class HeartEventHandler {
    public static void onPlayerDeath(ServerPlayerEntity deadPlayer, DamageSource source) {
        UUID deadUUID = deadPlayer.getUuid();
        HeartStorage storage = HeartStorage.get(deadPlayer);
        int hearts = storage.getHearts(deadUUID);
        if (hearts < 0) hearts = LifestealparrotmodMod.CONFIG.getStartHearts();

        hearts--;
        int min = LifestealparrotmodMod.CONFIG.getMinHearts();
        if (hearts <= min) {
            storage.setHearts(deadUUID, min);
            banPlayer(deadPlayer);
        } else {
            storage.setHearts(deadUUID, hearts);
            deadPlayer.sendMessage(Text.literal("§c[HeartSystem] You lost a heart! Remaining: " + hearts), false);
        }

        if (source.getAttacker() instanceof ServerPlayerEntity killer) {
            handleKill(killer);
        }
    }

    private static void banPlayer(ServerPlayerEntity player) {
        player.networkHandler.disconnect(Text.literal("§cPermadeath: ran out of hearts"));
        UserBanList banList = player.getServer().getPlayerManager().getUserBanList();
        banList.add(new UserBanListEntry(new GameProfile(player.getUuid(), player.getName().getString()), null, null, null, "Permadeath: ran out of hearts"));
    }

    private static void handleKill(ServerPlayerEntity killer) {
        UUID uuid = killer.getUuid();
        HeartStorage storage = HeartStorage.get(killer);
        int hearts = storage.getHearts(uuid);
        if (hearts < 0) hearts = LifestealparrotmodMod.CONFIG.getStartHearts();
        int max = LifestealparrotmodMod.CONFIG.getMaxHearts();
        if (hearts < max) {
            hearts++;
            storage.setHearts(uuid, hearts);
            HeartData.applyMaxHealth(killer, hearts);
            killer.sendMessage(Text.literal("§a[HeartSystem] You gained a heart! Hearts: " + hearts), false);
        }
    }
}