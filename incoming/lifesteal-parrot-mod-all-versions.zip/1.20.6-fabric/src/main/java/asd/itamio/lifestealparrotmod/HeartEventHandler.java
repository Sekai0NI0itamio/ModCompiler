package asd.itamio.lifestealparrotmod;

import com.mojang.authlib.GameProfile;
import net.minecraft.entity.damage.DamageSource;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.network.packet.s2c.play.DisconnectS2CPacket;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.ban.BanEntry;
import net.minecraft.text.Text;

import java.util.UUID;

public class HeartEventHandler {

    public static void onPlayerDeath(ServerPlayerEntity deadPlayer, DamageSource source) {
        HeartStorage storage = LifestealparrotmodMod.getStorage();
        HeartConfig config = LifestealparrotmodMod.getConfig();

        if (storage == null) return;

        UUID deadUUID = deadPlayer.getUuid();
        int hearts = storage.getHearts(deadUUID);

        // Decrease hearts by 1
        hearts--;
        int min = config.getMinHearts();

        if (hearts <= min) {
            storage.setHearts(deadUUID, min);
            // Permaban
            MinecraftServer server = deadPlayer.getServer();
            if (server != null) {
                Text banMessage = Text.literal("§cYou have been permanently banned.\nYou ran out of hearts.");
                BanEntry banEntry = new BanEntry(new GameProfile(deadUUID, deadPlayer.getName().getString()),
                        null, null, null, "Permadeath: ran out of hearts");
                server.getPlayerManager().getUserBanList().add(banEntry);
                deadPlayer.networkHandler.disconnect(banMessage);
            }
            return;
        }

        storage.setHearts(deadUUID, hearts);
        deadPlayer.sendMessage(Text.literal("§c[HeartSystem] You lost a heart! Hearts remaining: " + hearts), false);

        // Apply max health after death
        HeartData.applyMaxHealth(deadPlayer, hearts);

        // Check if killer is a player and give them a heart
        if (source.getAttacker() instanceof ServerPlayerEntity killerPlayer) {
            UUID killerUUID = killerPlayer.getUuid();
            int killerHearts = storage.getHearts(killerUUID);
            int max = config.getMaxHearts();

            if (killerHearts < max) {
                killerHearts++;
                storage.setHearts(killerUUID, killerHearts);
                HeartData.applyMaxHealth(killerPlayer, killerHearts);
                killerPlayer.sendMessage(Text.literal("§a[HeartSystem] You gained a heart! Hearts: " + killerHearts), false);
            } else {
                killerPlayer.sendMessage(Text.literal("§e[HeartSystem] You killed a player but are already at max hearts (" + max + ")."), false);
            }
        }
    }
}