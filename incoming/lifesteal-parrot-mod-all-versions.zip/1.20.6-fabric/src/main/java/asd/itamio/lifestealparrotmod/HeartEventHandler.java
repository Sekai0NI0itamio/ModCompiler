package asd.itamio.lifestealparrotmod;

// This class is no longer used; all event handling moved to ExampleMod
// Kept to avoid missing file error, but should not be compiled if not referenced.
// However, since it's in the source, we must either remove or leave empty.
// To avoid compilation errors, we replace with a minimal stub.
public class HeartEventHandler {
    // All logic moved to ExampleMod
}