package asd.itamio.lifestealparrotmod;

import net.minecraft.server.level.ServerPlayer;
import net.minecraft.server.players.UserBanList;
import net.minecraft.server.players.UserBanListEntry;
import net.minecraft.network.chat.Component;
import net.minecraft.world.damagesource.DamageSource;

import net.fabricmc.fabric.api.entity.event.v1.ServerPlayerEvents;

public class HeartEventHandler {
    public static void register() {
        ServerPlayerEvents.PLAYER_DEATH.register((player, source) -> {
            if (!player.level().isClientSide() && player instanceof ServerPlayer) {
                ServerPlayer deadPlayer = (ServerPlayer) player;
                UUID deadUUID = deadPlayer.getUUID();
                int hearts = HeartStorage.get().getHearts(deadUUID);
                if (hearts < 0) {
                    hearts = LifestealparrotmodMod.config.getStartHearts();
                }
                hearts--;
                int min = LifestealparrotmodMod.config.getMinHearts();
                if (hearts <= min) {
                    HeartStorage.get().setHearts(deadUUID, min);
                    // Ban player
                    UserBanList banList = player.getServer().getPlayerList().getBans();
                    banList.add(new UserBanListEntry(new GameProfile(deadUUID, deadPlayer.getName().getString()), null, null, null, "Permadeath: ran out of hearts"));
                    deadPlayer.connection.disconnect(Component.literal("§cYou have been permanently banned.\nYou ran out of hearts."));
                } else {
                    HeartStorage.get().setHearts(deadUUID, hearts);
                    deadPlayer.sendSystemMessage(Component.literal("§c[HeartSystem] You lost a heart! Hearts remaining: " + hearts));
                }
            }
        });

        ServerPlayerEvents.PLAYER_LOAD.register((player, data) -> {
            String uuidStr = player.getUUID().toString();
            File file = ((ServerPlayer) player).getPlayerFile("heartsystem"); 
            int loaded = HeartStorage.get().load(uuidStr, file);
            if (loaded < 0) {
                HeartStorage.get().setHearts(UUID.fromString(uuidStr), LifestealparrotmodMod.config.getStartHearts());
            }
            HeartData.applyMaxHealth((ServerPlayer) player, HeartStorage.get().getHearts(player.getUUID()));
        });

        ServerPlayerEvents.PLAYER_CLONE.register((oldPlayer, newPlayer, wasDeath) -> {
            if (!newPlayer.level().isClientSide() && wasDeath) {
                UUID uuid = newPlayer.getUUID();
                if (HeartStorage.get().has(uuid)) {
                    int hearts = HeartStorage.get().getHearts(uuid);
                    HeartData.applyMaxHealth((ServerPlayer) newPlayer, hearts);
                }
            }
        });
    }
}