package asd.itamio.lifestealparrotmod;

import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.server.players.UserBanList;
import net.minecraft.server.players.UserBanListEntry;
import net.minecraft.network.chat.Component;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.wolfpack.math.Vec3d;
import net.minecraft.util.UuidUtil;
import net.minecraft.util.Util;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.resources.ResourceKey;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.level.levelgen.structure.BoundingBox;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.chunk.Chunk;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.LightLayer;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.RenderShape;
import net.minecraft.world.level.block.state.properties.BlockStateProperties;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.BlockPlaceContext;
import net.minecraft.world.phys.Vec3;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.state.BlockBehaviour.Properties;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeLayout;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.properties.Properties;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.level.GameRules;
import net.minecraft.world.level.GameRules.ModifiableGameRule;
import net.minecraft.world.level.GameRules.Key;
import net.minecraft.world.level.GameRules.BooleanRule;
import net.minecraft.world.level.LightLayer;
import net.minecraft.server.level.ServerChunkCache;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraft.world.level.levelgen.structure.Structure;
import net.minecraft.world.level.block.state.pattern.BlockInWorld;
import net.minecraft.world.level.gameevent.Event;
import net.minecraft.world.level.gameevent.EventContexts;
import net.minecraft.world.level.block.LevelEvent;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.minecraft.world.level.blockstate.BlockState;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.blockstate.Blocks;
import net.minecraft.world.level.biome.ColorResolver;
import net.minecraft.world.level.biome.Biome;
import net.minecraft.world.level.biome.BiomeAccess;
import net.minecraft.world.level.EntityDataFixer;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.biome.BiomeDecorator;
import net.minecraft.world.level.entity.EntityInfo;
import net.minecraft.world.level.levelgen.structure.StructurePiece;
import net.minecraft.world.level.levelgen.structure.StructurePieceType;
import net.minecraft.world.level.levelgen.structure.StructurePieceType;
import net.minecraft.world.level.levelgen.structure.StructurePiece;
import net.minecraft.world.level.levelgen.structure.VoidStructurePiece;
import net.minecraft.world.level.levelgen.structure.StructurePieceTypes;
import net.minecraft.world.level.levelgen.structure.StructurePieceType;
import net.minecraft.world.level.levelgen.structure.StructurePieceTypes;
import net.minecraft.world.level.levelgen.structure.StructurePiece;
import net.minecraft.world.level.functions.Function;
import net.minecraft.world.level.gameevent.Event;
import net.fabricmc.fabric.api.event.player.PlayerBlockBreakEvents;
import net.fabricmc.fabric.api.event.player.PlayerCraftItemCallback;
import net.fabricmc.fabric.api.event.player.PlayerBlockBreakEvents;
import net.fabricmc.fabric.api.entity.event.v1.ServerLivingEvents;
import net.fabricmc.fabric.api.entity.event.v1.ServerPlayerEvents;

public class HeartEventHandler {
    private static final ConcurrentHashMap<UUID, Integer> HEARTS_MAP = new ConcurrentHashMap<>();
    private static final HeartConfig CONFIG = new HeartConfig();

    public static void registerEvents() {
        // Load hearts on player join
        ServerPlayerEvents.JOIN.register((ServerPlayer player) -> {
            UUID uuid = player.getUUID();
            CompoundTag tag = player.getPersistentData();
            int hearts = tag.getInt("hearts");
            if (hearts <= 0) {
                hearts = CONFIG.getStartHearts();
            }
            HEARTS_MAP.put(uuid, hearts);
            HeartData.applyMaxHealth(player, hearts);
        });

        // Apply hearts on respawn
        ServerPlayerEvents.AFTER_RESPAWN.register((ServerPlayer oldPlayer, ServerPlayer newPlayer, boolean alive) -> {
            if (newPlayer != null) {
                int hearts = HEARTS_MAP.getOrDefault(newPlayer.getUUID(), CONFIG.getStartHearts());
                HeartData.applyMaxHealth(newPlayer, hearts);
            }
        });

        // Handle death event
        ServerLivingEvents.DEATH.register((LivingEntity entity, DamageSource source, boolean alive) -> {
            if (!alive && entity instanceof ServerPlayer deadPlayer) {
                UUID deadUUID = deadPlayer.getUUID();
                int hearts = HEARTS_MAP.getOrDefault(deadUUID, CONFIG.getStartHearts());
                hearts--;

                // Persist hearts to player data
                CompoundTag persistentData = deadPlayer.getPersistentData();
                persistentData.putInt("hearts", hearts);

                int minHearts = CONFIG.getMinHearts();
                if (hearts <= minHearts) {
                    HEARTS_MAP.put(deadUUID, minHearts);
                    MinecraftServer server = deadPlayer.getServer();
                    if (server != null) {
                        Component msg = Component.literal("[Lifesteal] " + deadPlayer.getName().getString() + " has been permanently banned (0 hearts).");
                        server.getPlayerList().getPlayers().forEach(p -> p.sendSystemMessage(msg));
                        UserBanList banList = server.getPlayerList().getBans();
                        banList.add(
                            new UserBanListEntry(new com.mojang.authlib.GameProfile(deadUUID, deadPlayer.getName().getString()), null, null, null, "Permadeath: ran out of hearts")
                        );
                    }
                    deadPlayer.connection.disconnect(Component.literal("You have been permanently banned.\nYou ran out of hearts."));
                } else {
                    HEARTS_MAP.put(deadUUID, hearts);
                    deadPlayer.sendSystemMessage(Component.literal("[Lifesteal] You lost a heart! Hearts remaining: " + hearts));
                }

                // Award heart to killer if applicable
                Entity killer = source.getEntity();
                if (killer instanceof ServerPlayer killerPlayer) {
                    UUID killerUUID = killerPlayer.getUUID();
                    int killerHearts = HEARTS_MAP.getOrDefault(killerUUID, CONFIG.getStartHearts());
                    int maxHearts = CONFIG.getMaxHearts();
                    if (killerHearts < maxHearts) {
                        killerHearts++;
                        HEARTS_MAP.put(killerUUID, killerHearts);
                        killerPlayer.getPersistentData().putInt("hearts", killerHearts);
                        HeartData.applyMaxHealth(killerPlayer, killerHearts);
                        killerPlayer.sendSystemMessage(Component.literal("[Lifesteal] You gained a heart! Hearts: " + killerHearts));
                    } else {
                        killerPlayer.sendSystemMessage(Component.literal("[Lifesteal] You killed a player but are already at max hearts (" + maxHearts + ")."));
                    }
                }
            }
        });
    }
}