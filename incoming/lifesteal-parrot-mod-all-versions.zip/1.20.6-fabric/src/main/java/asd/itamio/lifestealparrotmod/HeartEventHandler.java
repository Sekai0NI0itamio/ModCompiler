package asd.itamio.lifestealparrotmod;

import net.fabricmc.fabric.api.entity.event.v1.ServerLivingEvents;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraftforge.eventbus.api.SubscribeEvent;

public class HeartEventHandler {
    @SubscribeEvent
    public void onLivingDeath(ServerLivingEvents.LivingDeathEvent event) {
        LivingEntity entity = event.getEntity();
        if (entity instanceof ServerPlayer) {
            ServerPlayer player = (ServerPlayer) entity;
            // ...
        }
    }
}