package asd.itamio.lifestealparrotmod;

// All logic moved to ExampleMod and mixins
public class HeartEventHandler {
}