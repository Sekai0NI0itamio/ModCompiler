package asd.itamio.lifestealparrotmod;

import com.mojang.authlib.GameProfile;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.ban.UserBanEntry;
import net.minecraft.text.Text;
import net.minecraft.world.World;

import java.util.UUID;

public class HeartEventHandler {
    // This class is called from the mixin upon player death
    public static void onPlayerDeath(ServerPlayerEntity player, net.minecraft.entity.damage.DamageSource damageSource) {
        if (player.getWorld().isClient) return;

        UUID deadUUID = player.getUuid();
        int hearts = HeartStorage.get().getHearts(deadUUID);
        if (hearts < 0) {
            hearts = ExampleMod.config.getStartHearts();
        }

        hearts--; // lose one heart

        int min = ExampleMod.config.getMinHearts();
        if (hearts <= min) {
            // Permadeath: ban and disconnect
            HeartStorage.get().setHearts(deadUUID, min);
            MinecraftServer server = player.getServer();
            if (server != null) {
                Text banMessage = Text.literal("§c[HeartSystem] " + player.getName().getString() + " has been permanently banned (0 hearts).");
                server.getPlayerManager().broadcast(banMessage, false);

                // Ban player
                GameProfile profile = player.getGameProfile();
                server.getPlayerManager().getUserBanList().add(
                        new UserBanEntry(profile, null, null, null, "Permadeath: ran out of hearts")
                );
            }
            player.networkHandler.disconnect(Text.literal("§cYou have been permanently banned.\nYou ran out of hearts."));
            return; // stop processing (player is already disconnecting)
        } else {
            HeartStorage.get().setHearts(deadUUID, hearts);
            player.sendMessage(Text.literal("§c[HeartSystem] You lost a heart! Hearts remaining: " + hearts), false);
        }

        // Give killer a heart
        net.minecraft.entity.Entity killer = damageSource.getAttacker();
        if (killer instanceof ServerPlayerEntity killerPlayer) {
            UUID killerUUID = killerPlayer.getUuid();
            int killerHearts = HeartStorage.get().getHearts(killerUUID);
            if (killerHearts < 0) {
                killerHearts = ExampleMod.config.getStartHearts();
            }

            int max = ExampleMod.config.getMaxHearts();
            if (killerHearts < max) {
                killerHearts++;
                HeartStorage.get().setHearts(killerUUID, killerHearts);
                HeartData.applyMaxHealth(killerPlayer, killerHearts);
                killerPlayer.sendMessage(Text.literal("§a[HeartSystem] You gained a heart! Hearts: " + killerHearts), false);
            } else {
                killerPlayer.sendMessage(Text.literal("§e[HeartSystem] You killed a player but are already at max hearts (" + max + ")."), false);
            }
        }
    }
}