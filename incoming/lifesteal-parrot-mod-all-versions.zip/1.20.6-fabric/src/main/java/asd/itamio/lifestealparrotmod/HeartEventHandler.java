package asd.itamio.lifestealparrotmod;

import net.minecraft.entity.damage.DamageSource;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.BannedPlayerList;
import net.minecraft.server.MinecraftServer;
import net.minecraft.text.Text;
import com.mojang.authlib.GameProfile;
import java.util.UUID;

public class HeartEventHandler {
    public static void onPlayerDeath(ServerPlayerEntity deadPlayer, DamageSource source) {
        UUID deadUUID = deadPlayer.getUuid();
        int hearts = HeartStorage.get().getHearts(deadUUID);
        if (hearts < 0) hearts = LifestealparrotmodMod.config.getStartHearts();

        hearts--;
        int min = LifestealparrotmodMod.config.getMinHearts();

        if (hearts <= min) {
            HeartStorage.get().setHearts(deadUUID, min);
            MinecraftServer server = deadPlayer.getServer();
            if (server != null) {
                BannedPlayerList banList = server.getPlayerManager().getUserBanList();
                banList.add(new net.minecraft.server.BannedPlayerEntry(
                    new GameProfile(deadUUID, deadPlayer.getName().getString()), null, null, null, "Permadeath: ran out of hearts"));
                server.getPlayerManager().broadcast(Text.literal("§c[HeartSystem] " + deadPlayer.getName().getString() + " has been permanently banned (0 hearts)."), false);
            }
            deadPlayer.networkHandler.disconnect(Text.literal("§cYou have been permanently banned.\nYou ran out of hearts."));
        } else {
            HeartStorage.get().setHearts(deadUUID, hearts);
            deadPlayer.sendMessage(Text.literal("§c[HeartSystem] You lost a heart! Hearts remaining: " + hearts), false);
        }

        PlayerEntity killer = source.getAttacker() instanceof PlayerEntity ? (PlayerEntity) source.getAttacker() : null;
        if (killer instanceof ServerPlayerEntity killerPlayer) {
            UUID killerUUID = killerPlayer.getUuid();
            int kHearts = HeartStorage.get().getHearts(killerUUID);
            if (kHearts < 0) kHearts = LifestealparrotmodMod.config.getStartHearts();
            int max = LifestealparrotmodMod.config.getMaxHearts();
            if (kHearts < max) {
                kHearts++;
                HeartStorage.get().setHearts(killerUUID, kHearts);
                HeartData.applyMaxHealth(killerPlayer, kHearts);
                killerPlayer.sendMessage(Text.literal("§a[HeartSystem] You gained a heart! Hearts: " + kHearts), false);
            }
        }
    }
}