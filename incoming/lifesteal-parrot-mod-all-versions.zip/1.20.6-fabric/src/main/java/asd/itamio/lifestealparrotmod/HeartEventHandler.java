package asd.itamio.lifestealparrotmod;

import com.mojang.authlib.GameProfile;
import java.io.File;
import java.util.UUID;
import net.minecraft.network.chat.Component;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.server.players.UserBanList;
import net.minecraft.server.players.UserBanListEntry;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.player.Player;
import net.minecraftforge.event.entity.living.LivingDeathEvent;
import net.minecraftforge.event.entity.player.PlayerEvent.Clone;
import net.minecraftforge.event.entity.player.PlayerEvent.LoadFromFile;
import net.minecraftforge.event.entity.player.PlayerEvent.SaveToFile;
import net.minecraftforge.eventbus.api.EventPriority;
import net.minecraftforge.eventbus.api.SubscribeEvent;

public class HeartEventHandler {
    @SubscribeEvent
    public void onPlayerLoad(LoadFromFile event) {
        Player player = event.getEntity();
        if (!player.level().isClientSide()) {
            String uuidStr = event.getPlayerUUID();
            File file = event.getPlayerFile("heartsystem");
            int loaded = HeartStorage.get().load(uuidStr, file);
            if (loaded < 0) {
                HeartStorage.get().setHearts(UUID.fromString(uuidStr), HeartSystemMod.config.getStartHearts());
            }
        }
    }

    @SubscribeEvent
    public void onPlayerSave(SaveToFile event) {
        Player player = event.getEntity();
        if (!player.level().isClientSide()) {
            String uuidStr = event.getPlayerUUID();
            UUID uuid = UUID.fromString(uuidStr);
            File file = event.getPlayerFile("heartsystem");
            int hearts = HeartStorage.get().getHearts(uuid);
            if (hearts < 0) {
                hearts = HeartSystemMod.config.getStartHearts();
            }

            HeartStorage.get().save(uuidStr, file, hearts);
        }
    }

    @SubscribeEvent
    public void onPlayerClone(Clone event) {
        Player newPlayer = event.getEntity();
        if (!newPlayer.level().isClientSide()) {
            if (event.isWasDeath()) {
                UUID uuid = newPlayer.getUUID();
                if (HeartStorage.get().has(uuid)) {
                    if (newPlayer instanceof ServerPlayer) {
                        int hearts = HeartStorage.get().getHearts(uuid);
                        HeartData.applyMaxHealth((ServerPlayer) newPlayer, hearts);
                    }
                }
            }
        }
    }

    @SubscribeEvent(
        priority = EventPriority.NORMAL
    )
    public void onLivingDeath(LivingDeathEvent event) {
        if (!event.getEntity().level().isClientSide()) {
            if (event.getEntity() instanceof ServerPlayer) {
                ServerPlayer deadPlayer = (ServerPlayer) event.getEntity();
                UUID deadUUID = deadPlayer.getUUID();
                int hearts = HeartStorage.get().getHearts(deadUUID);
                if (hearts < 0) {
                    hearts = HeartSystemMod.config.getStartHearts();
                }

                --hearts;
                int min = HeartSystemMod.config.getMinHearts();
                if (hearts <= min) {
                    HeartStorage.get().setHearts(deadUUID, min);
                    MinecraftServer server = deadPlayer.getServer();
                    if (server != null) {
                        Component msg = Component.literal("§c[HeartSystem] " + deadPlayer.getName().getString() + " has been permanently banned (0 hearts).");
                        server.getPlayerList().getPlayers().forEach(p -> p.sendSystemMessage(msg));
                        UserBanList banList = server.getPlayerList().getBans();
                        banList.add(
                            new UserBanListEntry(new GameProfile(deadUUID, deadPlayer.getName().getString()), null, null, null, "Permadeath: ran out of hearts")
                        );
                    }

                    deadPlayer.connection.disconnect(Component.literal("§cYou have been permanently banned.\nYou ran out of hearts."));
                } else {
                    HeartStorage.get().setHearts(deadUUID, hearts);
                    deadPlayer.sendSystemMessage(Component.literal("§c[HeartSystem] You lost a heart! Hearts remaining: " + hearts));
                }

                DamageSource source = event.getSource();
                Entity killer = source.getEntity();
                if (killer instanceof ServerPlayer killerPlayer) {
                    UUID killerUUID = killerPlayer.getUUID();
                    int killerHearts = HeartStorage.get().getHearts(killerUUID);
                    if (killerHearts < 0) {
                        killerHearts = HeartSystemMod.config.getStartHearts();
                    }

                    int max = HeartSystemMod.config.getMaxHearts();
                    if (killerHearts < max) {
                        HeartStorage.get().setHearts(killerUUID, ++killerHearts);
                        HeartData.applyMaxHealth(killerPlayer, killerHearts);
                        killerPlayer.sendSystemMessage(Component.literal("§a[HeartSystem] You gained a heart! Hearts: " + killerHearts));
                    } else {
                        killerPlayer.sendSystemMessage(Component.literal("§e[HeartSystem] You killed a player but are already at max hearts (" + max + ")."));
                    }
                }
            }
        }
    }
}