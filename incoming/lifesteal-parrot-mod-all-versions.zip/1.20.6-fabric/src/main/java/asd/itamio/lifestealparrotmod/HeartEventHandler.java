package asd.itamio.lifestealparrotmod;

import net.fabricmc.fabric.api.entity.event.v1.ServerLivingEvents;
import net.fabricmc.fabric.api.entity.event.v1.ServerPlayerEvents;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.server.players.UserBanList;
import net.minecraft.server.players.UserBanListEntry;
import net.minecraft.network.chat.Component;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.nbt.CompoundTag;

import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

public class HeartEventHandler {
    private static final ConcurrentHashMap<UUID, Integer> HEARTS_MAP = new ConcurrentHashMap<>();
    private static final HeartConfig CONFIG = new HeartConfig();

    public static void registerEvents() {
        ServerPlayerEvents.JOIN.register((ServerPlayer player) -> {
            UUID uuid = player.getUUID();
            CompoundTag tag = player.getPersistentData();
            int hearts = tag.getInt("hearts");
            if (hearts <= 0) {
                hearts = CONFIG.getStartHearts();
            }
            HEARTS_MAP.put(uuid, hearts);
            HeartData.applyMaxHealth(player, hearts);
        });

        ServerPlayerEvents.AFTER_RESPAWN.register((ServerPlayer oldPlayer, ServerPlayer newPlayer, boolean alive) -> {
            if (newPlayer != null) {
                int hearts = HEARTS_MAP.getOrDefault(newPlayer.getUUID(), CONFIG.getStartHearts());
                HeartData.applyMaxHealth(newPlayer, hearts);
            }
        });

        ServerLivingEvents.DEATH.register((LivingEntity entity, DamageSource source, boolean alive) -> {
            if (!alive && entity instanceof ServerPlayer deadPlayer) {
                UUID deadUUID = deadPlayer.getUUID();
                int hearts = HEARTS_MAP.getOrDefault(deadUUID, CONFIG.getStartHearts());
                hearts--;

                CompoundTag persistentData = deadPlayer.getPersistentData();
                persistentData.putInt("hearts", hearts);

                int minHearts = CONFIG.getMinHearts();
                if (hearts <= minHearts) {
                    HEARTS_MAP.put(deadUUID, minHearts);
                    MinecraftServer server = deadPlayer.getServer();
                    if (server != null) {
                        Component msg = Component.literal("[Lifesteal] " + deadPlayer.getName().getString() + " has been permanently banned (0 hearts).");
                        server.getPlayerList().getPlayers().forEach(p -> p.sendSystemMessage(msg));
                        UserBanList banList = server.getPlayerList().getBans();
                        banList.add(
                            new UserBanListEntry(new com.mojang.authlib.GameProfile(deadUUID, deadPlayer.getName().getString()), null, null, null, "Permadeath: ran out of hearts")
                        );
                    }
                    deadPlayer.connection.disconnect(Component.literal("You have been permanently banned.\nYou ran out of hearts."));
                } else {
                    HEARTS_MAP.put(deadUUID, hearts);
                    deadPlayer.sendSystemMessage(Component.literal("[Lifesteal] You lost a heart! Hearts remaining: " + hearts));
                }

                Entity killer = source.getEntity();
                if (killer instanceof ServerPlayer killerPlayer) {
                    UUID killerUUID = killerPlayer.getUUID();
                    int killerHearts = HEARTS_MAP.getOrDefault(killerUUID, CONFIG.getStartHearts());
                    int maxHearts = CONFIG.getMaxHearts();
                    if (killerHearts < maxHearts) {
                        killerHearts++;
                        HEARTS_MAP.put(killerUUID, killerHearts);
                        killerPlayer.getPersistentData().putInt("hearts", killerHearts);
                        HeartData.applyMaxHealth(killerPlayer, killerHearts);
                        killerPlayer.sendSystemMessage(Component.literal("[Lifesteal] You gained a heart! Hearts: " + killerHearts));
                    } else {
                        killerPlayer.sendSystemMessage(Component.literal("[Lifesteal] You killed a player but are already at max hearts (" + maxHearts + ")."));
                    }
                }
            }
        });
    }
}