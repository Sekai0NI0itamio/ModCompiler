package asd.itamio.lifestealparrotmod;

public class HeartConfig {
    private static final int startHearts = 10;
    private static final int maxHearts = 20;
    private static final int minHearts = 0;

    public static int getStartHearts() {
        return startHearts;
    }

    public static int getMaxHearts() {
        return maxHearts;
    }

    public static int getMinHearts() {
        return minHearts;
    }
}