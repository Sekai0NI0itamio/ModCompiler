package asd.itamio.lifestealparrotmod;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import net.fabricmc.loader.api.FabricLoader;

import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.file.Path;

public class HeartConfig {
    private int startHearts = 10;
    private int maxHearts = 20;
    private int minHearts = 0;

    public int getStartHearts() { return startHearts; }
    public int getMaxHearts() { return maxHearts; }
    public int getMinHearts() { return minHearts; }

    public void load() {
        Path configPath = FabricLoader.getInstance().getConfigDir().resolve("lifestealparrotmod.json");
        if (configPath.toFile().exists()) {
            Gson gson = new Gson();
            try (FileReader reader = new FileReader(configPath.toFile())) {
                HeartConfig loaded = gson.fromJson(reader, HeartConfig.class);
                if (loaded != null) {
                    this.startHearts = loaded.startHearts;
                    this.maxHearts = loaded.maxHearts;
                    this.minHearts = loaded.minHearts;
                }
            } catch (IOException e) {
                ExampleMod.LOGGER.error("Failed to load config: {}", e.getMessage());
            }
        } else {
            // Save default config
            save();
        }
    }

    public void save() {
        Path configPath = FabricLoader.getInstance().getConfigDir().resolve("lifestealparrotmod.json");
        Gson gson = new GsonBuilder().setPrettyPrinting().create();
        try (FileWriter writer = new FileWriter(configPath.toFile())) {
            gson.toJson(this, writer);
        } catch (IOException e) {
            ExampleMod.LOGGER.error("Failed to save config: {}", e.getMessage());
        }
    }
}