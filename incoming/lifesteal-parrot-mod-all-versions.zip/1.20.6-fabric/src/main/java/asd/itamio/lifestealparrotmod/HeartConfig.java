package asd.itamio.lifestealparrotmod;

public class HeartConfig {
    private static int startHearts = 10;
    private static int maxHearts = 20;
    private static int minHearts = 0;

    public static int getStartHearts() {
        return startHearts;
    }

    public static int getMaxHearts() {
        return maxHearts;
    }

    public static int getMinHearts() {
        return minHearts;
    }
}