package asd.itamio.lifestealparrotmod;

public class HeartConfig {
    public final int startHearts = 10;
    public final int maxHearts = 20;
    public final int minHearts = 0;

    public int getStartHearts() {
        return startHearts;
    }

    public int getMaxHearts() {
        return maxHearts;
    }

    public int getMinHearts() {
        return minHearts;
    }
}