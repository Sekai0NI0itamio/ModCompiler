package asd.itamio.lifestealparrotmod;

import net.minecraft.core.Registry;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.resources.Identifier;
import net.minecraft.util.ByIdMap;

public class HeartConfig {
    private final int startHearts = 10;
    private final int maxHearts = 20;
    private final int minHearts = 0;

    public int getStartHearts() {
        return startHearts;
    }

    public int getMaxHearts() {
        return maxHearts;
    }

    public int getMinHearts() {
        return minHearts;
    }
}