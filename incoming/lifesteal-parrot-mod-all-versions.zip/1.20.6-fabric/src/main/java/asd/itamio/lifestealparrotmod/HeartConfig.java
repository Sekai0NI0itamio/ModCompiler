package asd.itamio.lifestealparrotmod;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

public class HeartConfig {
    public static final Logger LOGGER = LoggerFactory.getLogger(ExampleMod.MOD_ID + "/config");

    private int startHearts = 20;
    private int minHearts = 0;

    private final Path configPath;

    public HeartConfig() {
        // Config file in the config directory of the game
        configPath = Paths.get("config", ExampleMod.MOD_ID + ".json");
    }

    public void load() {
        try {
            File configFile = configPath.toFile();
            if (!configFile.exists()) {
                // Create default config
                save();
                return;
            }
            Gson gson = new Gson();
            HeartConfig loaded = gson.fromJson(new FileReader(configFile), HeartConfig.class);
            this.startHearts = loaded.startHearts;
            this.minHearts = loaded.minHearts;
        } catch (IOException e) {
            LOGGER.error("Failed to load config, using defaults", e);
        }
    }

    public void save() {
        try {
            Files.createDirectories(configPath.getParent());
            Gson gson = new GsonBuilder().setPrettyPrinting().create();
            String json = gson.toJson(this);
            Files.writeString(configPath, json);
        } catch (IOException e) {
            LOGGER.error("Failed to save config", e);
        }
    }

    public int getStartHearts() {
        return startHearts;
    }

    public int getMinHearts() {
        return minHearts;
    }
}