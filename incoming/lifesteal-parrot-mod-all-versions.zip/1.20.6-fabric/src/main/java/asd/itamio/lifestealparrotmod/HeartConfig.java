package asd.itamio.lifestealparrotmod;

public class HeartConfig {
	// Hardcoded defaults (match Forge version settings)
	private final int startHearts = 10;
	private final int maxHearts = 20;
	private final int minHearts = 0;

	public int getStartHearts() {
		return startHearts;
	}

	public int getMaxHearts() {
		return maxHearts;
	}

	public int getMinHearts() {
		return minHearts;
	}
}