package asd.itamio.lifestealparrotmod;

public class HeartConfig {
    public int getStartHearts() { return 10; }
    public int getMaxHearts() { return 20; }
    public int getMinHearts() { return 0; }
    public getStartHearts getMaxHearts getMinHearts same.
}