package asd.itamio.lifestealparrotmod;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import net.fabricmc.loader.api.FabricLoader;

import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

public class HeartConfig {
    private int startHearts = 10;
    private int maxHearts = 20;
    private int minHearts = 0;

    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static final File CONFIG_FILE = new File(FabricLoader.getInstance().getConfigDir().toFile(), "lifestealparrotmod.json");

    public static HeartConfig load() {
        if (CONFIG_FILE.exists()) {
            try (FileReader reader = new FileReader(CONFIG_FILE)) {
                return GSON.fromJson(reader, HeartConfig.class);
            } catch (IOException e) {
                LifestealparrotmodMod.LOGGER.error("Failed to load config, using defaults.", e);
            }
        }
        HeartConfig config = new HeartConfig();
        config.save();
        return config;
    }

    public void save() {
        try (FileWriter writer = new FileWriter(CONFIG_FILE)) {
            GSON.toJson(this, writer);
        } catch (IOException e) {
            LifestealparrotmodMod.LOGGER.error("Failed to save config.", e);
        }
    }

    public int getStartHearts() { return startHearts; }
    public int getMaxHearts() { return maxHearts; }
    public int getMinHearts() { return minHearts; }
}