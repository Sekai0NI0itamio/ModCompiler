package asd.itamio.lifestealparrotmod;

import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.entity.event.v1.ServerPlayerEvents;
import net.fabricmc.fabric.api.networking.v1.ServerPlayConnectionEvents;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.text.Text;
import net.minecraft.world.level.storage.LevelResource;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.UUID;

public class ExampleMod implements ModInitializer {
    public static final String MOD_ID = "lifestealparrotmod";
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);
    public static HeartConfig CONFIG;

    @Override
    public void onInitialize() {
        // Load config
        CONFIG = new HeartConfig();
        CONFIG.load();

        // Register events
        ServerPlayConnectionEvents.JOIN.register((handler, sender, server) -> {
            ServerPlayerEntity player = handler.getPlayer();
            HeartStorage storage = HeartStorage.getInstance();

            Path worldSavePath = server.getSavePath(LevelResource.ROOT);
            Path heartsDir = worldSavePath.resolve("hearts");
            if (!Files.exists(heartsDir)) {
                try {
                    Files.createDirectories(heartsDir);
                } catch (IOException e) {
                    LOGGER.error("Failed to create hearts directory: {}", e.getMessage());
                }
            }
            Path playerFile = heartsDir.resolve(player.getUuid().toString() + ".json");
            int loaded = storage.load(player.getUuid(), playerFile);
            if (loaded < 0) {
                // New player
                int startHearts = CONFIG.getStartHearts();
                storage.setHearts(player.getUuid(), startHearts);
                HeartData.applyMaxHealth(player, startHearts);
            } else {
                HeartData.applyMaxHealth(player, loaded);
            }
        });

        ServerPlayConnectionEvents.DISCONNECT.register((handler, server) -> {
            ServerPlayerEntity player = handler.getPlayer();
            HeartStorage storage = HeartStorage.getInstance();
            Path worldSavePath = server.getSavePath(LevelResource.ROOT);
            Path heartsDir = worldSavePath.resolve("hearts");
            Path playerFile = heartsDir.resolve(player.getUuid().toString() + ".json");
            storage.save(player.getUuid(), playerFile);
        });

        ServerPlayerEvents.AFTER_DEATH.register((player, damageSource) -> {
            if (!player.getWorld().isClient()) {
                HeartStorage storage = HeartStorage.getInstance();
                UUID deadUUID = player.getUuid();
                int hearts = storage.getHearts(deadUUID);
                if (hearts < 0) {
                    hearts = CONFIG.getStartHearts();
                }

                // Lose a heart on death
                hearts--;
                if (hearts < CONFIG.getMinHearts()) {
                    hearts = CONFIG.getMinHearts();
                }
                storage.setHearts(deadUUID, hearts);
                HeartData.applyMaxHealth(player, hearts);

                // Check for permadeath
                if (hearts <= 0) {
                    // Ban player permanently
                    MinecraftServer server = player.getServer();
                    if (server != null) {
                        server.getPlayerManager().getUserBanList().add(
                                new GameProfile(player.getUuid(), player.getName().getString()),
                                null, "Permadeath: ran out of hearts", null, null
                        );
                        player.networkHandler.disconnect(Text.literal("You have run out of hearts and have been permanently banned."));
                    }
                }
            }
        });

        ServerPlayerEvents.AFTER_RESPAWN.register((oldPlayer, newPlayer, alive) -> {
            // Ensure max health is applied after respawn
            HeartStorage storage = HeartStorage.getInstance();
            int hearts = storage.getHearts(newPlayer.getUuid());
            if (hearts < 0) hearts = CONFIG.getStartHearts();
            HeartData.applyMaxHealth(newPlayer, hearts);
        });
    }
}