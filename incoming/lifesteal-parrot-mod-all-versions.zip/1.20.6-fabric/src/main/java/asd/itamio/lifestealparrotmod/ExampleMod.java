package asd.itamio.lifestealparrotmod;

import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.entity.event.v1.ServerEntityCombatEvents;
import net.fabricmc.fabric.api.entity.event.v1.ServerPlayerEvents;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.attributes.AttributeInstance;
import net.minecraft.world.entity.ai.attributes.AttributeModifier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.UUID;

public class ExampleMod implements ModInitializer {
    public static final String MOD_ID = "lifestealparrotmod";
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

    // Attribute modifier UUID for heart bonus
    private static final UUID HEART_MODIFIER_UUID = UUID.fromString("a1b2c3d4-e5f6-7890-abcd-ef1234567890");
    private static final String HEART_MODIFIER_NAME = "heartsystem.maxhealth";

    @Override
    public void onInitialize() {
        LOGGER.info("Initializing Lifesteal Mod");

        // Handle death events: reduce hearts of dead player, grant heart to killer
        ServerEntityCombatEvents.AFTER_ENTITY_DEATH.register((entity, damageSource) -> {
            if (entity instanceof ServerPlayer deadPlayer) {
                int hearts = HeartStorage.getHearts(deadPlayer.getUUID());
                // Default hearts if not set
                if (hearts < 0) hearts = HeartConfig.getStartHearts();

                hearts--;
                int min = HeartConfig.getMinHearts();
                if (hearts <= min) {
                    HeartStorage.setHearts(deadPlayer.getUUID(), min);
                    // Ban player
                    banPlayer(deadPlayer);
                } else {
                    HeartStorage.setHearts(deadPlayer.getUUID(), hearts);
                    deadPlayer.sendSystemMessage(net.minecraft.network.chat.Component.literal("§c[HeartSystem] You lost a heart! Hearts remaining: " + hearts));
                }

                // Check if killer is a player
                Entity killer = damageSource.getEntity();
                if (killer instanceof ServerPlayer killerPlayer) {
                    int killerHearts = HeartStorage.getHearts(killerPlayer.getUUID());
                    if (killerHearts < 0) killerHearts = HeartConfig.getStartHearts();

                    int max = HeartConfig.getMaxHearts();
                    if (killerHearts < max) {
                        killerHearts++;
                        HeartStorage.setHearts(killerPlayer.getUUID(), killerHearts);
                        applyMaxHealth(killerPlayer, killerHearts);
                        killerPlayer.sendSystemMessage(net.minecraft.network.chat.Component.literal("§a[HeartSystem] You gained a heart! Hearts: " + killerHearts));
                    } else {
                        killerPlayer.sendSystemMessage(net.minecraft.network.chat.Component.literal("§e[HeartSystem] You killed a player but are already at max hearts (" + max + ")."));
                    }
                }
            }
        });

        // Apply heart-based max health on join/spawn
        ServerPlayerEvents.AFTER_RESPAWN.register((oldPlayer, newPlayer, alive) -> {
            if (newPlayer instanceof ServerPlayer) {
                int hearts = HeartStorage.getHearts(newPlayer.getUUID());
                if (hearts < 0) hearts = HeartConfig.getStartHearts();
                applyMaxHealth((ServerPlayer) newPlayer, hearts);
            }
        });
    }

    public static void applyMaxHealth(ServerPlayer player, int hearts) {
        AttributeInstance attr = player.getAttribute(Attributes.MAX_HEALTH);
        if (attr != null) {
            // Remove previous modifier if exists
            if (attr.getModifier(HEART_MODIFIER_UUID) != null) {
                attr.removeModifier(HEART_MODIFIER_UUID);
            }
            // Each heart adds 2 health, base player health is 20 (10 hearts)
            double delta = (double) hearts * 2.0 - 20.0;
            AttributeModifier modifier = new AttributeModifier(HEART_MODIFIER_UUID, HEART_MODIFIER_NAME, delta, AttributeModifier.Operation.ADD_VALUE);
            attr.addPermanentModifier(modifier);
            // Clamp current health if over new max
            float newMax = (float) (hearts * 2);
            if (player.getHealth() > newMax) {
                player.setHealth(newMax);
            }
        }
    }

    private void banPlayer(ServerPlayer player) {
        // Broadcast message
        net.minecraft.network.chat.Component msg = net.minecraft.network.chat.Component.literal("§c[HeartSystem] " + player.getName().getString() + " has been permanently banned (0 hearts).");
        player.server.getPlayerList().getPlayers().forEach(p -> p.sendSystemMessage(msg));

        // Add to ban list
        com.mojang.authlib.GameProfile profile = player.getGameProfile();
        net.minecraft.server.players.UserBanList banList = player.server.getPlayerList().getBans();
        net.minecraft.server.players.UserBanListEntry entry = new net.minecraft.server.players.UserBanListEntry(profile, null, null, null, "Permadeath: ran out of hearts");
        banList.add(entry);

        // Disconnect player
        player.connection.disconnect(net.minecraft.network.chat.Component.literal("§cYou have been permanently banned.\nYou ran out of hearts."));
    }
}