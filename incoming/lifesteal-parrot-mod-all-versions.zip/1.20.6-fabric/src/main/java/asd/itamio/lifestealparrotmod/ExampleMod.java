package asd.itamio.lifestealparrotmod;

import com.mojang.authlib.GameProfile;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.entity.event.v1.ServerEntityCombatEvents;
import net.fabricmc.fabric.api.entity.event.v1.ServerPlayerEvents;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.attribute.EntityAttributeInstance;
import net.minecraft.entity.attribute.EntityAttributeModifier;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.entity.damage.DamageSource;
import net.minecraft.server.ban.UserBanEntry;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.text.Text;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Date;
import java.util.UUID;

public class ExampleMod implements ModInitializer {
    public static final String MOD_ID = "lifestealparrotmod";
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

    // Attribute modifier UUID for heart bonus
    private static final UUID HEART_MODIFIER_UUID = UUID.fromString("a1b2c3d4-e5f6-7890-abcd-ef1234567890");
    private static final String HEART_MODIFIER_NAME = "heartsystem.maxhealth";

    @Override
    public void onInitialize() {
        LOGGER.info("Initializing Lifesteal Mod");

        // Handle death events: reduce hearts of dead player, grant heart to killer
        ServerEntityCombatEvents.AFTER_ENTITY_DEATH.register((entity, damageSource) -> {
            if (entity instanceof ServerPlayerEntity deadPlayer) {
                if (deadPlayer.getWorld().isClient) return;

                int hearts = HeartStorage.getHearts(deadPlayer.getUuid());
                // Default hearts if not set
                if (hearts < 0) hearts = HeartConfig.getStartHearts();

                hearts--;
                int min = HeartConfig.getMinHearts();
                if (hearts <= min) {
                    HeartStorage.setHearts(deadPlayer.getUuid(), min);
                    // Ban player
                    banPlayer(deadPlayer);
                } else {
                    HeartStorage.setHearts(deadPlayer.getUuid(), hearts);
                    deadPlayer.sendMessage(Text.literal("§c[HeartSystem] You lost a heart! Hearts remaining: " + hearts), false);
                }

                // Check if killer is a player
                Entity killer = damageSource.getAttacker();
                if (killer instanceof ServerPlayerEntity killerPlayer) {
                    int killerHearts = HeartStorage.getHearts(killerPlayer.getUuid());
                    if (killerHearts < 0) killerHearts = HeartConfig.getStartHearts();

                    int max = HeartConfig.getMaxHearts();
                    if (killerHearts < max) {
                        killerHearts++;
                        HeartStorage.setHearts(killerPlayer.getUuid(), killerHearts);
                        applyMaxHealth(killerPlayer, killerHearts);
                        killerPlayer.sendMessage(Text.literal("§a[HeartSystem] You gained a heart! Hearts: " + killerHearts), false);
                    } else {
                        killerPlayer.sendMessage(Text.literal("§e[HeartSystem] You killed a player but are already at max hearts (" + max + ")."), false);
                    }
                }
            }
        });

        // Apply heart-based max health on join/spawn
        ServerPlayerEvents.AFTER_RESPAWN.register((oldPlayer, newPlayer, alive) -> {
            if (newPlayer instanceof ServerPlayerEntity) {
                ServerPlayerEntity player = (ServerPlayerEntity) newPlayer;
                int hearts = HeartStorage.getHearts(player.getUuid());
                if (hearts < 0) hearts = HeartConfig.getStartHearts();
                applyMaxHealth(player, hearts);
            }
        });
    }

    public static void applyMaxHealth(ServerPlayerEntity player, int hearts) {
        EntityAttributeInstance attr = player.getAttributeInstance(EntityAttributes.GENERIC_MAX_HEALTH);
        if (attr != null) {
            // Remove previous modifier if exists
            EntityAttributeModifier existing = attr.getModifier(HEART_MODIFIER_UUID);
            if (existing != null) {
                attr.removeModifier(HEART_MODIFIER_UUID);
            }
            // Each heart adds 2 health, base player health is 20 (10 hearts)
            double delta = (double) hearts * 2.0 - 20.0;
            EntityAttributeModifier modifier = new EntityAttributeModifier(HEART_MODIFIER_UUID, HEART_MODIFIER_NAME, delta, EntityAttributeModifier.Operation.ADDITION);
            attr.addPersistentModifier(modifier);
            // Clamp current health if over new max
            float newMax = (float) (hearts * 2);
            if (player.getHealth() > newMax) {
                player.setHealth(newMax);
            }
        }
    }

    private void banPlayer(ServerPlayerEntity player) {
        // Broadcast message
        Text msg = Text.literal("§c[HeartSystem] " + player.getName().getString() + " has been permanently banned (0 hearts).");
        player.getServer().getPlayerManager().getPlayerList().forEach(p -> p.sendMessage(msg, false));

        // Add to ban list
        GameProfile profile = player.getGameProfile();
        UserBanEntry entry = new UserBanEntry(profile, null, null, null, "Permadeath: ran out of hearts");
        player.getServer().getPlayerManager().getUserBanList().add(entry);

        // Disconnect player
        player.networkHandler.disconnect(Text.literal("§cYou have been permanently banned.\nYou ran out of hearts."));
    }
}