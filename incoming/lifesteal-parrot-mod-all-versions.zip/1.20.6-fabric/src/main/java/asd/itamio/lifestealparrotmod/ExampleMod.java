package asd.itamio.lifestealparrotmod;

import net.fabricmc.api.ModInitializer;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.nbt.NbtIo;
import net.minecraft.server.MinecraftServer;
import net.minecraft.util.WorldSavePath;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.File;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

public class ExampleMod implements ModInitializer {
    public static final Logger LOGGER = LoggerFactory.getLogger("lifestealparrotmod");
    public static final HeartConfig CONFIG = new HeartConfig();
    private static final HeartStorage STORAGE = new HeartStorage();

    @Override
    public void onInitialize() {
        LOGGER.info("Lifesteal Mod loaded!");
    }

    public static HeartStorage getStorage() {
        return STORAGE;
    }

    public static class HeartConfig {
        private final int startHearts = 10;
        private final int maxHearts = 20;
        private final int minHearts = 0;

        public int getStartHearts() {
            return startHearts;
        }

        public int getMaxHearts() {
            return maxHearts;
        }

        public int getMinHearts() {
            return minHearts;
        }
    }

    public static class HeartStorage {
        private final Map<UUID, Integer> heartMap = new HashMap<>();
        private boolean loaded = false;

        public void load(MinecraftServer server) {
            if (loaded) return;
            try {
                File file = server.getSavePath(WorldSavePath.ROOT).resolve("lifesteal_hearts.dat").toFile();
                if (file.exists()) {
                    NbtCompound tag = NbtIo.read(file.toPath());
                    if (tag != null) {
                        for (String key : tag.getKeys()) {
                            UUID uuid = UUID.fromString(key);
                            int hearts = tag.getInt(key);
                            heartMap.put(uuid, hearts);
                        }
                    }
                }
            } catch (IOException e) {
                LOGGER.error("Failed to load hearts data", e);
            }
            loaded = true;
        }

        public void save(MinecraftServer server) {
            try {
                File file = server.getSavePath(WorldSavePath.ROOT).resolve("lifesteal_hearts.dat").toFile();
                NbtCompound tag = new NbtCompound();
                for (Map.Entry<UUID, Integer> entry : heartMap.entrySet()) {
                    tag.putInt(entry.getKey().toString(), entry.getValue());
                }
                NbtIo.write(tag, file.toPath());
            } catch (IOException e) {
                LOGGER.error("Failed to save hearts data", e);
            }
        }

        public int getHearts(UUID uuid) {
            return heartMap.getOrDefault(uuid, -1);
        }

        public void setHearts(UUID uuid, int hearts) {
            heartMap.put(uuid, hearts);
        }

        public boolean hasHearts(UUID uuid) {
            return heartMap.containsKey(uuid);
        }
    }
}