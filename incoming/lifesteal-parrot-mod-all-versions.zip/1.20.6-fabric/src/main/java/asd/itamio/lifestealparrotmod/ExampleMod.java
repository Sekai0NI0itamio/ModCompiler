package asd.itamio.lifestealparrotmod;

import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.entity.event.v1.ServerPlayerEvents;
import net.fabricmc.fabric.api.networking.v1.ServerPlayConnectionEvents;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.world.World;
import net.minecraft.world.dimension.WorldSavePath;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;

public class ExampleMod implements ModInitializer {
    public static final String MOD_ID = "lifestealparrotmod";
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);
    public static HeartConfig CONFIG;

    @Override
    public void onInitialize() {
        // Load config
        CONFIG = new HeartConfig();
        CONFIG.load();

        // Register events
        ServerPlayConnectionEvents.JOIN.register((handler, sender, server) -> {
            ServerPlayerEntity player = handler.player;
            HeartStorage storage = HeartStorage.getInstance();
            Path worldSavePath = server.getSavePath(WorldSavePath.ROOT);
            Path heartsDir = worldSavePath.resolve("hearts");
            if (!Files.exists(heartsDir)) {
                try {
                    Files.createDirectories(heartsDir);
                } catch (IOException e) {
                    LOGGER.error("Failed to create hearts directory: {}", e.getMessage());
                }
            }
            Path playerFile = heartsDir.resolve(player.getUuid().toString() + ".json");
            int loaded = storage.load(player.getUuid(), playerFile);
            if (loaded < 0) {
                // new player
                int startHearts = CONFIG.getStartHearts();
                storage.setHearts(player.getUuid(), startHearts);
                HeartData.applyMaxHealth(player, startHearts);
            } else {
                HeartData.applyMaxHealth(player, loaded);
            }
        });

        ServerPlayConnectionEvents.DISCONNECT.register((handler, server) -> {
            ServerPlayerEntity player = handler.player;
            HeartStorage storage = HeartStorage.getInstance();
            Path worldSavePath = server.getSavePath(WorldSavePath.ROOT);
            Path heartsDir = worldSavePath.resolve("hearts");
            Path playerFile = heartsDir.resolve(player.getUuid().toString() + ".json");
            storage.save(player.getUuid(), playerFile);
        });

        ServerPlayerEvents.AFTER_DEATH.register((player, damageSource) -> {
            if (!player.getWorld().isClient()) {
                HeartStorage storage = HeartStorage.getInstance();
                java.util.UUID deadUUID = player.getUuid();
                int hearts = storage.getHearts(deadUUID);
                if (hearts < 0) {
                    hearts = CONFIG.getStartHearts();
                }
                hearts--;
                int min = CONFIG.getMinHearts();
                if (hearts <= min) {
                    // Permadeath
                    storage.setHearts(deadUUID, min);
                    MinecraftServer server = player.getServer();
                    if (server != null) {
                        net.minecraft.text.Text msg = net.minecraft.text.Text.literal("§c[HeartSystem] " + player.getName().getString() + " has been permanently banned (0 hearts).");
                        server.getPlayerManager().getPlayerList().forEach(p -> p.sendMessage(msg, false));
                        server.getPlayerManager().getUserBanList().add(
                                new net.minecraft.server.BannedPlayerEntry(
                                        new com.mojang.authlib.GameProfile(deadUUID, player.getName().getString()),
                                        null, null, null, "Permadeath: ran out of hearts"
                                )
                        );
                    }
                    player.networkHandler.disconnect(net.minecraft.text.Text.literal("§cYou have been permanently banned.\nYou ran out of hearts."));
                } else {
                    storage.setHearts(deadUUID, hearts);
                    player.sendMessage(net.minecraft.text.Text.literal("§c[HeartSystem] You lost a heart! Hearts remaining: " + hearts), false);
                }

                // Killer gains a heart
                if (damageSource.getAttacker() instanceof ServerPlayerEntity killer) {
                    int killerHearts = storage.getHearts(killer.getUuid());
                    if (killerHearts < 0) {
                        killerHearts = CONFIG.getStartHearts();
                    }
                    int max = CONFIG.getMaxHearts();
                    if (killerHearts < max) {
                        killerHearts++;
                        storage.setHearts(killer.getUuid(), killerHearts);
                        HeartData.applyMaxHealth(killer, killerHearts);
                        killer.sendMessage(net.minecraft.text.Text.literal("§a[HeartSystem] You gained a heart! Hearts: " + killerHearts), false);
                    } else {
                        killer.sendMessage(net.minecraft.text.Text.literal("§e[HeartSystem] You killed a player but are already at max hearts (" + max + ")."), false);
                    }
                }
            }
        });

        LOGGER.info("Lifesteal Mod initialized!");
    }
}