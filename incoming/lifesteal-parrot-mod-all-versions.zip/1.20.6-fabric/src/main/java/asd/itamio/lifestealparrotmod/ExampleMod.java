package asd.itamio.lifestealparrotmod;

import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.entity.event.v1.ServerPlayerEvents;
import net.fabricmc.fabric.api.networking.v1.ServerPlayConnectionEvents;
import net.minecraft.server.network.ServerPlayerEntity;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class ExampleMod implements ModInitializer {
	public static final String MOD_ID = "lifestealparrotmod";
	public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);
	public static HeartConfig config = new HeartConfig();

	@Override
	public void onInitialize() {
		// This code runs as soon as Minecraft is in a mod-load-ready state.

		ServerPlayConnectionEvents.JOIN.register((handler, sender, server) -> {
			ServerPlayerEntity player = handler.player;
			// Load hearts from storage (or use default)
			int hearts = HeartStorage.getOrLoad(player.getUuid(), server);
			if (hearts < 0) {
				hearts = config.getStartHearts();
				HeartStorage.setHearts(player.getUuid(), hearts);
			}
			// Apply max health
			HeartData.applyMaxHealth(player, hearts);
		});

		ServerPlayerEvents.AFTER_RESPAWN.register((oldPlayer, newPlayer, alive) -> {
			// Apply max health after respawn (hearts should already be updated on death)
			int hearts = HeartStorage.getHearts(newPlayer.getUuid());
			if (hearts >= 0) {
				HeartData.applyMaxHealth(newPlayer, hearts);
			}
		});
	}
}