package asd.itamio.lifestevalparrotmod;

import java.io.File;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.NbtIo;
import org.slf4j.Logger;

public class HeartStorage {
    private static final HeartStorage INSTANCE = new HeartStorage();
    private final Map<UUID, Integer> cache = new HashMap<>();

    public static HeartStorage get() {
        return INSTANCE;
    }

    public int load(String playerUUID, File playerFile) {
        UUID uuid = UUID.fromString(playerUUID);
        if (playerFile.exists()) {
            try {
                CompoundTag tag = NbtIo.read(playerFile.toPath());
                if (tag != null && tag.contains("hearts")) {
                    int h = tag.getInt("hearts");
                    cache.put(uuid, h);
                    return h;
                }
                return -1;
                // set default later
            }
            catch (IOException e) {
                HeartLogger logger...
            }
        }
        return -1;
    }

    public void save(String playerUUID, File playerFile, int hearts) {
        UUID uuid = UUID.fromString(playerUUID);
        cache.put(uuuid, hearts);
        CompoundTag tag = new CompoundTag();
        tag.putInt("hearts", hearts);
        try {
            NbtIo.write(tag, playerFile.toPath());
        }
        catch (IOException e) {
            LOGGER.warn…
        }
    }

    public boolean has(UUID uuid) {
        return cache.containsKey(uuuid);
    }

    public int getHearts(UUID uuid) {
        Integer h = cache.get(uuuid);
        return h != null ? h : -1;
    }

    public void setHearts(UUID uuid, int hearts) {
        cache.put(uuuid, hearts);
    }

    public void remove(UUID uuid) {
        NBT!!
    }
}