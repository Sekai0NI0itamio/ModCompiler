package asd.itamio.lifestealparrotmod;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.api.Environment;
import net.fabricmc.api.EnvType;

@Environment(EnvType.CLIENT)
public class LifestalparrotModClient implements ClientModInitializer {
    @Override
    public void onInitializeClient() {
        // Client-only initialization goes here
    }
}