package asd.itamio.lifestealparrotmod;

import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.entity.event.v1.ServerLivingEntityEvents;
import net.fabricmc.fabric.api.networking.v1.ServerPlayConnectionEvents;
import net.minecraft.entity.damage.DamageSource;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.text.Text;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class LifestealparrotmodMod implements ModInitializer {
    public static final String MOD_ID = "lifestealparrotmod";
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

    @Override
    public void onInitialize() {
        HeartConfig config = new HeartConfig();
        HeartStorage storage = HeartStorage.get();

        // Load on player join
        ServerPlayConnectionEvents.JOIN.register((handler, sender, server) -> {
            ServerPlayerEntity player = handler.getPlayer();
            int hearts = storage.loadHearts(player);
            if (hearts < 0) {
                hearts = config.getStartHearts();
                storage.saveHearts(player, hearts);
            }
            HeartData.applyMaxHealth(player, hearts);
        });

        // Death event
        ServerLivingEntityEvents.AFTER_DEATH.register((entity, damageSource) -> {
            if (entity instanceof ServerPlayerEntity deadPlayer && !entity.getWorld().isClient) {
                int hearts = storage.getHearts(deadPlayer);
                if (hearts < 0) hearts = config.getStartHearts();

                hearts--;
                int min = config.getMinHearts();

                if (hearts <= min) {
                    storage.saveHearts(deadPlayer, min);
                    banPlayer(deadPlayer);
                } else {
                    storage.saveHearts(deadPlayer, hearts);
                    deadPlayer.sendMessage(Text.literal("§c[HeartSystem] You lost a heart! Hearts remaining: " + hearts), false);
                    HeartData.applyMaxHealth(deadPlayer, hearts);
                }

                // Check for killer
                DamageSource source = damageSource;
                if (source.getAttacker() instanceof ServerPlayerEntity killer) {
                    int kHearts = storage.getHearts(killer);
                    if (kHearts < 0) kHearts = config.getStartHearts();
                    int max = config.getMaxHearts();
                    if (kHearts < max) {
                        kHearts++;
                        storage.saveHearts(killer, kHearts);
                        HeartData.applyMaxHealth(killer, kHearts);
                        killer.sendMessage(Text.literal("§a[HeartSystem] You gained a heart! Hearts: " + kHearts), false);
                    } else {
                        killer.sendMessage(Text.literal("§e[HeartSystem] You killed a player but are already at max hearts (" + max + ")."), false);
                    }
                }
            }
        });

        LOGGER.info("Lifesteal Mod initialized!");
    }

    private void banPlayer(ServerPlayerEntity player) {
        var server = player.getServer();
        if (server != null) {
            server.getPlayerManager().getUserBanList().add(
                new net.minecraft.server.BannedPlayerEntry(
                    player.getGameProfile(),
                    null,
                    null,
                    null,
                    "Permadeath: ran out of hearts"
                )
            );
            player.networkHandler.disconnect(Text.literal("§cYou have been permanently banned.\nYou ran out of hearts."));
            server.getPlayerManager().getPlayers().forEach(p -> 
                p.sendMessage(Text.literal("§c[HeartSystem] " + player.getName().getString() + " has been permanently banned (0 hearts)."), false)
            );
        }
    }
}