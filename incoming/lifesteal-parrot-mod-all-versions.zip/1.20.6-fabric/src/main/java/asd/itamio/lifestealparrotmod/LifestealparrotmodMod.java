package asd.itamio.lifestealparrotmod;

import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.entity.event.v1.ServerLivingEntityEvents;
import net.fabricmc.fabric.api.networking.v1.ServerPlayConnectionEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerLifecycleEvents;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.network.ServerPlayerEntity;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class LifestealparrotmodMod implements ModInitializer {
    public static final String MOD_ID = "lifestealparrotmod";
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);
    private static HeartConfig config;
    private static HeartStorage storage;

    @Override
    public void onInitialize() {
        config = new HeartConfig();
        HeartConfig.load();

        ServerLifecycleEvents.SERVER_STARTED.register(server -> {
            storage = HeartStorage.getOrCreate(server);
        });

        ServerPlayConnectionEvents.JOIN.register((handler, sender, server) -> {
            ServerPlayerEntity player = handler.getPlayer();
            if (storage != null) {
                storage.loadPlayer(player);
            }
        });

        ServerLivingEntityEvents.AFTER_DEATH.register((entity, damageSource) -> {
            if (entity instanceof ServerPlayerEntity deadPlayer) {
                if (storage == null) return;
                HeartEventHandler.onPlayerDeath(deadPlayer, damageSource);
            }
        });

        ServerLifecycleEvents.SERVER_STOPPING.register(server -> {
            if (storage != null) {
                storage.save();
            }
        });

        LOGGER.info("Lifesteal Mod initialized.");
    }

    public static HeartConfig getConfig() {
        return config;
    }

    public static HeartStorage getStorage() {
        return storage;
    }
}