package asd.itamio.lifestealparrotmod;

import net.fabricmc.api.ModInitializer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import net.minecraft.server.level.ServerPlayerEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.entity.damage.DamageSource;
import net.minecraft.server.players.UserBanList;
import net.minecraft.server.players.UserBanListEntry;
import com.mojang.authlib.GameProfile;
import net.fabricmc.fabric.api.entity.v1.ServerLivingEvents;
import net.minecraft.world.entity.Entity;

public class LifestealparrotmodMod implements ModInitializer {
    public static final String MOD_ID = "lifestealparrotmod";
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);
    public static HeartConfig config;

    @Override
    public void onInitialize() {
        config = new HeartConfig();
        ServerLivingEvents.ENTITY_DEATH.register(LifestealparrotmodMod::onPlayerDeath);
    }

    public static void onPlayerDeath(Entity entity, DamageSource source) {
        if (entity instanceof ServerPlayerEntity player) {
            // Get the killer
            Entity killer = source.getEntity();

            // Update hearts for player and killer
            if (killer instanceof ServerPlayerEntity killerPlayer) {
                int killerHearts = HeartStorage.get().getHearts(killerPlayer.getUUID());
                if (killerHearts < 0) {
                    killerHearts = config.getStartHearts();
                }
                int maxHearts = config.getMaxHearts();
                if (killerHearts < maxHearts) {
                    HeartStorage.get().setHearts(killerPlayer.getUUID(), ++killerHearts);
                    HeartData.applyMaxHealth(killerPlayer, killerHearts);
                    killerPlayer.sendSystemMessage(net.minecraft.text.Text.literal("§a[HeartSystem] You gained a heart! Hearts: " + killerHearts));
                } else {
                    killerPlayer.sendSystemMessage(net.minecraft.text.Text.literal("§e[HeartSystem] You killed a player but are already at max hearts (" + maxHearts + ")."));
                }
            }

            int hearts = HeartStorage.get().getHearts(player.getUUID());
            if (hearts < 0) {
                hearts = config.getStartHearts();
            }
            --hearts;
            int minHearts = config.getMinHearts();
            if (hearts <= minHearts) {
                HeartStorage.get().setHearts(player.getUUID(), minHearts);
                // MinecraftServer server = player.getServer();
                // if (server != null) {
                //     net.minecraft.text.Component msg = net.minecraft.text.Text.literal("§c[HeartSystem] " + player.getEntityName() + " has been permanently banned (0 hearts).");
                //     server.getPlayerList().getPlayers().forEach(p -> p.sendSystemMessage(msg));
                //     UserBanList banList = server.getPlayerList().getBans();
                //     banList.add(new UserBanListEntry(new GameProfile(player.getUUID(), player.getEntityName()), null, null, null, "Permadeath: ran out of hearts"));
                // }

                // player.connection.disconnect(net.minecraft.text.Text.literal("§cYou have been permanently banned.\nYou ran out of hearts."));
            } else {
                HeartStorage.get().setHearts(player.getUUID(), hearts);
                player.sendSystemMessage(net.minecraft.text.Text.literal("§c[HeartSystem] You lost a heart! Hearts remaining: " + hearts));
            }

            HeartData.applyMaxHealth(player, hearts);
        }
    }
}