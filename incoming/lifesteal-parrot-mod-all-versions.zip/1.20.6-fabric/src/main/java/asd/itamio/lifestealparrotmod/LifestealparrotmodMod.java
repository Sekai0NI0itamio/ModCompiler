package asd.itamio.lifestealparrotmod;

import net.fabricmc.api.ModInitializer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import net.fabricmc.fabric.api.entity.event.v1.ServerLivingEvents;
import java.io.File;
import java.util.UUID;
import net.minecraft.server.players.UserBanList;
import net.minecraft.server.players.UserBanListEntry;
import com.mojang.authlib.GameProfile;

public class LifestaleparrotmodMod implements ModInitializer {
    public static final String MOD_ID = "lifestealparrotmod";
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);
    public static HeartConfig config;

    @Override
    public void onInitialize() {
        config = new HeartConfig();
        ServerLivingEvents.PLAYER_DE Death.register((player, source) -> {
            // handler logic in event
        });
        // Player death event handling - separate event class
        ServerPlayerEvents.ADAPTED player death //...
    }
}