package asd.itamio.lifestealparrotmod;

import net.fabricmc.api.ModInitializer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class LifestealparrotmodMod implements ModInitializer {
    public static final String MOD_ID = "lifestealparrot";
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);
    public static HeartConfig config;

    @Override
    public void onInitialize() {
        config = new HeartConfig();
        HeartEventHandler.register();
    }
}