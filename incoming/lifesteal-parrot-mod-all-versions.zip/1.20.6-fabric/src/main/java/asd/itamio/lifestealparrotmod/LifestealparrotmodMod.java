package asd.itamio.lifestealparrotmod;

import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.entity.event.v1.ServerLivingEntityEvents;
import net.fabricmc.fabric.api.networking.v1.ServerPlayConnectionEvents;
import net.minecraft.entity.damage.DamageSource;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.players.UserBanList;
import net.minecraft.server.players.UserBanListEntry;
import net.minecraft.text.Text;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class LifestealparrotmodMod implements ModInitializer {
    public static final String MOD_ID = "lifestealparrotmod";
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);
    public static HeartConfig config;
    public static HeartStorage storage;

    @Override
    public void onInitialize() {
        config = new HeartConfig();
        storage = HeartStorage.get();

        ServerPlayConnectionEvents.JOIN.register((handler, sender, server) -> {
            ServerPlayerEntity player = handler.getPlayer();
            int hearts = storage.loadHearts(player.getUuid());
            if (hearts < 0) {
                hearts = config.getStartHearts();
                storage.saveHearts(player.getUuid(), hearts);
            }
            HeartData.applyMaxHealth(player, hearts);
        });

        ServerLivingEntityEvents.AFTER_DEATH.register((entity, damageSource) -> {
            if (entity instanceof ServerPlayerEntity deadPlayer && !entity.getWorld().isClient()) {
                handlePlayerDeath(deadPlayer, damageSource);
            }
        });

        LOGGER.info("Lifesteal Mod initialized!");
    }

    private void handlePlayerDeath(ServerPlayerEntity deadPlayer, DamageSource damageSource) {
        UUID deadUUID = deadPlayer.getUuid();
        int hearts = storage.getHearts(deadUUID);
        if (hearts < 0) hearts = config.getStartHearts();

        hearts--;
        int min = config.getMinHearts();

        if (hearts <= min) {
            storage.saveHearts(deadUUID, min);
            banPlayer(deadPlayer);
        } else {
            storage.saveHearts(deadUUID, hearts);
            deadPlayer.sendMessage(Text.literal("§c[HeartSystem] You lost a heart! Hearts remaining: " + hearts), false);
            HeartData.applyMaxHealth(deadPlayer, hearts);
        }

        if (damageSource.getAttacker() instanceof ServerPlayerEntity killer) {
            handleKiller(killer);
        }
    }

    private void handleKiller(ServerPlayerEntity killer) {
        UUID killerUUID = killer.getUuid();
        int kHearts = storage.getHearts(killerUUID);
        if (kHearts < 0) kHearts = config.getStartHearts();
        int max = config.getMaxHearts();
        if (kHearts < max) {
            kHearts++;
            storage.saveHearts(killerUUID, kHearts);
            HeartData.applyMaxHealth(killer, kHearts);
            killer.sendMessage(Text.literal("§a[HeartSystem] You gained a heart! Hearts: " + kHearts), false);
        } else {
            killer.sendMessage(Text.literal("§e[HeartSystem] You killed a player but are already at max hearts (" + max + ")."), false);
        }
    }

    private void banPlayer(ServerPlayerEntity player) {
        MinecraftServer server = player.getServer();
        if (server != null) {
            Text msg = Text.literal("§c[HeartSystem] " + player.getName().getString() + " has been permanently banned (0 hearts).");
            server.getPlayerManager().getPlayerList().forEach(p -> p.sendMessage(msg, false));

            UserBanList banList = server.getPlayerManager().getUserBanList();
            banList.add(new UserBanListEntry(player.getGameProfile(), null, null, null, "Permadeath: ran out of hearts"));

            player.networkHandler.disconnect(Text.literal("§cYou have been permanently banned.\nYou ran out of hearts."));
        }
    }
}