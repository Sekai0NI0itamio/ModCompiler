package asd.itamio.lifestealparrotmod;

import net.fabricmc.api.ModInitializer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class LifestealparrotmodMod implements ModInitializer {
    public static final String MOD_ID = "lifestealparrotmod";
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

    @Override
    public void onInitialize() {
        // Common initialization code goes here – event registration, config setup
        LifestealparrotmodMod.LOGGER.info("Lifestal mod loading…");
    }
}