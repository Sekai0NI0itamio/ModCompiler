package asd.itamio.lifestealparrotmod;

import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.entity.event.v1.ServerLivingEntityEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerEntityEvents;
import net.fabricmc.fabric.api.networking.v1.ServerPlayConnectionEvents;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class LifestealparrotmodMod implements ModInitializer {
    public static final String MOD_ID = "lifestealparrotmod";
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);
    public static final HeartConfig CONFIG = new HeartConfig();

    @Override
    public void onInitialize() {
        HeartStorage.getInstance().loadAll();
        ServerLivingEntityEvents.AFTER_DEATH.register((entity, source) -> {
            if (entity instanceof ServerPlayerEntity player) {
                handlePlayerDeath(player, source);
            }
        });
        ServerPlayConnectionEvents.JOIN.register((handler, sender, server) -> {
            ServerPlayerEntity player = handler.player;
            int hearts = HeartStorage.getInstance().getHearts(player.getUuid());
            if (hearts < 0) hearts = CONFIG.getStartHearts();
            HeartData.applyMaxHealth(player, hearts);
        });
        ServerEntityEvents.ENTITY_LOAD.register((entity, world) -> {
            if (entity instanceof ServerPlayerEntity player) {
                int hearts = HeartStorage.getInstance().getHearts(player.getUuid());
                if (hearts >= 0) HeartData.applyMaxHealth(player, hearts);
            }
        });
        LOGGER.info("Lifesteal Mod initialized");
    }

    private void handlePlayerDeath(ServerPlayerEntity deadPlayer, net.minecraft.entity.damage.DamageSource source) {
        UUID uuid = deadPlayer.getUuid();
        int hearts = HeartStorage.getInstance().getHearts(uuid);
        if (hearts < 0) hearts = CONFIG.getStartHearts();
        hearts--;
        int min = CONFIG.getMinHearts();
        if (hearts <= min) {
            HeartStorage.getInstance().setHearts(uuid, min);
            MinecraftServer server = deadPlayer.getServer();
            if (server != null) {
                Text msg = Text.literal("§c[HeartSystem] " + deadPlayer.getName().getString() + " has been permanently banned (0 hearts).");
                server.getPlayerManager().getPlayerList().forEach(p -> p.sendMessage(msg));
                server.getPlayerManager().getUserBanList().add(new net.minecraft.server.BannedPlayerEntry(deadPlayer.getGameProfile(), null, null, null, "Permadeath: ran out of hearts"));
            }
            deadPlayer.networkHandler.disconnect(Text.literal("§cYou have been permanently banned.\nYou ran out of hearts."));
        } else {
            HeartStorage.getInstance().setHearts(uuid, hearts);
            deadPlayer.sendMessage(Text.literal("§c[HeartSystem] You lost a heart! Hearts remaining: " + hearts));
        }
        if (source.getAttacker() instanceof ServerPlayerEntity killer) {
            UUID kUuid = killer.getUuid();
            int kHearts = HeartStorage.getInstance().getHearts(kUuid);
            if (kHearts < 0) kHearts = CONFIG.getStartHearts();
            int max = CONFIG.getMaxHearts();
            if (kHearts < max) {
                kHearts++;
                HeartStorage.getInstance().setHearts(kUuid, kHearts);
                HeartData.applyMaxHealth(killer, kHearts);
                killer.sendMessage(Text.literal("§a[HeartSystem] You gained a heart! Hearts: " + kHearts));
            }
        }
    }
}