package asd.itamio.lifestealparrotmod;

import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.entity.event.v1.ServerLivingEntityEvents;
import net.minecraft.entity.damage.DamageSource;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.text.Text;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class LifestealparrotmodMod implements ModInitializer {
    public static final String MOD_ID = "lifestealparrotmod";
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);
    public static HeartConfig config;
    public static HeartStorage storage = HeartStorage.get();

    @Override
    public void onInitialize() {
        config = new HeartConfig();
        ServerLivingEntityEvents.AFTER_DEATH.register((entity, source) -> {
            if (entity instanceof ServerPlayerEntity deadPlayer) {
                handlePlayerDeath(deadPlayer, source);
            }
        });
        LOGGER.info("Lifesteal Mod initialized");
    }

    private void handlePlayerDeath(ServerPlayerEntity deadPlayer, DamageSource source) {
        UUID uuid = deadPlayer.getUuid();
        int hearts = storage.getHearts(uuid);
        if (hearts < 0) hearts = config.getStartHearts();

        hearts--;
        int min = config.getMinHearts();
        if (hearts <= min) {
            storage.setHearts(uuid, min);
            banPlayer(deadPlayer);
        } else {
            storage.setHearts(uuid, hearts);
            deadPlayer.sendMessage(Text.literal("§c[HeartSystem] You lost a heart! Hearts remaining: " + hearts), false);
        }

        PlayerEntity killer = getKiller(source);
        if (killer instanceof ServerPlayerEntity killerPlayer && killerPlayer != deadPlayer) {
            handleKiller(killerPlayer);
        }
    }

    private PlayerEntity getKiller(DamageSource source) {
        return source.getAttacker() instanceof PlayerEntity p ? p : null;
    }

    private void handleKiller(ServerPlayerEntity killer) {
        UUID kUuid = killer.getUuid();
        int kHearts = storage.getHearts(kUuid);
        if (kHearts < 0) kHearts = config.getStartHearts();
        int max = config.getMaxHearts();
        if (kHearts < max) {
            kHearts++;
            storage.setHearts(kUuid, kHearts);
            HeartData.applyMaxHealth(killer, kHearts);
            killer.sendMessage(Text.literal("§a[HeartSystem] You gained a heart! Hearts: " + kHearts), false);
        }
    }

    private void banPlayer(ServerPlayerEntity player) {
        player.networkHandler.disconnect(Text.literal("§cYou have been permanently banned.\nYou ran out of hearts."));
        // Ban logic via server command or similar
        LOGGER.info("Permadeath ban for {}", player.getName().getString());
    }
}