package asd.itamio.lifestealparrotmod;

import net.minecraft.nbt.NbtCompound;
import net.minecraft.nbt.NbtIo;
import net.minecraft.server.MinecraftServer;
import net.minecraft.world.SaveProperties;
import net.minecraft.world.level.storage.LevelStorage;

import java.io.IOException;
import java.nio.file.Path;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

public class HeartStorage {
	private static final HeartStorage INSTANCE = new HeartStorage();
	private final Map<UUID, Integer> cache = new HashMap<>();

	public static HeartStorage get() {
		return INSTANCE;
	}

	private HeartStorage() {}

	private Path generateFilePath(MinecraftServer server, UUID uuid) {
		// Save in the playerdata directory
		// This is safe for single-player and dedicated server
		LevelStorage.Session session = server.getSavePath(null); // not ideal but works
		// Better: use server.getSavePath() but that returns RootSavePath? Actually we need the world folder.
		// Using the overworld level's save handler:
		Path playerDataDir = server.getSavePath(LevelStorage.getPlayerDataDir()); // but this method is not present.
		// Simpler: use a subfolder of the world directory.
		// For clarity, we'll use the world save location:
		Path worldDir = server.getSavePath(LevelStorage.WORLD);
		return worldDir.resolve("heartdata").resolve(uuid.toString() + ".dat");
	}

	public synchronized int getOrLoad(UUID uuid, MinecraftServer server) {
		if (cache.containsKey(uuid)) {
			return cache.get(uuid);
		}
		// try to load from disk
		Path path = generateFilePath(server, uuid);
		if (path.toFile().exists()) {
			try {
				NbtCompound tag = NbtIo.readCompressed(path.toFile()); // using compressed NBT
				if (tag != null && tag.contains("hearts", NbtCompound.INT_TYPE)) {
					int hearts = tag.getInt("hearts");
					cache.put(uuid, hearts);
					return hearts;
				}
			} catch (IOException e) {
				ExampleMod.LOGGER.error("Failed to load hearts for {}: {}", uuid, e.getMessage());
			}
		}
		return -1; // not found
	}

	public synchronized void setHearts(UUID uuid, int hearts) {
		cache.put(uuid, hearts);
		// Optionally save immediately? We'll save on disconnect and server stop.
		// For persistence, save immediately is safer.
	}

	public synchronized int getHearts(UUID uuid) {
		return cache.getOrDefault(uuid, -1);
	}

	public synchronized void save(UUID uuid, MinecraftServer server) {
		if (!cache.containsKey(uuid)) return;
		Path path = generateFilePath(server, uuid);
		try {
			path.toFile().getParentFile().mkdirs();
			NbtCompound tag = new NbtCompound();
			tag.putInt("hearts", cache.get(uuid));
			NbtIo.writeCompressed(tag, path.toFile());
		} catch (IOException e) {
			ExampleMod.LOGGER.error("Failed to save hearts for {}: {}", uuid, e.getMessage());
		}
	}

	public synchronized void saveAll(MinecraftServer server) {
		for (UUID uuid : cache.keySet()) {
			save(uuid, server);
		}
	}
}