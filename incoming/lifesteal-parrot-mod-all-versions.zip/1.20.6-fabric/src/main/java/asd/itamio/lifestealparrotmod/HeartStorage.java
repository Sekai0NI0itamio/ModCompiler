package asd.itamio.lifestealparrotmod;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

public class HeartStorage {
    private static final Map<UUID, Integer> heartsMap = new HashMap<>();

    public static int getHearts(UUID uuid) {
        return heartsMap.getOrDefault(uuid, -1);
    }

    public static void setHearts(UUID uuid, int hearts) {
        heartsMap.put(uuid, hearts);
    }

    public static boolean has(UUID uuid) {
        return heartsMap.containsKey(uuid);
    }
}