package asd.itamio.lifestealparrotmod;

import net.minecraft.nbt.NbtCompound;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.world.PersistentState;
import net.minecraft.world.PersistentStateManager;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

public class HeartStorage extends PersistentState {
    private static HeartStorage instance;
    private final Map<UUID, Integer> hearts = new HashMap<>();

    public static void init() {
        // Handled via player data
    }

    public static HeartStorage get(ServerPlayerEntity player) {
        PersistentStateManager manager = player.getServer().getOverworld().getPersistentStateManager();
        return manager.getOrCreate(HeartStorage::new, HeartStorage::new, "lifesteal_hearts");
    }

    public int getHearts(UUID uuid) {
        return hearts.getOrDefault(uuid, -1);
    }

    public void setHearts(UUID uuid, int amount) {
        hearts.put(uuid, amount);
        markDirty();
    }

    @Override
    public NbtCompound writeNbt(NbtCompound nbt) {
        NbtCompound data = new NbtCompound();
        hearts.forEach((uuid, h) -> data.putInt(uuid.toString(), h));
        nbt.put("hearts", data);
        return nbt;
    }

    public static HeartStorage readNbt(NbtCompound nbt) {
        HeartStorage storage = new HeartStorage();
        NbtCompound data = nbt.getCompound("hearts");
        for (String key : data.getKeys()) {
            storage.hearts.put(UUID.fromString(key), data.getInt(key));
        }
        return storage;
    }
}