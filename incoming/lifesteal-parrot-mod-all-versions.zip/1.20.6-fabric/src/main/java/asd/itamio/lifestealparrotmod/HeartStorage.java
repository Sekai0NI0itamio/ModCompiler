package asd.itamio.lifestealparrotmod;

import net.minecraft.nbt.NbtCompound;
import net.minecraft.nbt.NbtIo;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.world.PersistentState;
import net.minecraft.world.PersistentStateManager;
import net.minecraft.world.World;

import java.io.File;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

public class HeartStorage extends PersistentState {
    private static final String DATA_NAME = "lifesteal_parrot_data";
    private final Map<UUID, Integer> heartsMap = new HashMap<>();

    public static HeartStorage getOrCreate(MinecraftServer server) {
        PersistentStateManager manager = server.getWorld(World.OVERWORLD).getPersistentStateManager();
        return manager.getOrCreate(HeartStorage::new, HeartStorage::createFromNbt, DATA_NAME);
    }

    public int getHearts(UUID uuid) {
        return heartsMap.getOrDefault(uuid, LifestealparrotmodMod.getConfig().getStartHearts());
    }

    public void setHearts(UUID uuid, int hearts) {
        heartsMap.put(uuid, hearts);
        markDirty();
    }

    public void remove(UUID uuid) {
        heartsMap.remove(uuid);
        markDirty();
    }

    public boolean has(UUID uuid) {
        return heartsMap.containsKey(uuid);
    }

    public void loadPlayer(ServerPlayerEntity player) {
        UUID uuid = player.getUuid();
        if (!has(uuid)) {
            setHearts(uuid, LifestealparrotmodMod.getConfig().getStartHearts());
        }
        HeartData.applyMaxHealth(player, getHearts(uuid));
    }

    public void savePlayer(ServerPlayerEntity player) {
        // not needed, data is saved via markDirty on set
    }

    @Override
    public NbtCompound writeNbt(NbtCompound nbt) {
        NbtCompound playersTag = new NbtCompound();
        for (Map.Entry<UUID, Integer> entry : heartsMap.entrySet()) {
            playersTag.putInt(entry.getKey().toString(), entry.getValue());
        }
        nbt.put("players", playersTag);
        return nbt;
    }

    public static HeartStorage createFromNbt(NbtCompound tag) {
        HeartStorage storage = new HeartStorage();
        NbtCompound playersTag = tag.getCompound("players");
        for (String key : playersTag.getKeys()) {
            UUID uuid = UUID.fromString(key);
            storage.heartsMap.put(uuid, playersTag.getInt(key));
        }
        return storage;
    }

    public void save() {
        // PersistentState auto-saves when markDirty is called, but we force it on shutdown
        // No explicit action needed here
    }
}