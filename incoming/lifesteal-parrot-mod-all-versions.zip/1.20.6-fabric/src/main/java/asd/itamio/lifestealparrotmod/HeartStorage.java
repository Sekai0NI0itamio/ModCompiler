package asd.itamio.lifestealparrotmod;

import net.minecraft.nbt.NbtCompound;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.world.PersistentState;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

public class HeartStorage extends PersistentState {
    private static final HeartStorage INSTANCE = new HeartStorage();
    private final Map<UUID, Integer> cache = new HashMap<>();

    public static HeartStorage get() { return INSTANCE; }

    public int getHearts(UUID uuid) {
        return cache.getOrDefault(uuid, -1);
    }

    public void setHearts(UUID uuid, int hearts) {
        cache.put(uuid, hearts);
        markDirty();
    }

    public void loadPlayer(ServerPlayerEntity player) {
        // Load from player NBT or persistent
        int h = getHearts(player.getUuid());
        if (h < 0) {
            h = LifestealparrotmodMod.config.getStartHearts();
            setHearts(player.getUuid(), h);
        }
        HeartData.applyMaxHealth(player, h);
    }
}