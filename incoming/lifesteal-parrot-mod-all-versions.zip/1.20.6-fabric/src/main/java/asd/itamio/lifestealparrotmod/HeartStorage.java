package asd.itamio.lifestealparrotmod;

import net.minecraft.nbt.NbtCompound;
import net.minecraft.server.network.ServerPlayerEntity;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

public class HeartStorage {
    private static final HeartStorage INSTANCE = new HeartStorage();
    private final Map<UUID, Integer> cache = new HashMap<>();

    public static HeartStorage get() {
        return INSTANCE;
    }

    public int loadHearts(ServerPlayerEntity player) {
        UUID uuid = player.getUuid();
        if (cache.containsKey(uuid)) {
            return cache.get(uuid);
        }
        NbtCompound nbt = player.getPersistentData();
        if (nbt.contains("lifesteal_hearts")) {
            int hearts = nbt.getInt("lifesteal_hearts");
            cache.put(uuid, hearts);
            return hearts;
        }
        return -1;
    }

    public void saveHearts(ServerPlayerEntity player, int hearts) {
        UUID uuid = player.getUuid();
        cache.put(uuid, hearts);
        NbtCompound nbt = player.getPersistentData();
        nbt.putInt("lifesteal_hearts", hearts);
    }

    public int getHearts(ServerPlayerEntity player) {
        return cache.getOrDefault(player.getUuid(), -1);
    }
}