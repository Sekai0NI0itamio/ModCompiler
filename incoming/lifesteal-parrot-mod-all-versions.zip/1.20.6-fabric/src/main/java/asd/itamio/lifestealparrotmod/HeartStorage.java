package asd.itamio.lifestealparrotmod;

import net.minecraft.nbt.NbtCompound;
import net.minecraft.nbt.NbtIo;
import net.minecraft.server.MinecraftServer;
import net.minecraft.world.level.storage.WorldSavePath;

import java.io.IOException;
import java.nio.file.Path;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

public class HeartStorage {
    private static final HeartStorage INSTANCE = new HeartStorage();
    private final Map<UUID, Integer> cache = new HashMap<>();

    public static HeartStorage get() {
        return INSTANCE;
    }

    private HeartStorage() {}

    private Path getHeartsFile(UUID uuid, MinecraftServer server) {
        Path playerDataDir = server.getSavePath(WorldSavePath.PLAYERDATA);
        return playerDataDir.resolve(uuid.toString() + ".heart.dat");
    }

    public synchronized int getOrLoad(UUID uuid, MinecraftServer server) {
        if (cache.containsKey(uuid)) {
            return cache.get(uuid);
        }
        Path file = getHeartsFile(uuid, server);
        if (file.toFile().exists()) {
            try {
                NbtCompound tag = NbtIo.readCompressed(file.toFile());
                if (tag != null && tag.contains("hearts", NbtCompound.INT_TYPE)) {
                    int hearts = tag.getInt("hearts");
                    cache.put(uuid, hearts);
                    return hearts;
                }
            } catch (IOException e) {
                ExampleMod.LOGGER.error("Failed to load hearts for {}: {}", uuid, e.getMessage());
            }
        }
        return -1;
    }

    public synchronized void setHearts(UUID uuid, int hearts) {
        cache.put(uuid, hearts);
    }

    public synchronized int getHearts(UUID uuid) {
        return cache.getOrDefault(uuid, -1);
    }

    public synchronized void save(UUID uuid, MinecraftServer server) {
        if (!cache.containsKey(uuid)) return;
        Path file = getHeartsFile(uuid, server);
        try {
            file.toFile().getParentFile().mkdirs();
            NbtCompound tag = new NbtCompound();
            tag.putInt("hearts", cache.get(uuid));
            NbtIo.writeCompressed(tag, file.toFile());
        } catch (IOException e) {
            ExampleMod.LOGGER.error("Failed to save hearts for {}: {}", uuid, e.getMessage());
        }
    }

    public synchronized void saveAll(MinecraftServer server) {
        for (UUID uuid : cache.keySet()) {
            save(uuid, server);
        }
    }
}