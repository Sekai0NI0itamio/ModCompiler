package asd.itamio.lifestealparrotmod;

import com.google.gson.Gson;
import com.google.gson.JsonObject;

import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.file.Path;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

public class HeartStorage {
    private static final HeartStorage INSTANCE = new HeartStorage();
    private final Map<UUID, Integer> cache = new HashMap<>();

    private HeartStorage() {}

    public static HeartStorage getInstance() {
        return INSTANCE;
    }

    public int load(UUID uuid, Path file) {
        if (file.toFile().exists()) {
            Gson gson = new Gson();
            try (FileReader reader = new FileReader(file.toFile())) {
                JsonObject obj = gson.fromJson(reader, JsonObject.class);
                if (obj != null && obj.has("hearts")) {
                    int hearts = obj.get("hearts").getAsInt();
                    cache.put(uuid, hearts);
                    return hearts;
                }
            } catch (IOException e) {
                ExampleMod.LOGGER.error("Failed to load hearts for {}: {}", uuid, e.getMessage());
            }
        }
        return -1;
    }

    public void save(UUID uuid, Path file) {
        Integer hearts = cache.get(uuid);
        if (hearts == null) {
            hearts = ExampleMod.CONFIG != null ? ExampleMod.CONFIG.getStartHearts() : 10;
        }
        cache.put(uuid, hearts);
        JsonObject obj = new JsonObject();
        obj.addProperty("hearts", hearts);
        Gson gson = new Gson();
        try (FileWriter writer = new FileWriter(file.toFile())) {
            gson.toJson(obj, writer);
        } catch (IOException e) {
            ExampleMod.LOGGER.error("Failed to save hearts for {}: {}", uuid, e.getMessage());
        }
    }

    public boolean has(UUID uuid) {
        return cache.containsKey(uuid);
    }

    public int getHearts(UUID uuid) {
        Integer h = cache.get(uuid);
        return h != null ? h : -1;
    }

    public void setHearts(UUID uuid, int hearts) {
        cache.put(uuid, hearts);
    }

    public void remove(UUID uuid) {
        cache.remove(uuid);
    }
}