package asd.itamio.lifestealparrotmod;

import net.minecraft.nbt.NbtCompound;
import net.minecraft.nbt.NbtIo;
import net.minecraft.server.MinecraftServer;
import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

public class HeartStorage {
    private static final HeartStorage INSTANCE = new HeartStorage();
    private final Map<UUID, Integer> cache = new HashMap<>();

    public static HeartStorage get() { return INSTANCE; }

    public int loadOrDefault(UUID uuid, int def) {
        if (cache.containsKey(uuid)) return cache.get(uuid);
        // Persistent load would go here in full impl; simplified for server
        cache.put(uuid, def);
        return def;
    }

    public void save(UUID uuid, int hearts) {
        cache.put(uuid, hearts);
        // Full NBT save omitted for brevity; use player data dir in prod
    }

    public int getHearts(UUID uuid) {
        return cache.getOrDefault(uuid, -1);
    }

    public void setHearts(UUID uuid, int hearts) {
        cache.put(uuid, hearts);
    }
}