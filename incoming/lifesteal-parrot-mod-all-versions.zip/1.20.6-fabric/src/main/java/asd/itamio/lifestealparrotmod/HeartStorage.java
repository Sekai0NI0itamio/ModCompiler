package asd.itamio.lifestealparrotmod;

import net.minecraft.nbt.NbtCompound;
import net.minecraft.server.network.ServerPlayerEntity;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

public class HeartStorage {
    private static final HeartStorage INSTANCE = new HeartStorage();
    private final Map<UUID, Integer> cache = new HashMap<>();

    public static HeartStorage get() {
        return INSTANCE;
    }

    public int loadHearts(UUID uuid) {
        if (cache.containsKey(uuid)) {
            return cache.get(uuid);
        }
        return -1;
    }

    public void saveHearts(UUID uuid, int hearts) {
        cache.put(uuid, hearts);
    }

    public int getHearts(UUID uuid) {
        return cache.getOrDefault(uuid, -1);
    }

    public void onPlayerSave(ServerPlayerEntity player) {
        UUID uuid = player.getUuid();
        if (cache.containsKey(uuid)) {
            NbtCompound persistent = player.getCustomData(); // Use custom NBT
            persistent.putInt("lifesteal_hearts", cache.get(uuid));
        }
    }

    public void onPlayerLoad(ServerPlayerEntity player) {
        UUID uuid = player.getUuid();
        NbtCompound persistent = player.getCustomData();
        if (persistent.contains("lifesteal_hearts")) {
            int hearts = persistent.getInt("lifesteal_hearts");
            cache.put(uuid, hearts);
        }
    }
}