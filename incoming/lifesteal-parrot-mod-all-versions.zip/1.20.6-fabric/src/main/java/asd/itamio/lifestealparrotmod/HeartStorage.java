package asd.itamio.lifestealparrotmod;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

public class HeartStorage {
    private static final HeartStorage INSTANCE = new HeartStorage();
    private final Map<UUID, Integer> hearts = new HashMap<>();

    private HeartStorage() {}

    public static HeartStorage getInstance() {
        return INSTANCE;
    }

    public int getHearts(UUID playerUUID) {
        return hearts.getOrDefault(playerUUID, -1); // -1 indicates not loaded
    }

    public void setHearts(UUID playerUUID, int amount) {
        hearts.put(playerUUID, amount);
    }

    /**
     * Load hearts from a JSON file. Returns the number of hearts, or -1 if the file doesn't exist.
     */
    public int load(UUID playerUUID, Path filePath) {
        File file = filePath.toFile();
        if (!file.exists()) {
            return -1;
        }
        try {
            Gson gson = new Gson();
            PlayerData data = gson.fromJson(new FileReader(file), PlayerData.class);
            if (data != null) {
                hearts.put(playerUUID, data.hearts);
                return data.hearts;
            }
        } catch (IOException e) {
            ExampleMod.LOGGER.error("Failed to load hearts for {}", playerUUID, e);
        }
        return -1;
    }

    /**
     * Save hearts for a player to a JSON file.
     */
    public void save(UUID playerUUID, Path filePath) {
        int heartCount = hearts.getOrDefault(playerUUID, -1);
        if (heartCount < 0) return; // not loaded, don't save

        PlayerData data = new PlayerData();
        data.hearts = heartCount;
        try {
            Files.createDirectories(filePath.getParent());
            Gson gson = new GsonBuilder().setPrettyPrinting().create();
            String json = gson.toJson(data);
            Files.writeString(filePath, json);
        } catch (IOException e) {
            ExampleMod.LOGGER.error("Failed to save hearts for {}", playerUUID, e);
        }
    }

    private static class PlayerData {
        int hearts;
    }
}