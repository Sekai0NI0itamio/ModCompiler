package asd.itamio.lifestealparrotmod;

import net.minecraft.nbt.NbtCompound;
import net.minecraft.nbt.NbtIo;
import net.minecraft.server.network.ServerPlayerEntity;
import java.io.File;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

public class HeartStorage {
    private static final HeartStorage INSTANCE = new HeartStorage();
    private final Map<UUID, Integer> cache = new HashMap<>();

    public static HeartStorage getInstance() { return INSTANCE; }

    public int getHearts(UUID uuid) {
        return cache.getOrDefault(uuid, -1);
    }

    public void setHearts(UUID uuid, int hearts) {
        cache.put(uuid, hearts);
    }

    public void loadAll() {
        // Persistence handled via player data in practice; cache on join
    }

    public void savePlayer(ServerPlayerEntity player) {
        // Fabric player data persistence via mixin or ServerPlayerEvents
    }
}