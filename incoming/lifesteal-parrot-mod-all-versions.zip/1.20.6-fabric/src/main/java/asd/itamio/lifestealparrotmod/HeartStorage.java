package asd.itamio.lifestealparrotmod;

import net.minecraft.nbt.NbtCompound;
import net.minecraft.nbt.NbtIo;
import net.minecraft.server.MinecraftServer;
import net.minecraft.world.PersistentState;

import java.io.File;
import java.io.IOException;
import java.nio.file.Path;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

public class HeartStorage {
    private static final HeartStorage INSTANCE = new HeartStorage();
    private final Map<UUID, Integer> cache = new HashMap<>();

    public static HeartStorage get() {
        return INSTANCE;
    }

    private HeartStorage() {}

    public synchronized int getOrLoad(UUID uuid, MinecraftServer server) {
        if (cache.containsKey(uuid)) {
            return cache.get(uuid);
        }
        // Load from world data
        HeartState state = server.getOverworld().getPersistentStateManager().getOrCreate(HeartState::new, HeartState::new, "lifesteal_hearts");
        int hearts = state.getHearts(uuid);
        if (hearts >= 0) {
            cache.put(uuid, hearts);
        }
        return hearts;
    }

    public synchronized void setHearts(UUID uuid, int hearts) {
        cache.put(uuid, hearts);
    }

    public synchronized int getHearts(UUID uuid) {
        return cache.getOrDefault(uuid, -1);
    }

    public synchronized void save(UUID uuid, MinecraftServer server) {
        // Save is handled in saveAll; we don't need per-player save for this approach
    }

    public synchronized void saveAll(MinecraftServer server) {
        if (cache.isEmpty()) return;
        HeartState state = server.getOverworld().getPersistentStateManager().getOrCreate(HeartState::new, HeartState::new, "lifesteal_hearts");
        for (Map.Entry<UUID, Integer> entry : cache.entrySet()) {
            state.setHeart(entry.getKey(), entry.getValue());
        }
        state.markDirty();
    }
}