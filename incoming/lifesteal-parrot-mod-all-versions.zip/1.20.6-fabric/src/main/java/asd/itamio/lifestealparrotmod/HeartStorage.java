package asd.itamio.lifestealparrotmod;

import java.io.File;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.nbt.NbtIo;
import net.minecraft.server.network.ServerPlayerEntity;

public class HeartStorage {
    private static final HeartStorage INSTANCE = new HeartStorage();
    private final Map<UUID, Integer> cache = new HashMap<>();

    public static HeartStorage get() { return INSTANCE; }
    private HeartStorage() {}

    public void loadOrInit(ServerPlayerEntity player, int defaultHearts) {
        UUID uuid = player.getUuid();
        File file = getFile(player);
        if (file.exists()) {
            try {
                NbtCompound tag = NbtIo.read(file.toPath());
                if (tag != null && tag.contains("hearts")) {
                    cache.put(uuid, tag.getInt("hearts"));
                    return;
                }
            } catch (IOException e) {
                LifestealparrotmodMod.LOGGER.error("Failed to load hearts", e);
            }
        }
        cache.put(uuid, defaultHearts);
    }

    public void save(ServerPlayerEntity player) {
        UUID uuid = player.getUuid();
        int hearts = getHearts(uuid);
        if (hearts >= 0) {
            File file = getFile(player);
            NbtCompound tag = new NbtCompound();
            tag.putInt("hearts", hearts);
            try {
                NbtIo.write(tag, file.toPath());
            } catch (IOException e) {
                LifestealparrotmodMod.LOGGER.error("Failed to save hearts", e);
            }
        }
    }

    private File getFile(ServerPlayerEntity player) {
        File worldDir = player.getServerWorld().getServer().getSavePath(net.minecraft.world.WorldSavePath.ROOT).toFile();
        return new File(worldDir, player.getUuid() + ".lifesteal.dat");
    }

    public boolean has(UUID uuid) { return cache.containsKey(uuid); }
    public int getHearts(UUID uuid) { return cache.getOrDefault(uuid, -1); }
    public void setHearts(UUID uuid, int hearts) { cache.put(uuid, hearts); }
    public void copyHearts(UUID from, UUID to) {
        Integer h = cache.get(from);
        if (h != null) cache.put(to, h);
    }
}