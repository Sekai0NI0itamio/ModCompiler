package asd.itamio.lifestealparrotmod;

import java.util.UUID;
import java.util.HashMap;
import java.util.Map;

public class HeartStorage {
    private static final HeartStorage INSTANCE = new HeartStorage();
    private final Map<UUID, Integer> cache = new HashMap<>();

    public static HeartStorage get() {
        return INSTANCE;
    }

    private HeartStorage() {}

    public int getHearts(UUID uuid) {
        Integer h = this.cache.get(uuid);
        return h != null ? h : -1;
    }

    public void setHearts(UUID uuid, int hearts) {
        this.cache.put(uuid, hearts);
    }

    public void remove(UUID uuid) {
        this.cache.remove(uuid);
    }
}