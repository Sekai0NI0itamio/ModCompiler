package asd.itamio.lifestealparrotmod;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

public class HeartStorage {
    private static final HeartStorage INSTANCE = new HeartStorage();
    private final Map<UUID, Integer> cache = new HashMap<>();

    public static HeartStorage get() {
        return INSTANCE;
    }

    public int getHearts(UUID uuid) {
        Integer hearts = cache.get(uuid);
        return hearts != null ? hearts : 10; // Default to 10 hearts
    }

    public void setHearts(UUID uuid, int hearts) {
        cache.put(uuid, hearts);
    }
}