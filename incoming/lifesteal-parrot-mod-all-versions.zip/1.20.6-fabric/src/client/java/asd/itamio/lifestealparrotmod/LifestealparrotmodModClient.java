package asd.itamio.lifestealparrotmod;

import net.fabricmc.api.ClientModInitializer;

public class LifestealparrotmodModClient implements ClientModInitializer {
    @Override
    public void onInitializeClient() {
        // Client-side only logic if needed (none for this server-side mod)
    }
}