package asd.itamio.lifestealparrotmod;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@Environment(EnvType.CLIENT)
public class LifestealparrotmodModClient implements ClientModInitializer {
    @Override
    public void onInitializeClient() {
        // Client-only setup if needed (none for this server mod)
    }
}