package asd.itamio.lifestealparrotmod;

import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;

@Mod(LifestealparrotmodMod.MODID)
public class LifestealparrotmodMod {
    public static final String MODID = "lifestealparrotmod";

    public LifestealparrotmodMod(FMLJavaModLoadingContext context) {
        HeartConfig config = new HeartConfig(context.getModEventBus());
        MinecraftForge.EVENT_BUS.register(new HeartEventHandler());
    }
}