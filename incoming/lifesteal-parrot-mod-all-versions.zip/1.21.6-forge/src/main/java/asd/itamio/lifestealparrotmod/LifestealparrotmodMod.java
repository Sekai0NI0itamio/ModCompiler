package asd.itamio.lifestealparrotmod;

import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;
import net.minecraftforge.eventbus.api.IEventBus;

@Mod(LifestealparrotmodMod.MODID)
public class LifestealparrotmodMod {
    public static final String MODID = "lifestealparrotmod";
    public static HeartConfig config;

    public LifestealparrotmodMod(FMLJavaModLoadingContext context) {
        IEventBus modEventBus = context.getModEventBus();
        config = new HeartConfig(context);
        HeartEventHandler handler = new HeartEventHandler();
        LoadFromFile.BUS.addListener(handler::onPlayerLoad);
        SaveToFile.BUS.addListener(handler::onPlayerSave);
        Clone.BUS.addListener(handler::onPlayerClone);
        LivingDeathEvent.BUS.addListener(handler::onLivingDeath);
    }
}