package asd.itamio.lifestealparrotmod;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class HeartSystemMod {
    public static final Logger logger = LogManager.getLogger();
}