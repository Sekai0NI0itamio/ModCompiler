package asd.itamio.lifestealparrotmod;

import com.mojang.logging.LogUtils;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.ai.attributes.AttributeModifier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.player.Player;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.event.entity.living.LivingDeathEvent;
import net.minecraftforge.event.entity.player.PlayerEvent;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;
import net.minecraftforge.fml.util.thread.SidedThreadGroups;
import org.slf4j.Logger;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

@Mod(LifestealparrotmodMod.MODID)
public class LifestealparrotmodMod {
    public static final String MODID = "lifestealparrotmod";
    private static final Logger LOGGER = LogUtils.getLogger();
    private static final UUID HEALTH_MODIFIER_ID = UUID.fromString("a1b2c3d4-e5f6-7890-abcd-ef1234567890");
    private static final Map<UUID, Integer> playerHearts = new HashMap<>();
    private static final int MIN_HEARTS = 0;
    private static final int DEFAULT_HEARTS = 10;

    public LifestealparrotmodMod(FMLJavaModLoadingContext context) {
        IEventBus modEventBus = context.getModEventBus();
        MinecraftForge.EVENT_BUS.register(this);
        LOGGER.info("Lifesteal Mod initialized");
    }

    @SubscribeEvent
    public void onPlayerDeath(LivingDeathEvent event) {
        if (!(event.getEntity() instanceof ServerPlayer victim)) return;
        int hearts = getHearts(victim);
        hearts = Math.max(MIN_HEARTS, hearts - 1);
        setHearts(victim, hearts);
        if (hearts <= MIN_HEARTS) {
            victim.getServer().getPlayerList().getBannedPlayers().add(new net.minecraft.server.players.BanListEntry(victim.getGameProfile(), null, "Permadeath: ran out of hearts", null, "Permadeath"));
            victim.connection.disconnect(net.minecraft.network.chat.Component.literal("Permadeath: ran out of hearts"));
        }
    }

    @SubscribeEvent
    public void onPlayerKill(LivingDeathEvent event) {
        if (!(event.getSource().getEntity() instanceof ServerPlayer killer)) return;
        if (!(event.getEntity() instanceof ServerPlayer)) return;
        int hearts = getHearts(killer);
        setHearts(killer, hearts + 1);
    }

    @SubscribeEvent
    public void onPlayerLogin(PlayerEvent.PlayerLoggedInEvent event) {
        if (event.getEntity() instanceof ServerPlayer player) {
            applyHealth(player);
        }
    }

    @SubscribeEvent
    public void onPlayerRespawn(PlayerEvent.PlayerRespawnEvent event) {
        if (event.getEntity() instanceof ServerPlayer player) {
            applyHealth(player);
        }
    }

    @SubscribeEvent
    public void onClone(PlayerEvent.Clone event) {
        if (event.isWasDeath() && event.getOriginal() instanceof ServerPlayer oldPlayer) {
            int hearts = getHearts(oldPlayer);
            setHearts((ServerPlayer) event.getEntity(), hearts);
        }
    }

    private int getHearts(ServerPlayer player) {
        return playerHearts.getOrDefault(player.getUUID(), DEFAULT_HEARTS);
    }

    private void setHearts(ServerPlayer player, int hearts) {
        playerHearts.put(player.getUUID(), hearts);
        applyHealth(player);
    }

    private void applyHealth(ServerPlayer player) {
        int hearts = getHearts(player);
        double maxHealth = hearts * 2.0;
        player.getAttribute(Attributes.MAX_HEALTH).removeModifier(HEALTH_MODIFIER_ID);
        player.getAttribute(Attributes.MAX_HEALTH).addPermanentModifier(
            new AttributeModifier(HEALTH_MODIFIER_ID, "Lifesteal hearts", maxHealth - 20.0, AttributeModifier.Operation.ADDITION)
        );
        player.setHealth((float) maxHealth);
    }
}