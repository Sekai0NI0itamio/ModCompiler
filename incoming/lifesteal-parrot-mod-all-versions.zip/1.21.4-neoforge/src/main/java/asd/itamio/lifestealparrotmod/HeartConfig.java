package asd.itamio.lifestealparrotmod;

import net.minecraftforge.common.ForgeConfigSpec;
import net.minecraftforge.common.ForgeConfigSpec.IntValue;

public class HeartConfig {
    private static final ForgeConfigSpec.Builder BUILDER = new ForgeConfigSpec.Builder();
    private static final IntValue START_HEARTS = BUILDER
            .comment("Hearts a new player starts with (1 heart = 2 HP)")
            .defineInRange("startHearts", 10, 1, 100);
    private static final IntValue MAX_HEARTS = BUILDER
            .comment("Maximum hearts a player can have")
            .defineInRange("maxHearts", 20, 1, 100);
    private static final IntValue MIN_HEARTS = BUILDER
            .comment("Minimum hearts before permadeath")
            .defineInRange("minHearts", 0, 0, 99);
    public static final ForgeConfigSpec SPEC = BUILDER.build();

    static {
        BUILDER.comment("Heart System Configuration");
    }

    public int getStartHearts() {
        return START_HEARTS.get();
    }

    public int getMaxHearts() {
        return MAX_HEARTS.get();
    }

    public int getMinHearts() {
        return MIN_HEARTS.get();
    }
}