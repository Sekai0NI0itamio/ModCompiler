package asd.itamio.lifestealparrotmod;

import com.mojang.authlib.GameProfile;
import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.server.players.UserBanList;
import net.minecraft.server.players.UserBanListEntry;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.ai.attributes.AttributeInstance;
import net.minecraft.world.entity.ai.attributes.AttributeModifier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.player.Player;
import net.neoforged.bus.api.EventPriority;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.ModContainer;
import net.neoforged.fml.common.Mod;
import net.neoforged.fml.config.ModConfig;
import net.neoforged.fml.event.lifecycle.FMLCommonSetupEvent;
import net.neoforged.neoforge.common.NeoForge;
import net.neoforged.neoforge.event.entity.living.LivingDeathEvent;
import net.neoforged.neoforge.event.entity.player.PlayerEvent;

import java.io.File;
import java.io.IOException;
import java.nio.file.Path;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

@Mod("lifestealparrotmod")
public class ExampleMod {
    public static final String MOD_ID = "lifestealparrotmod";
    public static HeartConfig config;
    public static HeartStorage storage;

    public ExampleMod(IEventBus modEventBus, ModContainer modContainer) {
        modEventBus.addListener(this::setup);
        NeoForge.EVENT_BUS.register(new HeartEventHandler());
    }

    private void setup(FMLCommonSetupEvent event) {
        config = new HeartConfig();
        storage = new HeartStorage();
    }

    // ======================== Config ========================
    public static class HeartConfig {
        private int startHearts = 10;
        private int maxHearts = 20;
        private int minHearts = 0;

        public HeartConfig() {
            // In a real mod, you'd use NeoForge config system.
            // For simplicity, we hardcode defaults but they could be loaded from a config file.
        }

        public int getStartHearts() { return startHearts; }
        public int getMaxHearts() { return maxHearts; }
        public int getMinHearts() { return minHearts; }
    }

    // ======================== Storage ========================
    public static class HeartStorage {
        private final Map<UUID, Integer> cache = new HashMap<>();
        private static final HeartStorage INSTANCE = new HeartStorage();

        public static HeartStorage get() { return INSTANCE; }

        private Path getPlayerDataDir() {
            // Placeholder: In a real mod, get world data directory.
            return Path.of(".");
        }

        public int load(String playerUUID, Path playerDataPath) {
            UUID uuid = UUID.fromString(playerUUID);
            File file = playerDataPath.resolve("heartsystem.dat").toFile();
            if (file.exists()) {
                // For simplicity, no NBT IO. Just return cached value or default.
                // Real implementation would use NbtIo.
                if (cache.containsKey(uuid)) return cache.get(uuid);
            }
            return -1;
        }

        public void save(String playerUUID, Path playerDataPath, int hearts) {
            UUID uuid = UUID.fromString(playerUUID);
            cache.put(uuid, hearts);
            File file = playerDataPath.resolve("heartsystem.dat").toFile();
            // NBT write omitted for brevity.
        }

        public boolean has(UUID uuid) {
            return cache.containsKey(uuid);
        }

        public int getHearts(UUID uuid) {
            return cache.getOrDefault(uuid, -1);
        }

        public void setHearts(UUID uuid, int hearts) {
            cache.put(uuid, hearts);
        }
    }

    // ======================== Heart Data ========================
    public static class HeartData {
        private static final UUID MODIFIER_UUID = UUID.fromString("8e4d7a3b-5f1c-4e2d-9a6f-1b2c3d4e5f6a");

        public static void applyMaxHealth(ServerPlayer player, int hearts) {
            var attrib = player.getAttribute(Attributes.MAX_HEALTH);
            if (attrib != null) {
                // Remove existing modifier
                attrib.removeModifier(MODIFIER_UUID);
                double delta = hearts * 2.0 - 20.0;
                var modifier = new AttributeModifier(MODIFIER_UUID, "Lifesteal health", delta, AttributeModifier.Operation.ADD_VALUE);
                attrib.addPermanentModifier(modifier);
                float newMax = hearts * 2.0f;
                if (player.getHealth() > newMax) {
                    player.setHealth(newMax);
                }
            }
        }
    }

    // ======================== Event Handler ========================
    public static class HeartEventHandler {
        @SubscribeEvent(priority = EventPriority.NORMAL)
        public void onLivingDeath(LivingDeathEvent event) {
            if (event.getEntity().level().isClientSide()) return;
            if (!(event.getEntity() instanceof ServerPlayer deadPlayer)) return;

            UUID deadUUID = deadPlayer.getUUID();
            int hearts = storage.getHearts(deadUUID);
            if (hearts < 0) hearts = config.getStartHearts();

            hearts--;
            int min = config.getMinHearts();
            if (hearts <= min) {
                storage.setHearts(deadUUID, min);
                MinecraftServer server = deadPlayer.getServer();
                if (server != null) {
                    Component msg = Component.literal(ChatFormatting.RED + "[Lifesteal] " + deadPlayer.getName().getString() + " has been permanently banned (0 hearts).");
                    server.getPlayerList().getPlayers().forEach(p -> p.sendSystemMessage(msg));
                    UserBanList banList = server.getPlayerList().getBans();
                    banList.add(new UserBanListEntry(new GameProfile(deadUUID, deadPlayer.getName().getString()), null, null, null, "Permadeath: ran out of hearts"));
                }
                deadPlayer.connection.disconnect(Component.literal(ChatFormatting.RED + "You have been permanently banned.\nYou ran out of hearts."));
                return;
            }

            storage.setHearts(deadUUID, hearts);
            deadPlayer.sendSystemMessage(Component.literal(ChatFormatting.RED + "[Lifesteal] You lost a heart! Hearts remaining: " + hearts));

            DamageSource source = event.getSource();
            Entity killer = source.getEntity();
            if (killer instanceof ServerPlayer killerPlayer) {
                UUID killerUUID = killerPlayer.getUUID();
                int killerHearts = storage.getHearts(killerUUID);
                if (killerHearts < 0) killerHearts = config.getStartHearts();

                int max = config.getMaxHearts();
                if (killerHearts < max) {
                    storage.setHearts(killerUUID, ++killerHearts);
                    HeartData.applyMaxHealth(killerPlayer, killerHearts);
                    killerPlayer.sendSystemMessage(Component.literal(ChatFormatting.GREEN + "[Lifesteal] You gained a heart! Hearts: " + killerHearts));
                } else {
                    killerPlayer.sendSystemMessage(Component.literal(ChatFormatting.YELLOW + "[Lifesteal] You killed a player but are already at max hearts (" + max + ")."));
                }
            }
        }

        @SubscribeEvent
        public void onPlayerLoad(PlayerEvent.LoadFromFile event) {
            Player player = event.getEntity();
            if (player.level().isClientSide()) return;
            String uuidStr = event.getPlayerUUID();
            Path path = event.getPlayerFile("heartsystem").toPath();
            int loaded = storage.load(uuidStr, path);
            if (loaded < 0) {
                storage.setHearts(player.getUUID(), config.getStartHearts());
            }
        }

        @SubscribeEvent
        public void onPlayerSave(PlayerEvent.SaveToFile event) {
            Player player = event.getEntity();
            if (player.level().isClientSide()) return;
            String uuidStr = event.getPlayerUUID();
            UUID uuid = player.getUUID();
            Path path = event.getPlayerFile("heartsystem").toPath();
            int hearts = storage.getHearts(uuid);
            if (hearts < 0) hearts = config.getStartHearts();
            storage.save(uuidStr, path, hearts);
        }

        @SubscribeEvent
        public void onPlayerClone(PlayerEvent.Clone event) {
            if (event.getEntity().level().isClientSide()) return;
            if (event.isWasDeath()) {
                Player newPlayer = event.getEntity();
                UUID uuid = newPlayer.getUUID();
                if (storage.has(uuid)) {
                    if (newPlayer instanceof ServerPlayer serverPlayer) {
                        int hearts = storage.getHearts(uuid);
                        HeartData.applyMaxHealth(serverPlayer, hearts);
                    }
                }
            }
        }
    }

    // Note: In a real mod, you would also need to subscribe HeartEventHandler to the NeoForge event bus.
    // That is done in the constructor above.
}