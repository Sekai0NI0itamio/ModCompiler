package asd.itamio.lifestealparrotmod;

import net.neoforged.bus.api.IEventBus;
import net.neoforged.fml.ModLoadingContext;
import net.neoforged.fml.common.Mod;
import net.neoforged.fml.config.ModConfig;
import net.neoforged.fml.event.lifecycle.FMLCommonSetupEvent;
import net.neoforged.neoforge.common.NeoForge;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

@Mod("lifestealparrotmod")
public final class LifestealparrotmodMod {
    public static final String MOD_ID = "lifestealparrotmod";
    public static final Logger LOGGER = LogManager.getLogger();
    public static HeartConfig CONFIG;

    public LifestealparrotmodMod(IEventBus modEventBus) {
        modEventBus.addListener(this::commonSetup);
    }

    private void commonSetup(final FMLCommonSetupEvent event) {
        CONFIG = new HeartConfig();
        ModLoadingContext.get().registerConfig(ModConfig.Type.SERVER, HeartConfig.SPEC);
        NeoForge.EVENT_BUS.register(new HeartEventHandler());
    }
}