package asd.itamio.lifestealparrotmod;

import net.neoforged.fml.ModLoadingContext;
import net.neoforged.fml.config.ModConfig;
import net.neoforged.neoforge.common.ModConfigSpec;

public class HeartConfig {
    private static final ModConfigSpec.Builder BUILDER = new ModConfigSpec.Builder();
    private static final ModConfigSpec SPEC;

    public static final ModConfigSpec.IntValue startHearts;
    public static final ModConfigSpec.IntValue maxHearts;
    public static final ModConfigSpec.IntValue minHearts;

    static {
        BUILDER.comment("Heart System Configuration");
        startHearts = BUILDER.comment("Hearts a new player starts with (1 heart = 2 HP)").defineInRange("startHearts", 10, 1, 100);
        maxHearts = BUILDER.comment("Maximum hearts a player can have").defineInRange("maxHearts", 20, 1, 100);
        minHearts = BUILDER.comment("Minimum hearts before permadeath").defineInRange("minHearts", 0, 0, 99);
        SPEC = BUILDER.build();
    }

    public HeartConfig() {
        ModLoadingContext.get().registerConfig(ModConfig.Type.SERVER, SPEC);
    }

    public int getStartHearts() { return startHearts.get(); }
    public int getMaxHearts() { return maxHearts.get(); }
    public int getMinHearts() { return minHearts.get(); }
}