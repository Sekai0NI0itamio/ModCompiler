package asd.itamio.lifestealparrotmod;

import net.neoforged.bus.api.IEventBus;
import net.neoforged.fml.common.Mod;
import net.neoforged.neoforge.common.NeoForge;

@Mod(LifestealparrotmodMod.MODID)
public class LifestealparrotmodMod {
    public static final String MODID = "lifestealparrotmod";

    public static HeartConfig config;

    public LifestealparrotmodMod(IEventBus modEventBus) {
        config = new HeartConfig();
        HeartEventHandler handler = new HeartEventHandler();
        NeoForge.EVENT_BUS.addListener(handler::onPlayerLoad);
        NeoForge.EVENT_BUS.addListener(handler::onPlayerSave);
        NeoForge.EVENT_BUS.addListener(handler::onPlayerClone);
        NeoForge.EVENT_BUS.addListener(handler::onLivingDeath);
    }
}