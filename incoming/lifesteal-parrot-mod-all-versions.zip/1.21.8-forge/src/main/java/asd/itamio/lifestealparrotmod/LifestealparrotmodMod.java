package asd.itamio.lifestealparrotmod;

import com.mojang.logging.LogUtils;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.ai.attributes.AttributeModifier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.event.entity.living.LivingDeathEvent;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;
import org.slf4j.Logger;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

@Mod(LifestealparrotmodMod.MODID)
public class LifestealparrotmodMod {
    public static final String MODID = "lifestealparrotmod";
    private static final Logger LOGGER = LogUtils.getLogger();
    private static final Map<UUID, Integer> playerHearts = new HashMap<>();
    private static final UUID HEALTH_MODIFIER_ID = UUID.fromString("a1b2c3d4-e5f6-7890-abcd-ef1234567890");

    public LifestealparrotmodMod() {
        IEventBus modEventBus = FMLJavaModLoadingContext.get().getModEventBus();
        MinecraftForge.EVENT_BUS.register(this);
        LOGGER.info("Lifesteal Mod initialized");
    }

    @SubscribeEvent
    public void onLivingDeath(LivingDeathEvent event) {
        if (event.getEntity() instanceof ServerPlayer player) {
            int hearts = getHearts(player);
            hearts = Math.max(0, hearts - 1);
            setHearts(player, hearts);
            if (hearts <= 0) {
                player.getServer().getPlayerList().getBannedPlayers().add(new net.minecraft.server.players.BanListEntry(player.getGameProfile(), null, "Permadeath: ran out of hearts", null, "Permadeath"));
                player.connection.disconnect(net.minecraft.network.chat.Component.literal("Permadeath: ran out of hearts"));
            } else {
                updateMaxHealth(player);
            }
        }
        if (event.getSource().getEntity() instanceof ServerPlayer killer) {
            if (event.getEntity() instanceof ServerPlayer) {
                int hearts = getHearts(killer);
                setHearts(killer, hearts + 1);
                updateMaxHealth(killer);
            }
        }
    }

    private int getHearts(ServerPlayer player) {
        return playerHearts.getOrDefault(player.getUUID(), 10);
    }

    private void setHearts(ServerPlayer player, int hearts) {
        playerHearts.put(player.getUUID(), hearts);
    }

    private void updateMaxHealth(ServerPlayer player) {
        int hearts = getHearts(player);
        var attr = player.getAttribute(Attributes.MAX_HEALTH);
        if (attr != null) {
            attr.removeModifier(HEALTH_MODIFIER_ID);
            attr.addPermanentModifier(new AttributeModifier(HEALTH_MODIFIER_ID, "Lifesteal Hearts", hearts * 2.0 - 20.0, AttributeModifier.Operation.ADD_VALUE));
            player.setHealth(player.getMaxHealth());
        }
    }
}