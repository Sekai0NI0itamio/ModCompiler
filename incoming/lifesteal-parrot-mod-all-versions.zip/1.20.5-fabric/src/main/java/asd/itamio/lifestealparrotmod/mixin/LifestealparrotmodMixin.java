package asd.itamio.lifestealparrotmod.mixin;

import asd.itamio.lifestealparrotmod.*;
import com.mojang.authlib.GameProfile;
import net.minecraft.entity.damage.DamageSource;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.players.UserBanList;
import net.minecraft.server.players.UserBanListEntry;
import net.minecraft.text.Text;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(PlayerEntity.class)
public class LifestealparrotmodMixin {
    @Inject(method = "onDeath", at = @At("HEAD"))
    private void onPlayerDeath(DamageSource source, CallbackInfo ci) {
        PlayerEntity self = (PlayerEntity) (Object) this;
        if (self.getWorld().isClient) return;
        if (!(self instanceof ServerPlayerEntity deadPlayer)) return;

        HeartConfig config = LifestealparrotmodMod.config;
        UUID deadUUID = deadPlayer.getUuid();
        int hearts = HeartStorage.get().getHearts(deadUUID);
        if (hearts < 0) hearts = config.getStartHearts();
        --hearts;

        int min = config.getMinHearts();
        if (hearts <= min) {
            HeartStorage.get().setHearts(deadUUID, min);
            MinecraftServer server = deadPlayer.getServer();
            if (server != null) {
                Text msg = Text.literal("§c[HeartSystem] " + deadPlayer.getName().getString() + " has been permanently banned (0 hearts).");
                server.getPlayerManager().getPlayerList().forEach(p -> p.sendMessage(msg, false));
                UserBanList banList = server.getPlayerManager().getUserBanList();
                banList.add(new UserBanListEntry(new GameProfile(deadUUID, deadPlayer.getName().getString()), null, null, null, "Permadeath: ran out of hearts"));
            }
            deadPlayer.networkHandler.disconnect(Text.literal("§cYou have been permanently banned.\nYou ran out of hearts."));
        } else {
            HeartStorage.get().setHearts(deadUUID, hearts);
            deadPlayer.sendMessage(Text.literal("§c[HeartSystem] You lost a heart! Hearts remaining: " + hearts), false);
        }

        if (source.getAttacker() instanceof ServerPlayerEntity killerPlayer) {
            UUID killerUUID = killerPlayer.getUuid();
            int killerHearts = HeartStorage.get().getHearts(killerUUID);
            if (killerHearts < 0) killerHearts = config.getStartHearts();
            int max = config.getMaxHearts();
            if (killerHearts < max) {
                HeartStorage.get().setHearts(killerUUID, ++killerHearts);
                HeartData.applyMaxHealth(killerPlayer, killerHearts);
                killerPlayer.sendMessage(Text.literal("§a[HeartSystem] You gained a heart! Hearts: " + killerHearts), false);
            } else {
                killerPlayer.sendMessage(Text.literal("§e[HeartSystem] You killed a player but are already at max hearts (" + max + ")."), false);
            }
        }
    }
}