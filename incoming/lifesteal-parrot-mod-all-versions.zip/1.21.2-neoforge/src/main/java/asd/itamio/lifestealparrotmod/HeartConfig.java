package asd.itamio.lifestealparrotmod;

import net.neoforged.bus.api.IEventBus;
import net.neoforged.fml.ModContainer;
import net.neoforged.fml.config.ModConfig;
import net.neoforged.neoforge.common.ModConfigSpec;
import net.neoforged.neoforge.common.ModConfigSpec.IntValue;

public class HeartConfig {
    private final IntValue startHearts;
    private final IntValue maxHearts;
    private final IntValue minHearts;

    public HeartConfig(IEventBus modBus, ModContainer container) {
        ModConfigSpec.Builder builder = new ModConfigSpec.Builder();
        builder.comment("Heart System Configuration");
        this.startHearts = builder.comment("Hearts a new player starts with (1 heart = 2 HP)")
                .defineInRange("startHearts", 10, 1, 100);
        this.maxHearts = builder.comment("Maximum hearts a player can have")
                .defineInRange("maxHearts", 20, 1, 100);
        this.minHearts = builder.comment("Minimum hearts before permadeath")
                .defineInRange("minHearts", 0, 0, 99);
        container.registerConfig(ModConfig.Type.SERVER, builder.build());
    }

    public int getStartHearts() {
        return this.startHearts.get();
    }

    public int getMaxHearts() {
        return this.maxHearts.get();
    }

    public int getMinHearts() {
        return this.minHearts.get();
    }
}