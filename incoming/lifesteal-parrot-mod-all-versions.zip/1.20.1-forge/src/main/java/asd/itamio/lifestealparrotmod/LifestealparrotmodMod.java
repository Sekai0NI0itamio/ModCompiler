package asd.itamio.lifestealparrotmod;

import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.event.lifecycle.FMLCommonSetupEvent;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

@Mod(LifestealparrotmodMod.MOD_ID)
public class LifestealparrotmodMod {
    public static final String MOD_ID = "lifestealparrotmod";
    public static final Logger logger = LogManager.getLogger(MOD_ID);
    public static HeartConfig config;

    public LifestealparrotmodMod() {
        FMLJavaModLoadingContext.get().getModEventBus().addListener(this::setup);
        config = new HeartConfig();
        MinecraftForge.EVENT_BUS.register(new HeartEventHandler());
    }

    private void setup(final FMLCommonSetupEvent event) {
        // Common setup if needed
    }
}