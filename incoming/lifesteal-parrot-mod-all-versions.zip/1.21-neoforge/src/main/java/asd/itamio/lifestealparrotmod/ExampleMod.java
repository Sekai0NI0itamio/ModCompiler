package asd.itamio.lifestealparrotmod;

import net.neoforged.fml.common.Mod;

@Mod("lifestealparrotmod")
public final class ExampleMod {
    public ExampleMod() {
    }
}