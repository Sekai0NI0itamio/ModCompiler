package com.seedprotect.mixin;

import net.minecraft.world.level.block.FarmlandBlock;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.entity.Entity;
import net.minecraft.core.BlockPos;
import net.minecraft.world.level.Level;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

// Fabric 26.1+ — Mojang mappings
// Class renamed back to FarmlandBlock (was FarmBlock in 1.21.x)
// fallDistance changed from float to double in 26.1
@Mixin(FarmlandBlock.class)
public abstract class FarmlandBlockMixin {
    @Inject(method = "fallOn", at = @At("HEAD"), cancellable = true)
    private void seedprotect_cancelTrample(Level level, BlockState state,
            BlockPos pos, Entity entity, double fallDistance, CallbackInfo ci) {
        ci.cancel();
    }
}
