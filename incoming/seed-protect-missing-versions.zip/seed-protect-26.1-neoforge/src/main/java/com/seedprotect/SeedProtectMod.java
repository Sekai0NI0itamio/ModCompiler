package com.seedprotect;

import net.neoforged.neoforge.event.level.BlockEvent;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.fml.common.Mod;

// NeoForge 26.1+: @EventBusSubscriber is a standalone annotation (not nested in @Mod).
// No bus= parameter — defaults to the game/Forge bus.
@Mod("seedprotect")
@EventBusSubscriber(modid = "seedprotect")
public final class SeedProtectMod {
    public static final String MOD_ID = "seedprotect";

    @SubscribeEvent
    public static void onFarmlandTrample(BlockEvent.FarmlandTrampleEvent event) {
        event.setCanceled(true);
    }
}
