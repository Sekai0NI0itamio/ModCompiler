package com.seedprotect;

import net.minecraftforge.event.world.BlockEvent.FarmlandTrampleEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod("seedprotect")
@Mod.EventBusSubscriber(modid = "seedprotect", bus = Mod.EventBusSubscriber.Bus.FORGE)
public final class SeedProtectMod {
    public static final String MOD_ID = "seedprotect";
    public static final String NAME = "Seed Protect";
    public static final String VERSION = "1.0.0";

    @SubscribeEvent
    public static void onFarmlandTrample(FarmlandTrampleEvent event) {
        event.setCanceled(true);
    }
}
