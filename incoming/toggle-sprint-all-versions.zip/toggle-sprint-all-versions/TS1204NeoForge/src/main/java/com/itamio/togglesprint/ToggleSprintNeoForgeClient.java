package com.itamio.togglesprint;

import net.minecraft.client.Minecraft;
import net.neoforged.neoforge.event.TickEvent.ClientTickEvent;
import net.neoforged.neoforge.event.TickEvent.Phase;

public final class ToggleSprintNeoForgeClient {
    private static final ToggleSprintController CONTROLLER = new ToggleSprintController();

    private ToggleSprintNeoForgeClient() {}

    public static void onClientTick(ClientTickEvent event) {
        if (event.phase == Phase.END) {
            CONTROLLER.onClientTick(Minecraft.getInstance());
        }
    }
}
