package com.itamio.togglesprint;

import net.minecraft.client.Minecraft;
import net.minecraftforge.event.TickEvent;

public final class ToggleSprintForgeClient {
    private static final ToggleSprintController CONTROLLER = new ToggleSprintController();

    private ToggleSprintForgeClient() {}

    public static void onClientTick(TickEvent.ClientTickEvent.Post event) {
        CONTROLLER.onClientTick(Minecraft.getInstance());
    }
}
