package com.itamio.togglesprint;

import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.eventbus.api.Event;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.loading.FMLEnvironment;

@Mod("togglesprint")
public final class ToggleSprintForgeMod {
    public static final String MOD_ID = "togglesprint";

    public ToggleSprintForgeMod() {
        if (FMLEnvironment.dist == Dist.CLIENT) {
            Event.BUS.addListener(ToggleSprintForgeClient::onClientTick);
        }
    }
}
