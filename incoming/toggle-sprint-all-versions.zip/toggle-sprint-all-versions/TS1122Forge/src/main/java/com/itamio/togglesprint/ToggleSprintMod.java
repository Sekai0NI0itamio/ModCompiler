package com.itamio.togglesprint;

import net.minecraft.client.Minecraft;
import net.minecraft.util.text.TextComponentString;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent;

@Mod(modid = "togglesprint", clientSideOnly = true)
public final class ToggleSprintMod {
    private boolean sprintLocked;
    private boolean sprintKeyWasDown;

    @SubscribeEvent
    public void onClientTick(TickEvent.ClientTickEvent event) {
        if (event.phase != TickEvent.Phase.END) return;
        Minecraft client = Minecraft.getMinecraft();
        if (client == null || client.gameSettings == null) {
            sprintLocked = false;
            sprintKeyWasDown = false;
            return;
        }
        if (client.player == null) {
            sprintLocked = false;
            sprintKeyWasDown = false;
            return;
        }
        if (client.isGamePaused()) {
            sprintKeyWasDown = client.gameSettings.keyBindSprint.isKeyDown();
            return;
        }
        boolean sprintKeyDown = client.gameSettings.keyBindSprint.isKeyDown();
        if (sprintKeyDown && !sprintKeyWasDown) {
            sprintLocked = !sprintLocked;
            client.player.setSprinting(false);
            client.player.sendMessage(
                new TextComponentString("Toggle Sprint: " + (sprintLocked ? "ON" : "OFF")));
        }
        sprintKeyWasDown = sprintKeyDown;
        if (sprintLocked) {
            client.player.setSprinting(shouldKeepSprinting(client));
        }
    }

    private boolean shouldKeepSprinting(Minecraft client) {
        if (client.currentScreen != null) return false;
        if (client.player == null) return false;
        if (client.player.isSpectator() || client.player.isRiding()) return false;
        if (client.player.isSneaking() || client.player.isUsingItem()) return false;
        return client.gameSettings.keyBindForward.isKeyDown()
            && !client.gameSettings.keyBindBack.isKeyDown();
    }
}
