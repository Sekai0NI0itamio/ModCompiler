package com.itamio.togglesprint;

import net.minecraft.client.MinecraftClient;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(MinecraftClient.class)
public class ToggleSprintMixin {
    private static final ToggleSprintController CONTROLLER = new ToggleSprintController();

    @Inject(at = @At("HEAD"), method = "tick")
    private void onClientTick(CallbackInfo ci) {
        CONTROLLER.onClientTick((MinecraftClient)(Object)this);
    }
}
