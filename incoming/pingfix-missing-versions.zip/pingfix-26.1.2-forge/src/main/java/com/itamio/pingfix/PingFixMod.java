package com.itamio.pingfix;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.screens.multiplayer.JoinMultiplayerScreen;
import net.minecraft.client.gui.screens.TitleScreen;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.loading.FMLEnvironment;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;

/**
 * PingFix Forge 1.21.6+ (EventBus 7) — periodically re-opens the server list
 * to force Minecraft to re-ping all servers, fixing stale network route issues.
 */
@Mod(PingFixMod.MOD_ID)
public final class PingFixMod {
    public static final String MOD_ID = "pingfix";
    private static final int REFRESH_INTERVAL_TICKS = 200;
    private int tickCounter = 0;

    public PingFixMod(FMLJavaModLoadingContext context) {
        // Only register the tick listener on the client side
        if (FMLEnvironment.dist == Dist.CLIENT) {
            TickEvent.ClientTickEvent.BUS.addListener(this::onClientTick);
        }
    }

    private void onClientTick(TickEvent.ClientTickEvent event) {
        if (event.phase != TickEvent.Phase.END) return;
        Minecraft mc = Minecraft.getInstance();
        if (mc == null) return;
        if (mc.screen instanceof JoinMultiplayerScreen) {
            tickCounter++;
            if (tickCounter >= REFRESH_INTERVAL_TICKS) {
                tickCounter = 0;
                mc.setScreen(new JoinMultiplayerScreen(new TitleScreen()));
            }
        } else {
            tickCounter = 0;
        }
    }
}
