package com.itamio.pingfix;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.minecraft.client.gui.screens.multiplayer.JoinMultiplayerScreen;
import net.minecraft.client.gui.screens.TitleScreen;

/**
 * PingFix Fabric (Mojang mappings 1.21+)
 * Periodically re-opens the server list to force a fresh ping of all servers.
 * Fixes the bug where Minecraft caches a stale network route after VPN changes.
 */
public final class PingFixClient implements ClientModInitializer {
    public static final String MOD_ID = "pingfix";
    private static final int REFRESH_INTERVAL_TICKS = 200;
    private int tickCounter = 0;

    @Override
    public void onInitializeClient() {
        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            if (client.screen instanceof JoinMultiplayerScreen) {
                tickCounter++;
                if (tickCounter >= REFRESH_INTERVAL_TICKS) {
                    tickCounter = 0;
                    client.setScreen(new JoinMultiplayerScreen(new TitleScreen()));
                }
            } else {
                tickCounter = 0;
            }
        });
    }
}
