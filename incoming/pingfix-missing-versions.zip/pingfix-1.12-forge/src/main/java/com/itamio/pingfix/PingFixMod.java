package com.itamio.pingfix;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiMultiplayer;
import net.minecraft.client.gui.GuiMainMenu;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.Mod.EventHandler;
import net.minecraftforge.fml.common.event.FMLInitializationEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;

/**
 * PingFix Forge 1.12 — periodically re-opens the server list to force
 * Minecraft to re-ping all servers, fixing stale network route issues.
 */
@Mod(modid = PingFixMod.MOD_ID, name = PingFixMod.MOD_NAME,
     version = PingFixMod.MOD_VERSION, clientSideOnly = true,
     acceptableRemoteVersions = "*", acceptedMinecraftVersions = "[1.12,1.12.2]")
public final class PingFixMod {
    public static final String MOD_ID      = "pingfix";
    public static final String MOD_NAME    = "FIX MY PINGGGGG";
    public static final String MOD_VERSION = "1.0.0";

    private static final int REFRESH_INTERVAL_TICKS = 200;
    private int tickCounter = 0;

    @EventHandler
    public void init(FMLInitializationEvent event) {
        if (event.getSide().isClient()) {
            MinecraftForge.EVENT_BUS.register(this);
        }
    }

    @SideOnly(Side.CLIENT)
    @SubscribeEvent
    public void onClientTick(TickEvent.ClientTickEvent event) {
        if (event.phase != TickEvent.Phase.END) return;
        Minecraft mc = Minecraft.getMinecraft();
        if (mc == null) return;
        if (mc.currentScreen instanceof GuiMultiplayer) {
            tickCounter++;
            if (tickCounter >= REFRESH_INTERVAL_TICKS) {
                tickCounter = 0;
                mc.displayGuiScreen(new GuiMultiplayer(new GuiMainMenu()));
            }
        } else {
            tickCounter = 0;
        }
    }
}
