package com.itamio.pingfix;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.screens.multiplayer.JoinMultiplayerScreen;
import net.minecraft.client.gui.screens.TitleScreen;
import net.neoforged.fml.common.Mod;
import net.neoforged.neoforge.client.event.ClientTickEvent;
import net.neoforged.neoforge.common.NeoForge;

/**
 * PingFix NeoForge 1.20.x-1.21.x — periodically re-opens the server list
 * to force Minecraft to re-ping all servers, fixing stale network route issues.
 * Client-only mod (runtime_side=client), no dist check needed.
 */
@Mod(PingFixMod.MOD_ID)
public final class PingFixMod {
    public static final String MOD_ID = "pingfix";
    private static final int REFRESH_INTERVAL_TICKS = 200;
    private int tickCounter = 0;

    public PingFixMod() {
        NeoForge.EVENT_BUS.addListener(this::onClientTick);
    }

    private void onClientTick(ClientTickEvent.Post event) {
        Minecraft mc = Minecraft.getInstance();
        if (mc == null) return;
        if (mc.screen instanceof JoinMultiplayerScreen) {
            tickCounter++;
            if (tickCounter >= REFRESH_INTERVAL_TICKS) {
                tickCounter = 0;
                mc.setScreen(new JoinMultiplayerScreen(new TitleScreen()));
            }
        } else {
            tickCounter = 0;
        }
    }
}
