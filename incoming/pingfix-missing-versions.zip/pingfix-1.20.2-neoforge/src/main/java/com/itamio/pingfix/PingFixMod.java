package com.itamio.pingfix;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.screens.multiplayer.JoinMultiplayerScreen;
import net.minecraft.client.gui.screens.TitleScreen;
import net.neoforged.fml.common.Mod;
import net.neoforged.neoforge.client.event.RenderGuiEvent;
import net.neoforged.neoforge.common.NeoForge;

/**
 * PingFix NeoForge 1.20.2 — ClientTickEvent and LevelTickEvent are not in the
 * public API for NeoForge 20.2.x. Uses RenderGuiEvent.Post (fires every frame,
 * client-only) with a frame counter as a workaround.
 */
@Mod(PingFixMod.MOD_ID)
public final class PingFixMod {
    public static final String MOD_ID = "pingfix";
    // ~1200 frames at 120fps ≈ 10 seconds; at 60fps ≈ 20 seconds. Good enough.
    private static final int REFRESH_INTERVAL_FRAMES = 1200;
    private int frameCounter = 0;

    public PingFixMod() {
        NeoForge.EVENT_BUS.addListener(this::onRenderGui);
    }

    private void onRenderGui(RenderGuiEvent.Post event) {
        Minecraft mc = Minecraft.getInstance();
        if (mc == null) return;
        if (mc.screen instanceof JoinMultiplayerScreen) {
            frameCounter++;
            if (frameCounter >= REFRESH_INTERVAL_FRAMES) {
                frameCounter = 0;
                mc.setScreen(new JoinMultiplayerScreen(new TitleScreen()));
            }
        } else {
            frameCounter = 0;
        }
    }
}
