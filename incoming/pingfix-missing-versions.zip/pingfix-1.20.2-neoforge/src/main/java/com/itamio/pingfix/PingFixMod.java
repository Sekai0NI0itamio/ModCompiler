package com.itamio.pingfix;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.screens.multiplayer.JoinMultiplayerScreen;
import net.minecraft.client.gui.screens.TitleScreen;
import net.neoforged.fml.common.Mod;
import net.neoforged.neoforge.common.NeoForge;
import net.neoforged.neoforge.event.tick.LevelTickEvent;

/**
 * PingFix NeoForge 1.20.2 — ClientTickEvent is not in the public API for NeoForge 20.2.x.
 * Uses LevelTickEvent.Post with isClientSide() check as a workaround.
 * LevelTickEvent fires for both client and server levels — only act on client side.
 */
@Mod(PingFixMod.MOD_ID)
public final class PingFixMod {
    public static final String MOD_ID = "pingfix";
    private static final int REFRESH_INTERVAL_TICKS = 200;
    private int tickCounter = 0;

    public PingFixMod() {
        NeoForge.EVENT_BUS.addListener(this::onLevelTick);
    }

    private void onLevelTick(LevelTickEvent.Post event) {
        if (!event.getLevel().isClientSide()) return;
        Minecraft mc = Minecraft.getInstance();
        if (mc == null) return;
        if (mc.screen instanceof JoinMultiplayerScreen) {
            tickCounter++;
            if (tickCounter >= REFRESH_INTERVAL_TICKS) {
                tickCounter = 0;
                mc.setScreen(new JoinMultiplayerScreen(new TitleScreen()));
            }
        } else {
            tickCounter = 0;
        }
    }
}
