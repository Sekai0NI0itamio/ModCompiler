package io.itamio.aipoweredcompanionship;

import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityTracker;
import net.minecraft.util.IntHashMap;
import net.minecraft.util.math.MathHelper;
import net.minecraft.world.WorldServer;
import net.minecraft.world.chunk.Chunk;
import org.apache.logging.log4j.Logger;

import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.Map;
import java.util.UUID;

public final class CompanionWorldAccess {
    private static Field entitiesByIdField;
    private static Field entitiesByUuidField;

    static {
        try {
            for (Field f : WorldServer.class.getSuperclass().getDeclaredFields()) {
                if (f.getType() == IntHashMap.class) { f.setAccessible(true); entitiesByIdField = f; }
                if (f.getType() == Map.class) { f.setAccessible(true); entitiesByUuidField = f; }
            }
        } catch (Exception ignored) {}
    }

    static boolean register(WorldServer world, CompanionEntity entity, Logger logger) {
        if (world == null || entity == null) return false;
        try {
            int cx = MathHelper.floor(entity.posX) >> 4;
            int cz = MathHelper.floor(entity.posZ) >> 4;
            Chunk chunk = world.getChunkFromChunkCoords(cx, cz);
            chunk.addEntity(entity);
            world.loadedEntityList.add(entity);
            getEntitiesById(world).addKey(entity.getEntityId(), entity);
            getEntitiesByUuid(world).put(entity.getUniqueID(), entity);
            entity.onAddedToWorld();
            removeFromVanillaTracker(world, entity);
            return true;
        } catch (Exception ex) {
            logger.error("Failed to register companion: {}", ex.getMessage());
            cleanup(world, entity);
            return false;
        }
    }

    static void unregister(WorldServer world, CompanionEntity entity, Logger logger) {
        if (world == null || entity == null) return;
        try {
            int cx = MathHelper.floor(entity.posX) >> 4;
            int cz = MathHelper.floor(entity.posZ) >> 4;
            Chunk chunk = world.getChunkFromChunkCoords(cx, cz);
            chunk.removeEntity(entity);
            world.loadedEntityList.remove(entity);
            world.playerEntities.remove(entity);
            getEntitiesById(world).removeObject(entity.getEntityId());
            getEntitiesByUuid(world).remove(entity.getUniqueID());
            removeFromVanillaTracker(world, entity);
        } catch (Exception ex) {
            logger.error("Failed to unregister companion: {}", ex.getMessage());
        }
    }

    @SuppressWarnings("unchecked")
    private static IntHashMap<Entity> getEntitiesById(WorldServer world) {
        try { return (IntHashMap<Entity>) entitiesByIdField.get(world); } catch (Exception e) { throw new RuntimeException(e); }
    }

    @SuppressWarnings("unchecked")
    private static Map<UUID, Entity> getEntitiesByUuid(WorldServer world) {
        try { return (Map<UUID, Entity>) entitiesByUuidField.get(world); } catch (Exception e) { throw new RuntimeException(e); }
    }

    private static void removeFromVanillaTracker(WorldServer world, CompanionEntity entity) {
        try {
            EntityTracker tracker = world.getEntityTracker();
            for (Method method : EntityTracker.class.getDeclaredMethods()) {
                Class<?>[] params = method.getParameterTypes();
                if (params.length == 1 && params[0] == Entity.class) {
                    method.setAccessible(true);
                    method.invoke(tracker, entity);
                    return;
                }
            }
        } catch (Exception ignored) {}
    }

    private static void cleanup(WorldServer world, CompanionEntity entity) {
        try {
            world.loadedEntityList.remove(entity);
            world.playerEntities.remove(entity);
            getEntitiesById(world).removeObject(entity.getEntityId());
            getEntitiesByUuid(world).remove(entity.getUniqueID());
        } catch (Exception ignored) {}
    }
}
