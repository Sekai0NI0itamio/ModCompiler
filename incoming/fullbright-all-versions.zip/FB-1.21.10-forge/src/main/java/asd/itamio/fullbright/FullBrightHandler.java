package asd.itamio.fullbright;

import net.minecraft.client.Minecraft;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;
import java.lang.reflect.Field;

@OnlyIn(Dist.CLIENT)
public class FullBrightHandler {
    private static Field optionsGammaField = null;
    private static Field simpleOptionValueField = null;

    private static void setGamma(Minecraft mc, double value) {
        try {
            if (optionsGammaField == null) {
                optionsGammaField = mc.options.getClass().getDeclaredField("gamma");
                optionsGammaField.setAccessible(true);
            }
            Object gammaOption = optionsGammaField.get(mc.options);
            if (gammaOption == null) return;
            if (simpleOptionValueField == null) {
                simpleOptionValueField = gammaOption.getClass().getDeclaredField("value");
                simpleOptionValueField.setAccessible(true);
            }
            simpleOptionValueField.set(gammaOption, value);
        } catch (Exception e) {
            // ignore
        }
    }

    public static void onClientTick(TickEvent.ClientTickEvent.Post event) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null) return;
        setGamma(mc, 15.0);
    }
}
