package asd.itamio.autofastxp;

import java.io.File;
import net.minecraftforge.common.config.Configuration;

public class AutoFastXPConfig {
   private Configuration config;
   public static boolean enabled = true;
   public static int throwDelay = 1;

   public AutoFastXPConfig(File configFile) {
      this.config = new Configuration(configFile);
      this.load();
   }

   public void load() {
      this.config.load();
      enabled = this.config.getBoolean("enabled", "general", true, "Enable auto fast XP bottle throwing");
      throwDelay = this.config.getInt("throwDelay", "general", 1, 1, 20, "Delay in ticks between XP bottle throws (1 = fastest, 20 = 1 second)");
      if (this.config.hasChanged()) {
         this.config.save();
      }
   }

   public void save() {
      this.config.get("general", "enabled", true).set(enabled);
      this.config.get("general", "throwDelay", 1).set(throwDelay);
      if (this.config.hasChanged()) {
         this.config.save();
      }
   }
}