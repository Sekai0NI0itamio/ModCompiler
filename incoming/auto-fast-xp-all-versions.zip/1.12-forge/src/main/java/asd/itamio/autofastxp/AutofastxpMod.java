package asd.itamio.autofastxp;

import java.io.File;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.Mod.EventHandler;
import net.minecraftforge.fml.common.event.FMLInitializationEvent;
import net.minecraftforge.fml.common.event.FMLPreInitializationEvent;
import org.apache.logging.log4j.Logger;

@Mod(
   modid = "autofastxp",
   name = "Auto Fast XP",
   version = "1.0.0",
   clientSideOnly = true,
   acceptedMinecraftVersions = "[1.12.2]"
)
public class AutofastxpMod {
   public static final String MODID = "autofastxp";
   public static final String NAME = "Auto Fast XP";
   public static final String VERSION = "1.0.0";
   public static Logger logger;
   public static AutoFastXPConfig config;

   @EventHandler
   public void preInit(FMLPreInitializationEvent event) {
      logger = event.getModLog();
      config = new AutoFastXPConfig(new File(event.getModConfigurationDirectory(), "autofastxp.cfg"));
   }

   @EventHandler
   public void init(FMLInitializationEvent event) {
      MinecraftForge.EVENT_BUS.register(new AutoFastXPHandler());
      logger.info("Auto Fast XP mod initialized!");
   }
}