```java
package asd.itamio.autofastxp;

import net.minecraft.client.Minecraft;
import net.minecraft.init.Items;
import net.minecraft.item.ItemStack;
import net.minecraft.util.EnumActionResult;
import net.minecraft.util.EnumHand;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent.ClientTickEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent.Phase;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;

public class AutoFastXPHandler {
    private int tickCounter = 0;
    private boolean wasRightClickPressed = false;

    @SubscribeEvent
    @SideOnly(Side.CLIENT)
    public void onClientTick(ClientTickEvent event) {
        if (event.phase == Phase.START) {
            if (AutoFastXPConfig.enabled) {
                Minecraft mc = Minecraft.getMinecraft();
                if (mc.player != null && mc.world != null) {
                    boolean isRightClickPressed = mc.gameSettings.keyBindUseItem.isKeyDown();
                    EnumHand handWithBottle = null;
                    ItemStack heldItem = mc.player.getHeldItemMainhand();
                    if (!heldItem.isEmpty() && heldItem.getItem() == Items.EXPERIENCE_BOTTLE) {
                        handWithBottle = EnumHand.MAIN_HAND;
                    } else {
                        heldItem = mc.player.getHeldItemOffhand();
                        if (!heldItem.isEmpty() && heldItem.getItem() == Items.EXPERIENCE_BOTTLE) {
                            handWithBottle = EnumHand.OFF_HAND;
                        }
                    }

                    if (isRightClickPressed && handWithBottle != null) {
                        ++this.tickCounter;
                        if (this.tickCounter >= AutoFastXPConfig.throwDelay) {
                            this.throwXPBottle(mc, handWithBottle);
                            this.tickCounter = 0;
                        }

                        this.wasRightClickPressed = true;
                    } else if (this.wasRightClickPressed) {
                        this.tickCounter = 0;
                        this.wasRightClickPressed = false;
                    }
                }
            }
        }
    }

    private void throwXPBottle(Minecraft mc, EnumHand hand) {
        if (mc.player != null && mc.world != null) {
            if (mc.playerController != null) {
                EnumActionResult result = mc.playerController.processRightClick(mc.player, mc.world, hand);
                if (result == EnumActionResult.SUCCESS) {
                    mc.player.swingItem(hand);
                }
            }
        }
    }
}