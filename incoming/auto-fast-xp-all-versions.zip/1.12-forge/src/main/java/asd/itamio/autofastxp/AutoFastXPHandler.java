package asd.itamio.autofastxp;

import net.minecraft.client.Minecraft;
import net.minecraft.init.Items;
import net.minecraft.item.ItemStack;
import net.minecraft.util.EnumActionResult;
import net.minecraft.util.EnumHand;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent.ClientTickEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent.Phase;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;

public class AutoFastXPHandler {
   private int tickCounter = 0;
   private boolean wasRightClickPressed = false;

   @SubscribeEvent
   @SideOnly(Side.CLIENT)
   public void onClientTick(ClientTickEvent event) {
      if (event.phase == Phase.START) {
         if (AutoFastXPConfig.enabled) {
            Minecraft mc = Minecraft.func_71410_x();
            if (mc.field_71439_g != null && mc.field_71441_e != null) {
               boolean isRightClickPressed = mc.field_71474_y.field_74313_G.func_151470_d();
               EnumHand handWithBottle = null;
               ItemStack heldItem = mc.field_71439_g.func_184614_ca();
               if (!heldItem.func_190926_b() && heldItem.func_77973_b() == Items.field_151062_by) {
                  handWithBottle = EnumHand.MAIN_HAND;
               } else {
                  heldItem = mc.field_71439_g.func_184592_cb();
                  if (!heldItem.func_190926_b() && heldItem.func_77973_b() == Items.field_151062_by) {
                     handWithBottle = EnumHand.OFF_HAND;
                  }
               }

               if (isRightClickPressed && handWithBottle != null) {
                  ++this.tickCounter;
                  if (this.tickCounter >= AutoFastXPConfig.throwDelay) {
                     this.throwXPBottle(mc, handWithBottle);
                     this.tickCounter = 0;
                  }

                  this.wasRightClickPressed = true;
               } else if (this.wasRightClickPressed) {
                  this.tickCounter = 0;
                  this.wasRightClickPressed = false;
               }
            }
         }
      }
   }

   private void throwXPBottle(Minecraft mc, EnumHand hand) {
      if (mc.field_71439_g != null && mc.field_71441_e != null) {
         if (mc.field_71442_b != null) {
            EnumActionResult result = mc.field_71442_b.func_187101_a(mc.field_71439_g, mc.field_71441_e, hand);
            if (result == EnumActionResult.SUCCESS) {
               mc.field_71439_g.func_184609_a(hand);
            }
         }
      }
   }
}