package net.itamio.tpateleport;
import net.minecraft.command.CommandSource;
import net.minecraft.command.Commands;
import net.minecraft.entity.player.ServerPlayerEntity;
import net.minecraft.server.MinecraftServer;
import net.minecraft.util.text.StringTextComponent;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.event.RegisterCommandsEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.StringArgumentType;
import java.util.*;
import java.util.concurrent.*;

@Mod(TpaTeleportMod.MODID)
public class TpaTeleportMod {
    public static final String MODID = "tpateleport";
    static final long TIMEOUT_MS = 60_000L;
    static final Map<String, Long> pending = new ConcurrentHashMap<>();

    public TpaTeleportMod() { MinecraftForge.EVENT_BUS.register(this); }

    @SubscribeEvent
    public void onRegisterCommands(RegisterCommandsEvent e) {
        CommandDispatcher<CommandSource> d = e.getDispatcher();
        d.register(Commands.literal("tpa").then(Commands.argument("player", StringArgumentType.word()).executes(ctx -> tpa(ctx.getSource(), StringArgumentType.getString(ctx,"player")))));
        d.register(Commands.literal("tpahere").then(Commands.argument("player", StringArgumentType.word()).executes(ctx -> tpahere(ctx.getSource(), StringArgumentType.getString(ctx,"player")))));
        d.register(Commands.literal("tpaccept").then(Commands.argument("player", StringArgumentType.word()).executes(ctx -> tpaccept(ctx.getSource(), StringArgumentType.getString(ctx,"player")))));
        d.register(Commands.literal("tpacceptall").executes(ctx -> tpacceptall(ctx.getSource())));
        d.register(Commands.literal("tpadeny").then(Commands.argument("player", StringArgumentType.word()).executes(ctx -> tpadeny(ctx.getSource(), StringArgumentType.getString(ctx,"player")))));
        d.register(Commands.literal("tpadenyall").executes(ctx -> tpadenyall(ctx.getSource())));
        d.register(Commands.literal("tpacancel").then(Commands.argument("target", StringArgumentType.word()).executes(ctx -> tpacancel(ctx.getSource(), StringArgumentType.getString(ctx,"target")))));
    }

    static String key(String f, String t) { return f + "->" + t; }
    static void cleanExpired() { long now=System.currentTimeMillis(); pending.entrySet().removeIf(e->now-e.getValue()>TIMEOUT_MS); }

    static int tpa(CommandSource src, String target) throws com.mojang.brigadier.exceptions.CommandSyntaxException {
        ServerPlayerEntity from = src.asPlayer();
        MinecraftServer srv = src.getServer();
        ServerPlayerEntity to = srv.getPlayerList().getPlayerByName(target);
        if (to == null) { src.sendSuccess(new StringTextComponent("Player not found: "+target), false); return 0; }
        if (to == from) { src.sendSuccess(new StringTextComponent("You cannot tpa to yourself."), false); return 0; }
        cleanExpired();
        pending.put(key(from.getName().getString(), to.getName().getString()), System.currentTimeMillis());
        src.sendSuccess(new StringTextComponent("Teleport request sent to "+to.getName().getString()+". Expires in 60s."), false);
        to.sendMessage(new StringTextComponent(from.getName().getString()+" wants to teleport to you. Use /tpaccept or /tpadeny."), to.getUUID());
        return 1;
    }
    static int tpahere(CommandSource src, String target) throws com.mojang.brigadier.exceptions.CommandSyntaxException {
        ServerPlayerEntity from = src.asPlayer();
        MinecraftServer srv = src.getServer();
        ServerPlayerEntity to = srv.getPlayerList().getPlayerByName(target);
        if (to == null) { src.sendSuccess(new StringTextComponent("Player not found: "+target), false); return 0; }
        if (to == from) { src.sendSuccess(new StringTextComponent("You cannot tpahere yourself."), false); return 0; }
        cleanExpired();
        pending.put(key(from.getName().getString(), to.getName().getString())+":here", System.currentTimeMillis());
        src.sendSuccess(new StringTextComponent("Request sent to "+to.getName().getString()+" to come to you. Expires in 60s."), false);
        to.sendMessage(new StringTextComponent(from.getName().getString()+" wants you to teleport to them. Use /tpaccept or /tpadeny."), to.getUUID());
        return 1;
    }
    static int tpaccept(CommandSource src, String requester) throws com.mojang.brigadier.exceptions.CommandSyntaxException {
        ServerPlayerEntity me = src.asPlayer();
        cleanExpired();
        String k = key(requester, me.getName().getString());
        String kh = k+":here";
        MinecraftServer srv = src.getServer();
        if (pending.containsKey(k)) {
            pending.remove(k);
            ServerPlayerEntity req = srv.getPlayerList().getPlayerByName(requester);
            if (req != null) { req.teleportTo(me.getX(),me.getY(),me.getZ()); req.sendMessage(new StringTextComponent("Teleport accepted."), req.getUUID()); }
            src.sendSuccess(new StringTextComponent("Accepted teleport from "+requester+"."), false);
        } else if (pending.containsKey(kh)) {
            pending.remove(kh);
            ServerPlayerEntity req = srv.getPlayerList().getPlayerByName(requester);
            if (req != null) { me.teleportTo(req.getX(),req.getY(),req.getZ()); req.sendMessage(new StringTextComponent("Teleport accepted."), req.getUUID()); }
            src.sendSuccess(new StringTextComponent("Accepted teleport to "+requester+"."), false);
        } else { src.sendSuccess(new StringTextComponent("No pending request from "+requester+"."), false); return 0; }
        return 1;
    }
    static int tpacceptall(CommandSource src) throws com.mojang.brigadier.exceptions.CommandSyntaxException {
        ServerPlayerEntity me = src.asPlayer();
        cleanExpired();
        String myName = me.getName().getString();
        int count = 0;
        MinecraftServer srv = src.getServer();
        for (Iterator<Map.Entry<String,Long>> it = pending.entrySet().iterator(); it.hasNext();) {
            Map.Entry<String,Long> e = it.next();
            String k = e.getKey(); boolean here = k.endsWith(":here");
            String base = here ? k.substring(0,k.length()-5) : k;
            String[] parts = base.split("->"); if (parts.length!=2||!parts[1].equals(myName)) continue;
            it.remove(); count++;
            ServerPlayerEntity req = srv.getPlayerList().getPlayerByName(parts[0]); if (req==null) continue;
            if (here) { me.teleportTo(req.getX(),req.getY(),req.getZ()); } else { req.teleportTo(me.getX(),me.getY(),me.getZ()); }
            req.sendMessage(new StringTextComponent("Teleport accepted."), req.getUUID());
        }
        src.sendSuccess(new StringTextComponent("Accepted "+count+" teleport request(s)."), false); return 1;
    }
    static int tpadeny(CommandSource src, String requester) throws com.mojang.brigadier.exceptions.CommandSyntaxException {
        ServerPlayerEntity me = src.asPlayer();
        cleanExpired();
        String k = key(requester, me.getName().getString());
        boolean removed = pending.remove(k)!=null | pending.remove(k+":here")!=null;
        if (!removed) { src.sendSuccess(new StringTextComponent("No pending request from "+requester+"."), false); return 0; }
        src.sendSuccess(new StringTextComponent("Denied teleport from "+requester+"."), false);
        ServerPlayerEntity req = src.getServer().getPlayerList().getPlayerByName(requester);
        if (req!=null) req.sendMessage(new StringTextComponent(me.getName().getString()+" denied your teleport request."), req.getUUID());
        return 1;
    }
    static int tpadenyall(CommandSource src) throws com.mojang.brigadier.exceptions.CommandSyntaxException {
        ServerPlayerEntity me = src.asPlayer();
        cleanExpired();
        String myName = me.getName().getString(); int count=0;
        for (Iterator<Map.Entry<String,Long>> it = pending.entrySet().iterator(); it.hasNext();) {
            Map.Entry<String,Long> e = it.next();
            String k = e.getKey(); String base = k.endsWith(":here")?k.substring(0,k.length()-5):k;
            String[] parts = base.split("->"); if (parts.length!=2||!parts[1].equals(myName)) continue;
            it.remove(); count++;
            ServerPlayerEntity req = src.getServer().getPlayerList().getPlayerByName(parts[0]);
            if (req!=null) req.sendMessage(new StringTextComponent(myName+" denied your teleport request."), req.getUUID());
        }
        src.sendSuccess(new StringTextComponent("Denied "+count+" teleport request(s)."), false); return 1;
    }
    static int tpacancel(CommandSource src, String target) throws com.mojang.brigadier.exceptions.CommandSyntaxException {
        ServerPlayerEntity me = src.asPlayer();
        String myName = me.getName().getString(); cleanExpired();
        if ("all".equalsIgnoreCase(target)) {
            int count=0;
            for (Iterator<Map.Entry<String,Long>> it = pending.entrySet().iterator(); it.hasNext();) {
                Map.Entry<String,Long> e = it.next();
                String base = e.getKey().endsWith(":here")?e.getKey().substring(0,e.getKey().length()-5):e.getKey();
                if (base.startsWith(myName+"->")) { it.remove(); count++; }
            }
            src.sendSuccess(new StringTextComponent("Cancelled "+count+" outgoing request(s)."), false);
        } else {
            String k = key(myName, target);
            boolean removed = pending.remove(k)!=null | pending.remove(k+":here")!=null;
            if (!removed) { src.sendSuccess(new StringTextComponent("No pending request to "+target+"."), false); return 0; }
            src.sendSuccess(new StringTextComponent("Cancelled request to "+target+"."), false);
        }
        return 1;
    }
}
