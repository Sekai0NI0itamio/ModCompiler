package net.itamio.tpateleport;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.network.chat.TextComponent;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.event.RegisterCommandsEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.StringArgumentType;
import java.util.*;
import java.util.concurrent.*;

@Mod(TpaTeleportMod.MODID)
public class TpaTeleportMod {
    public static final String MODID = "tpateleport";
    static final long TIMEOUT_MS = 60_000L;
    static final Map<String, Long> pending = new ConcurrentHashMap<>();

    public TpaTeleportMod() { MinecraftForge.EVENT_BUS.register(this); }

    @SubscribeEvent
    public void onRegisterCommands(RegisterCommandsEvent e) {
        CommandDispatcher<CommandSourceStack> d = e.getDispatcher();
        d.register(Commands.literal("tpa").then(Commands.argument("player", StringArgumentType.word()).executes(ctx -> tpa(ctx.getSource(), StringArgumentType.getString(ctx,"player")))));
        d.register(Commands.literal("tpahere").then(Commands.argument("player", StringArgumentType.word()).executes(ctx -> tpahere(ctx.getSource(), StringArgumentType.getString(ctx,"player")))));
        d.register(Commands.literal("tpaccept").then(Commands.argument("player", StringArgumentType.word()).executes(ctx -> tpaccept(ctx.getSource(), StringArgumentType.getString(ctx,"player")))));
        d.register(Commands.literal("tpacceptall").executes(ctx -> tpacceptall(ctx.getSource())));
        d.register(Commands.literal("tpadeny").then(Commands.argument("player", StringArgumentType.word()).executes(ctx -> tpadeny(ctx.getSource(), StringArgumentType.getString(ctx,"player")))));
        d.register(Commands.literal("tpadenyall").executes(ctx -> tpadenyall(ctx.getSource())));
        d.register(Commands.literal("tpacancel").then(Commands.argument("target", StringArgumentType.word()).executes(ctx -> tpacancel(ctx.getSource(), StringArgumentType.getString(ctx,"target")))));
    }

    static String key(String f, String t) { return f+"->"+t; }
    static void cleanExpired() { long now=System.currentTimeMillis(); pending.entrySet().removeIf(e->now-e.getValue()>TIMEOUT_MS); }

    static int tpa(CommandSourceStack src, String target) throws com.mojang.brigadier.exceptions.CommandSyntaxException {
        ServerPlayer from = src.getPlayerOrException();
        ServerPlayer to = src.getServer().getPlayerList().getPlayerByName(target);
        if (to==null) { src.sendSuccess(new TextComponent("Player not found: "+target), false); return 0; }
        if (to==from) { src.sendSuccess(new TextComponent("You cannot tpa to yourself."), false); return 0; }
        cleanExpired();
        pending.put(key(from.getName().getString(), to.getName().getString()), System.currentTimeMillis());
        src.sendSuccess(new TextComponent("Teleport request sent to "+to.getName().getString()+". Expires in 60s."), false);
        to.sendMessage(new TextComponent(from.getName().getString()+" wants to teleport to you. Use /tpaccept or /tpadeny."), to.getUUID());
        return 1;
    }
    static int tpahere(CommandSourceStack src, String target) throws com.mojang.brigadier.exceptions.CommandSyntaxException {
        ServerPlayer from = src.getPlayerOrException();
        ServerPlayer to = src.getServer().getPlayerList().getPlayerByName(target);
        if (to==null) { src.sendSuccess(new TextComponent("Player not found: "+target), false); return 0; }
        if (to==from) { src.sendSuccess(new TextComponent("You cannot tpahere yourself."), false); return 0; }
        cleanExpired();
        pending.put(key(from.getName().getString(), to.getName().getString())+":here", System.currentTimeMillis());
        src.sendSuccess(new TextComponent("Request sent to "+to.getName().getString()+" to come to you. Expires in 60s."), false);
        to.sendMessage(new TextComponent(from.getName().getString()+" wants you to teleport to them. Use /tpaccept or /tpadeny."), to.getUUID());
        return 1;
    }
    static int tpaccept(CommandSourceStack src, String requester) throws com.mojang.brigadier.exceptions.CommandSyntaxException {
        ServerPlayer me = src.getPlayerOrException(); cleanExpired();
        String k=key(requester,me.getName().getString()); String kh=k+":here";
        MinecraftServer srv=src.getServer();
        if (pending.containsKey(k)) {
            pending.remove(k); ServerPlayer req=srv.getPlayerList().getPlayerByName(requester);
            if (req!=null) { req.teleportTo(me.getX(),me.getY(),me.getZ()); req.sendMessage(new TextComponent("Teleport accepted."), req.getUUID()); }
            src.sendSuccess(new TextComponent("Accepted teleport from "+requester+"."), false);
        } else if (pending.containsKey(kh)) {
            pending.remove(kh); ServerPlayer req=srv.getPlayerList().getPlayerByName(requester);
            if (req!=null) { me.teleportTo(req.getX(),req.getY(),req.getZ()); req.sendMessage(new TextComponent("Teleport accepted."), req.getUUID()); }
            src.sendSuccess(new TextComponent("Accepted teleport to "+requester+"."), false);
        } else { src.sendSuccess(new TextComponent("No pending request from "+requester+"."), false); return 0; }
        return 1;
    }
    static int tpacceptall(CommandSourceStack src) throws com.mojang.brigadier.exceptions.CommandSyntaxException {
        ServerPlayer me=src.getPlayerOrException(); cleanExpired();
        String myName=me.getName().getString(); int count=0; MinecraftServer srv=src.getServer();
        for (Iterator<Map.Entry<String,Long>> it=pending.entrySet().iterator(); it.hasNext();) {
            Map.Entry<String,Long> e=it.next(); String k=e.getKey(); boolean here=k.endsWith(":here");
            String base=here?k.substring(0,k.length()-5):k; String[] parts=base.split("->");
            if (parts.length!=2||!parts[1].equals(myName)) continue; it.remove(); count++;
            ServerPlayer req=srv.getPlayerList().getPlayerByName(parts[0]); if (req==null) continue;
            if (here) { me.teleportTo(req.getX(),req.getY(),req.getZ()); } else { req.teleportTo(me.getX(),me.getY(),me.getZ()); }
            req.sendMessage(new TextComponent("Teleport accepted."), req.getUUID());
        }
        src.sendSuccess(new TextComponent("Accepted "+count+" teleport request(s)."), false); return 1;
    }
    static int tpadeny(CommandSourceStack src, String requester) throws com.mojang.brigadier.exceptions.CommandSyntaxException {
        ServerPlayer me=src.getPlayerOrException(); cleanExpired();
        String k=key(requester,me.getName().getString());
        boolean removed=pending.remove(k)!=null|pending.remove(k+":here")!=null;
        if (!removed) { src.sendSuccess(new TextComponent("No pending request from "+requester+"."), false); return 0; }
        src.sendSuccess(new TextComponent("Denied teleport from "+requester+"."), false);
        ServerPlayer req=src.getServer().getPlayerList().getPlayerByName(requester);
        if (req!=null) req.sendMessage(new TextComponent(me.getName().getString()+" denied your teleport request."), req.getUUID());
        return 1;
    }
    static int tpadenyall(CommandSourceStack src) throws com.mojang.brigadier.exceptions.CommandSyntaxException {
        ServerPlayer me=src.getPlayerOrException(); cleanExpired();
        String myName=me.getName().getString(); int count=0;
        for (Iterator<Map.Entry<String,Long>> it=pending.entrySet().iterator(); it.hasNext();) {
            Map.Entry<String,Long> e=it.next(); String k=e.getKey();
            String base=k.endsWith(":here")?k.substring(0,k.length()-5):k; String[] parts=base.split("->");
            if (parts.length!=2||!parts[1].equals(myName)) continue; it.remove(); count++;
            ServerPlayer req=src.getServer().getPlayerList().getPlayerByName(parts[0]);
            if (req!=null) req.sendMessage(new TextComponent(me.getName().getString()+" denied your teleport request."), req.getUUID());
        }
        src.sendSuccess(new TextComponent("Denied "+count+" teleport request(s)."), false); return 1;
    }
    static int tpacancel(CommandSourceStack src, String target) throws com.mojang.brigadier.exceptions.CommandSyntaxException {
        ServerPlayer me=src.getPlayerOrException(); String myName=me.getName().getString(); cleanExpired();
        if ("all".equalsIgnoreCase(target)) {
            int count=0;
            for (Iterator<Map.Entry<String,Long>> it=pending.entrySet().iterator(); it.hasNext();) {
                Map.Entry<String,Long> e=it.next();
                String base=e.getKey().endsWith(":here")?e.getKey().substring(0,e.getKey().length()-5):e.getKey();
                if (base.startsWith(myName+"->")) { it.remove(); count++; }
            }
            src.sendSuccess(new TextComponent("Cancelled "+count+" outgoing request(s)."), false);
        } else {
            String k=key(myName,target);
            boolean removed=pending.remove(k)!=null|pending.remove(k+":here")!=null;
            if (!removed) { src.sendSuccess(new TextComponent("No pending request to "+target+"."), false); return 0; }
            src.sendSuccess(new TextComponent("Cancelled request to "+target+"."), false);
        }
        return 1;
    }
}
