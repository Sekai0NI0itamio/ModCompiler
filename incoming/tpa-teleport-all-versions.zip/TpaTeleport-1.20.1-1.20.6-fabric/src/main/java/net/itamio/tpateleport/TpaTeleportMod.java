package net.itamio.tpateleport;
import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.StringArgumentType;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.minecraft.server.command.CommandManager;
import net.minecraft.server.command.ServerCommandSource;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.text.Text;
import java.util.*;
import java.util.concurrent.*;

public class TpaTeleportMod implements ModInitializer {
    static final long TIMEOUT_MS = 60_000L;
    static final Map<String, Long> pending = new ConcurrentHashMap<>();

    @Override
    public void onInitialize() {
        CommandRegistrationCallback.EVENT.register((dispatcher, registryAccess, dedicated) -> register(dispatcher));
    }

    static String key(String f, String t) { return f+"->"+t; }
    static void cleanExpired() { long now=System.currentTimeMillis(); pending.entrySet().removeIf(e->now-e.getValue()>TIMEOUT_MS); }

    static void register(CommandDispatcher<ServerCommandSource> d) {
        d.register(CommandManager.literal("tpa").then(CommandManager.argument("player", StringArgumentType.word()).executes(ctx -> tpa(ctx.getSource(), StringArgumentType.getString(ctx,"player")))));
        d.register(CommandManager.literal("tpahere").then(CommandManager.argument("player", StringArgumentType.word()).executes(ctx -> tpahere(ctx.getSource(), StringArgumentType.getString(ctx,"player")))));
        d.register(CommandManager.literal("tpaccept").then(CommandManager.argument("player", StringArgumentType.word()).executes(ctx -> tpaccept(ctx.getSource(), StringArgumentType.getString(ctx,"player")))));
        d.register(CommandManager.literal("tpacceptall").executes(ctx -> tpacceptall(ctx.getSource())));
        d.register(CommandManager.literal("tpadeny").then(CommandManager.argument("player", StringArgumentType.word()).executes(ctx -> tpadeny(ctx.getSource(), StringArgumentType.getString(ctx,"player")))));
        d.register(CommandManager.literal("tpadenyall").executes(ctx -> tpadenyall(ctx.getSource())));
        d.register(CommandManager.literal("tpacancel").then(CommandManager.argument("target", StringArgumentType.word()).executes(ctx -> tpacancel(ctx.getSource(), StringArgumentType.getString(ctx,"target")))));
    }

    static int tpa(ServerCommandSource src, String target) throws com.mojang.brigadier.exceptions.CommandSyntaxException {
        ServerPlayerEntity from = src.getPlayer();
        ServerPlayerEntity to = src.getMinecraftServer().getPlayerManager().getPlayer(target);
        if (to==null) { src.sendFeedback(() -> Text.literal("Player not found: "+target), false); return 0; }
        if (to==from) { src.sendFeedback(() -> Text.literal("You cannot tpa to yourself."), false); return 0; }
        cleanExpired();
        pending.put(key(from.getName().getString(), to.getName().getString()), System.currentTimeMillis());
        src.sendFeedback(() -> Text.literal("Teleport request sent to "+to.getName().getString()+". Expires in 60s."), false);
        to.sendMessage(Text.literal(from.getName().getString()+" wants to teleport to you. Use /tpaccept or /tpadeny."), false);
        return 1;
    }
    static int tpahere(ServerCommandSource src, String target) throws com.mojang.brigadier.exceptions.CommandSyntaxException {
        ServerPlayerEntity from = src.getPlayer();
        ServerPlayerEntity to = src.getMinecraftServer().getPlayerManager().getPlayer(target);
        if (to==null) { src.sendFeedback(() -> Text.literal("Player not found: "+target), false); return 0; }
        if (to==from) { src.sendFeedback(() -> Text.literal("You cannot tpahere yourself."), false); return 0; }
        cleanExpired();
        pending.put(key(from.getName().getString(), to.getName().getString())+":here", System.currentTimeMillis());
        src.sendFeedback(() -> Text.literal("Request sent to "+to.getName().getString()+" to come to you. Expires in 60s."), false);
        to.sendMessage(Text.literal(from.getName().getString()+" wants you to teleport to them. Use /tpaccept or /tpadeny."), false);
        return 1;
    }
    static int tpaccept(ServerCommandSource src, String requester) throws com.mojang.brigadier.exceptions.CommandSyntaxException {
        ServerPlayerEntity me = src.getPlayer(); cleanExpired();
        String k=key(requester,me.getName().getString()); String kh=k+":here";
        if (pending.containsKey(k)) {
            pending.remove(k); ServerPlayerEntity req=src.getMinecraftServer().getPlayerManager().getPlayer(requester);
            if (req!=null) { req.teleport(me.getX(),me.getY(),me.getZ()); req.sendMessage(Text.literal("Teleport accepted."), false); }
            src.sendFeedback(() -> Text.literal("Accepted teleport from "+requester+"."), false);
        } else if (pending.containsKey(kh)) {
            pending.remove(kh); ServerPlayerEntity req=src.getMinecraftServer().getPlayerManager().getPlayer(requester);
            if (req!=null) { me.teleport(req.getX(),req.getY(),req.getZ()); req.sendMessage(Text.literal("Teleport accepted."), false); }
            src.sendFeedback(() -> Text.literal("Accepted teleport to "+requester+"."), false);
        } else { src.sendFeedback(() -> Text.literal("No pending request from "+requester+"."), false); return 0; }
        return 1;
    }
    static int tpacceptall(ServerCommandSource src) throws com.mojang.brigadier.exceptions.CommandSyntaxException {
        ServerPlayerEntity me = src.getPlayer(); cleanExpired();
        String myName=me.getName().getString(); int count=0;
        for (Iterator<Map.Entry<String,Long>> it=pending.entrySet().iterator(); it.hasNext();) {
            Map.Entry<String,Long> e=it.next(); String k=e.getKey(); boolean here=k.endsWith(":here");
            String base=here?k.substring(0,k.length()-5):k; String[] parts=base.split("->");
            if (parts.length!=2||!parts[1].equals(myName)) continue; it.remove(); count++;
            ServerPlayerEntity req=src.getMinecraftServer().getPlayerManager().getPlayer(parts[0]); if (req==null) continue;
            if (here) { me.teleport(req.getX(),req.getY(),req.getZ()); } else { req.teleport(me.getX(),me.getY(),me.getZ()); }
            req.sendMessage(Text.literal("Teleport accepted."), false);
        }
        final int finalCount=count; src.sendFeedback(() -> Text.literal("Accepted "+finalCount+" teleport request(s)."), false); return 1;
    }
    static int tpadeny(ServerCommandSource src, String requester) throws com.mojang.brigadier.exceptions.CommandSyntaxException {
        ServerPlayerEntity me = src.getPlayer(); cleanExpired();
        String k=key(requester,me.getName().getString());
        boolean removed=pending.remove(k)!=null|pending.remove(k+":here")!=null;
        if (!removed) { src.sendFeedback(() -> Text.literal("No pending request from "+requester+"."), false); return 0; }
        src.sendFeedback(() -> Text.literal("Denied teleport from "+requester+"."), false);
        ServerPlayerEntity req=src.getMinecraftServer().getPlayerManager().getPlayer(requester);
        if (req!=null) req.sendMessage(Text.literal(me.getName().getString()+" denied your teleport request."), false);
        return 1;
    }
    static int tpadenyall(ServerCommandSource src) throws com.mojang.brigadier.exceptions.CommandSyntaxException {
        ServerPlayerEntity me = src.getPlayer(); cleanExpired();
        String myName=me.getName().getString(); int count=0;
        for (Iterator<Map.Entry<String,Long>> it=pending.entrySet().iterator(); it.hasNext();) {
            Map.Entry<String,Long> e=it.next(); String k=e.getKey();
            String base=k.endsWith(":here")?k.substring(0,k.length()-5):k; String[] parts=base.split("->");
            if (parts.length!=2||!parts[1].equals(myName)) continue; it.remove(); count++;
            ServerPlayerEntity req=src.getMinecraftServer().getPlayerManager().getPlayer(parts[0]);
            if (req!=null) req.sendMessage(Text.literal(myName+" denied your teleport request."), false);
        }
        final int finalCount=count; src.sendFeedback(() -> Text.literal("Denied "+finalCount+" teleport request(s)."), false); return 1;
    }
    static int tpacancel(ServerCommandSource src, String target) throws com.mojang.brigadier.exceptions.CommandSyntaxException {
        ServerPlayerEntity me = src.getPlayer(); String myName=me.getName().getString(); cleanExpired();
        if ("all".equalsIgnoreCase(target)) {
            int count=0;
            for (Iterator<Map.Entry<String,Long>> it=pending.entrySet().iterator(); it.hasNext();) {
                Map.Entry<String,Long> e=it.next();
                String base=e.getKey().endsWith(":here")?e.getKey().substring(0,e.getKey().length()-5):e.getKey();
                if (base.startsWith(myName+"->")) { it.remove(); count++; }
            }
            final int finalCount=count; src.sendFeedback(() -> Text.literal("Cancelled "+finalCount+" outgoing request(s)."), false);
        } else {
            String k=key(myName,target);
            boolean removed=pending.remove(k)!=null|pending.remove(k+":here")!=null;
            if (!removed) { src.sendFeedback(() -> Text.literal("No pending request to "+target+"."), false); return 0; }
            src.sendFeedback(() -> Text.literal("Cancelled request to "+target+"."), false);
        }
        return 1;
    }
}
