package net.itamio.tpateleport;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.network.chat.Component;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.event.RegisterCommandsEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;
import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.StringArgumentType;
import java.util.*;
import java.util.concurrent.*;

@Mod(TpaTeleportMod.MODID)
public class TpaTeleportMod {
    public static final String MODID = "tpateleport";
    static final long TIMEOUT_MS = 60_000L;
    static final Map<String, Long> pending = new ConcurrentHashMap<>();

    public TpaTeleportMod(FMLJavaModLoadingContext context) {
        RegisterCommandsEvent.BUS.addListener(TpaTeleportMod::onRegisterCommands);
    }

    static void onRegisterCommands(RegisterCommandsEvent e) {
        CommandDispatcher<CommandSourceStack> d = e.getDispatcher();
        d.register(Commands.literal("tpa").then(Commands.argument("player", StringArgumentType.word()).executes(ctx -> tpa(ctx.getSource(), StringArgumentType.getString(ctx,"player")))));
        d.register(Commands.literal("tpahere").then(Commands.argument("player", StringArgumentType.word()).executes(ctx -> tpahere(ctx.getSource(), StringArgumentType.getString(ctx,"player")))));
        d.register(Commands.literal("tpaccept").then(Commands.argument("player", StringArgumentType.word()).executes(ctx -> tpaccept(ctx.getSource(), StringArgumentType.getString(ctx,"player")))));
        d.register(Commands.literal("tpacceptall").executes(ctx -> tpacceptall(ctx.getSource())));
        d.register(Commands.literal("tpadeny").then(Commands.argument("player", StringArgumentType.word()).executes(ctx -> tpadeny(ctx.getSource(), StringArgumentType.getString(ctx,"player")))));
        d.register(Commands.literal("tpadenyall").executes(ctx -> tpadenyall(ctx.getSource())));
        d.register(Commands.literal("tpacancel").then(Commands.argument("target", StringArgumentType.word()).executes(ctx -> tpacancel(ctx.getSource(), StringArgumentType.getString(ctx,"target")))));
    }

    static String key(String f, String t) { return f+"->"+t; }
    static void cleanExpired() { long now=System.currentTimeMillis(); pending.entrySet().removeIf(e->now-e.getValue()>TIMEOUT_MS); }

    static int tpa(CommandSourceStack src, String target) throws com.mojang.brigadier.exceptions.CommandSyntaxException {
        ServerPlayer from=src.getPlayerOrException();
        ServerPlayer to=src.getServer().getPlayerList().getPlayerByName(target);
        if (to==null) { src.sendSuccess(()->Component.literal("Player not found: "+target), false); return 0; }
        if (to==from) { src.sendSuccess(()->Component.literal("You cannot tpa to yourself."), false); return 0; }
        cleanExpired();
        pending.put(key(from.getName().getString(), to.getName().getString()), System.currentTimeMillis());
        src.sendSuccess(()->Component.literal("Teleport request sent to "+to.getName().getString()+". Expires in 60s."), false);
        to.sendSystemMessage(Component.literal(from.getName().getString()+" wants to teleport to you. Use /tpaccept or /tpadeny."));
        return 1;
    }
    static int tpahere(CommandSourceStack src, String target) throws com.mojang.brigadier.exceptions.CommandSyntaxException {
        ServerPlayer from=src.getPlayerOrException();
        ServerPlayer to=src.getServer().getPlayerList().getPlayerByName(target);
        if (to==null) { src.sendSuccess(()->Component.literal("Player not found: "+target), false); return 0; }
        if (to==from) { src.sendSuccess(()->Component.literal("You cannot tpahere yourself."), false); return 0; }
        cleanExpired();
        pending.put(key(from.getName().getString(), to.getName().getString())+":here", System.currentTimeMillis());
        src.sendSuccess(()->Component.literal("Request sent to "+to.getName().getString()+" to come to you. Expires in 60s."), false);
        to.sendSystemMessage(Component.literal(from.getName().getString()+" wants you to teleport to them. Use /tpaccept or /tpadeny."));
        return 1;
    }
    static int tpaccept(CommandSourceStack src, String requester) throws com.mojang.brigadier.exceptions.CommandSyntaxException {
        ServerPlayer me=src.getPlayerOrException(); cleanExpired();
        String k=key(requester,me.getName().getString()); String kh=k+":here";
        MinecraftServer srv=src.getServer();
        if (pending.containsKey(k)) {
            pending.remove(k); ServerPlayer req=srv.getPlayerList().getPlayerByName(requester);
            if (req!=null) { req.teleportTo(me.getX(),me.getY(),me.getZ()); req.sendSystemMessage(Component.literal("Teleport accepted.")); }
            src.sendSuccess(()->Component.literal("Accepted teleport from "+requester+"."), false);
        } else if (pending.containsKey(kh)) {
            pending.remove(kh); ServerPlayer req=srv.getPlayerList().getPlayerByName(requester);
            if (req!=null) { me.teleportTo(req.getX(),req.getY(),req.getZ()); req.sendSystemMessage(Component.literal("Teleport accepted.")); }
            src.sendSuccess(()->Component.literal("Accepted teleport to "+requester+"."), false);
        } else { src.sendSuccess(()->Component.literal("No pending request from "+requester+"."), false); return 0; }
        return 1;
    }
    static int tpacceptall(CommandSourceStack src) throws com.mojang.brigadier.exceptions.CommandSyntaxException {
        ServerPlayer me=src.getPlayerOrException(); cleanExpired();
        String myName=me.getName().getString(); int count=0; MinecraftServer srv=src.getServer();
        for (Iterator<Map.Entry<String,Long>> it=pending.entrySet().iterator(); it.hasNext();) {
            Map.Entry<String,Long> e=it.next(); String k=e.getKey(); boolean here=k.endsWith(":here");
            String base=here?k.substring(0,k.length()-5):k; String[] parts=base.split("->");
            if (parts.length!=2||!parts[1].equals(myName)) continue; it.remove(); count++;
            ServerPlayer req=srv.getPlayerList().getPlayerByName(parts[0]); if (req==null) continue;
            if (here) { me.teleportTo(req.getX(),req.getY(),req.getZ()); } else { req.teleportTo(me.getX(),me.getY(),me.getZ()); }
            req.sendSystemMessage(Component.literal("Teleport accepted."));
        }
        final int finalCount=count; src.sendSuccess(()->Component.literal("Accepted "+finalCount+" teleport request(s)."), false); return 1;
    }
    static int tpadeny(CommandSourceStack src, String requester) throws com.mojang.brigadier.exceptions.CommandSyntaxException {
        ServerPlayer me=src.getPlayerOrException(); cleanExpired();
        String k=key(requester,me.getName().getString());
        boolean removed=pending.remove(k)!=null|pending.remove(k+":here")!=null;
        if (!removed) { src.sendSuccess(()->Component.literal("No pending request from "+requester+"."), false); return 0; }
        src.sendSuccess(()->Component.literal("Denied teleport from "+requester+"."), false);
        ServerPlayer req=src.getServer().getPlayerList().getPlayerByName(requester);
        if (req!=null) req.sendSystemMessage(Component.literal(me.getName().getString()+" denied your teleport request."));
        return 1;
    }
    static int tpadenyall(CommandSourceStack src) throws com.mojang.brigadier.exceptions.CommandSyntaxException {
        ServerPlayer me=src.getPlayerOrException(); cleanExpired();
        String myName=me.getName().getString(); int count=0;
        for (Iterator<Map.Entry<String,Long>> it=pending.entrySet().iterator(); it.hasNext();) {
            Map.Entry<String,Long> e=it.next(); String k=e.getKey();
            String base=k.endsWith(":here")?k.substring(0,k.length()-5):k; String[] parts=base.split("->");
            if (parts.length!=2||!parts[1].equals(myName)) continue; it.remove(); count++;
            ServerPlayer req=src.getServer().getPlayerList().getPlayerByName(parts[0]);
            if (req!=null) req.sendSystemMessage(Component.literal(myName+" denied your teleport request."));
        }
        final int finalCount=count; src.sendSuccess(()->Component.literal("Denied "+finalCount+" teleport request(s)."), false); return 1;
    }
    static int tpacancel(CommandSourceStack src, String target) throws com.mojang.brigadier.exceptions.CommandSyntaxException {
        ServerPlayer me=src.getPlayerOrException(); String myName=me.getName().getString(); cleanExpired();
        if ("all".equalsIgnoreCase(target)) {
            int count=0;
            for (Iterator<Map.Entry<String,Long>> it=pending.entrySet().iterator(); it.hasNext();) {
                Map.Entry<String,Long> e=it.next();
                String base=e.getKey().endsWith(":here")?e.getKey().substring(0,e.getKey().length()-5):e.getKey();
                if (base.startsWith(myName+"->")) { it.remove(); count++; }
            }
            final int finalCount=count; src.sendSuccess(()->Component.literal("Cancelled "+finalCount+" outgoing request(s)."), false);
        } else {
            String k=key(myName,target);
            boolean removed=pending.remove(k)!=null|pending.remove(k+":here")!=null;
            if (!removed) { src.sendSuccess(()->Component.literal("No pending request to "+target+"."), false); return 0; }
            src.sendSuccess(()->Component.literal("Cancelled request to "+target+"."), false);
        }
        return 1;
    }
}
