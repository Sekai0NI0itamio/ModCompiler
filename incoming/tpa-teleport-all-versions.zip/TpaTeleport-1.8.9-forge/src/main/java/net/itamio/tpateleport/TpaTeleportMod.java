package net.itamio.tpateleport;
import net.minecraft.command.CommandBase;
import net.minecraft.command.CommandException;
import net.minecraft.command.ICommandSender;
import net.minecraft.entity.player.EntityPlayerMP;
import net.minecraft.server.MinecraftServer;
import net.minecraft.util.ChatComponentText;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.event.FMLServerStartingEvent;
import java.util.*;
import java.util.concurrent.*;

@Mod(modid=TpaTeleportMod.MODID, name="Tpa Teleport", version="1.0.0", acceptedMinecraftVersions="[1.8.9]")
public class TpaTeleportMod {
    public static final String MODID = "tpateleport";
    static final long TIMEOUT_MS = 60000L;
    static final Map<String, Long> pending = new ConcurrentHashMap<String, Long>();

    @Mod.EventHandler
    public void serverStarting(FMLServerStartingEvent e) {
        e.registerServerCommand(new TpaCmd());
        e.registerServerCommand(new TpaHereCmd());
        e.registerServerCommand(new TpAcceptCmd());
        e.registerServerCommand(new TpAcceptAllCmd());
        e.registerServerCommand(new TpaDenyCmd());
        e.registerServerCommand(new TpaDenyAllCmd());
        e.registerServerCommand(new TpaCancelCmd());
    }

    static String key(String from, String to) { return from + "->" + to; }

    static void cleanExpired() {
        long now = System.currentTimeMillis();
        Iterator<Map.Entry<String,Long>> it = pending.entrySet().iterator();
        while (it.hasNext()) { if (now - it.next().getValue() > TIMEOUT_MS) it.remove(); }
    }

    static EntityPlayerMP findPlayer(MinecraftServer srv, String name) {
        for (Object o : srv.getConfigurationManager().playerEntityList) {
            EntityPlayerMP p = (EntityPlayerMP) o;
            if (p.getGameProfile().getName().equalsIgnoreCase(name)) return p;
        }
        return null;
    }

    static class TpaCmd extends CommandBase {
        public String getCommandName() { return "tpa"; }
        public int getRequiredPermissionLevel() { return 0; }
        public String getCommandUsage(ICommandSender s) { return "/tpa <player>"; }
        public void processCommand(ICommandSender sender, String[] args) throws CommandException {
            if (!(sender instanceof EntityPlayerMP)) throw new CommandException("Players only.");
            if (args.length < 1) throw new CommandException("Usage: /tpa <player>");
            EntityPlayerMP from = (EntityPlayerMP) sender;
            EntityPlayerMP to = findPlayer(MinecraftServer.getServer(), args[0]);
            if (to == null) throw new CommandException("Player not found: " + args[0]);
            if (to == from) throw new CommandException("You cannot tpa to yourself.");
            cleanExpired();
            pending.put(key(from.getGameProfile().getName(), to.getGameProfile().getName()), System.currentTimeMillis());
            from.addChatMessage(new ChatComponentText("Teleport request sent to " + to.getGameProfile().getName() + ". Expires in 60s."));
            to.addChatMessage(new ChatComponentText(from.getGameProfile().getName() + " wants to teleport to you. Use /tpaccept or /tpadeny."));
        }
    }
    static class TpaHereCmd extends CommandBase {
        public String getCommandName() { return "tpahere"; }
        public int getRequiredPermissionLevel() { return 0; }
        public String getCommandUsage(ICommandSender s) { return "/tpahere <player>"; }
        public void processCommand(ICommandSender sender, String[] args) throws CommandException {
            if (!(sender instanceof EntityPlayerMP)) throw new CommandException("Players only.");
            if (args.length < 1) throw new CommandException("Usage: /tpahere <player>");
            EntityPlayerMP from = (EntityPlayerMP) sender;
            EntityPlayerMP to = findPlayer(MinecraftServer.getServer(), args[0]);
            if (to == null) throw new CommandException("Player not found: " + args[0]);
            if (to == from) throw new CommandException("You cannot tpahere yourself.");
            cleanExpired();
            pending.put(key(from.getGameProfile().getName(), to.getGameProfile().getName()) + ":here", System.currentTimeMillis());
            from.addChatMessage(new ChatComponentText("Request sent to " + to.getGameProfile().getName() + " to come to you. Expires in 60s."));
            to.addChatMessage(new ChatComponentText(from.getGameProfile().getName() + " wants you to teleport to them. Use /tpaccept or /tpadeny."));
        }
    }
    static class TpAcceptCmd extends CommandBase {
        public String getCommandName() { return "tpaccept"; }
        public int getRequiredPermissionLevel() { return 0; }
        public String getCommandUsage(ICommandSender s) { return "/tpaccept <player>"; }
        public void processCommand(ICommandSender sender, String[] args) throws CommandException {
            if (!(sender instanceof EntityPlayerMP)) throw new CommandException("Players only.");
            if (args.length < 1) throw new CommandException("Usage: /tpaccept <player>");
            EntityPlayerMP me = (EntityPlayerMP) sender;
            String requester = args[0];
            cleanExpired();
            String k = key(requester, me.getGameProfile().getName());
            String kh = k + ":here";
            if (pending.containsKey(k)) {
                pending.remove(k);
                EntityPlayerMP req = findPlayer(MinecraftServer.getServer(), requester);
                if (req != null) { req.setPositionAndUpdate(me.posX, me.posY, me.posZ); req.addChatMessage(new ChatComponentText("Teleport accepted.")); }
                me.addChatMessage(new ChatComponentText("Accepted teleport from " + requester + "."));
            } else if (pending.containsKey(kh)) {
                pending.remove(kh);
                EntityPlayerMP req = findPlayer(MinecraftServer.getServer(), requester);
                if (req != null) { me.setPositionAndUpdate(req.posX, req.posY, req.posZ); req.addChatMessage(new ChatComponentText("Teleport accepted.")); }
                me.addChatMessage(new ChatComponentText("Accepted teleport to " + requester + "."));
            } else {
                throw new CommandException("No pending request from " + requester + ".");
            }
        }
    }
    static class TpAcceptAllCmd extends CommandBase {
        public String getCommandName() { return "tpacceptall"; }
        public int getRequiredPermissionLevel() { return 0; }
        public String getCommandUsage(ICommandSender s) { return "/tpacceptall"; }
        public void processCommand(ICommandSender sender, String[] args) throws CommandException {
            if (!(sender instanceof EntityPlayerMP)) throw new CommandException("Players only.");
            EntityPlayerMP me = (EntityPlayerMP) sender;
            cleanExpired();
            String myName = me.getGameProfile().getName();
            int count = 0;
            Iterator<Map.Entry<String,Long>> it = pending.entrySet().iterator();
            while (it.hasNext()) {
                Map.Entry<String,Long> e = it.next();
                String k = e.getKey();
                boolean here = k.endsWith(":here");
                String base = here ? k.substring(0, k.length()-5) : k;
                String[] parts = base.split("->");
                if (parts.length != 2 || !parts[1].equals(myName)) continue;
                it.remove(); count++;
                EntityPlayerMP req = findPlayer(MinecraftServer.getServer(), parts[0]);
                if (req == null) continue;
                if (here) { me.setPositionAndUpdate(req.posX, req.posY, req.posZ); }
                else { req.setPositionAndUpdate(me.posX, me.posY, me.posZ); }
                req.addChatMessage(new ChatComponentText("Teleport accepted."));
            }
            me.addChatMessage(new ChatComponentText("Accepted " + count + " teleport request(s)."));
        }
    }
    static class TpaDenyCmd extends CommandBase {
        public String getCommandName() { return "tpadeny"; }
        public int getRequiredPermissionLevel() { return 0; }
        public String getCommandUsage(ICommandSender s) { return "/tpadeny <player>"; }
        public void processCommand(ICommandSender sender, String[] args) throws CommandException {
            if (!(sender instanceof EntityPlayerMP)) throw new CommandException("Players only.");
            if (args.length < 1) throw new CommandException("Usage: /tpadeny <player>");
            EntityPlayerMP me = (EntityPlayerMP) sender;
            String requester = args[0];
            cleanExpired();
            String k = key(requester, me.getGameProfile().getName());
            boolean removed = pending.remove(k) != null | pending.remove(k + ":here") != null;
            if (!removed) throw new CommandException("No pending request from " + requester + ".");
            me.addChatMessage(new ChatComponentText("Denied teleport from " + requester + "."));
            EntityPlayerMP req = findPlayer(MinecraftServer.getServer(), requester);
            if (req != null) req.addChatMessage(new ChatComponentText(me.getGameProfile().getName() + " denied your teleport request."));
        }
    }
    static class TpaDenyAllCmd extends CommandBase {
        public String getCommandName() { return "tpadenyall"; }
        public int getRequiredPermissionLevel() { return 0; }
        public String getCommandUsage(ICommandSender s) { return "/tpadenyall"; }
        public void processCommand(ICommandSender sender, String[] args) throws CommandException {
            if (!(sender instanceof EntityPlayerMP)) throw new CommandException("Players only.");
            EntityPlayerMP me = (EntityPlayerMP) sender;
            cleanExpired();
            String myName = me.getGameProfile().getName();
            int count = 0;
            Iterator<Map.Entry<String,Long>> it = pending.entrySet().iterator();
            while (it.hasNext()) {
                Map.Entry<String,Long> e = it.next();
                String k = e.getKey();
                String base = k.endsWith(":here") ? k.substring(0, k.length()-5) : k;
                String[] parts = base.split("->");
                if (parts.length != 2 || !parts[1].equals(myName)) continue;
                it.remove(); count++;
                EntityPlayerMP req = findPlayer(MinecraftServer.getServer(), parts[0]);
                if (req != null) req.addChatMessage(new ChatComponentText(myName + " denied your teleport request."));
            }
            me.addChatMessage(new ChatComponentText("Denied " + count + " teleport request(s)."));
        }
    }
    static class TpaCancelCmd extends CommandBase {
        public String getCommandName() { return "tpacancel"; }
        public int getRequiredPermissionLevel() { return 0; }
        public String getCommandUsage(ICommandSender s) { return "/tpacancel <player|all>"; }
        public void processCommand(ICommandSender sender, String[] args) throws CommandException {
            if (!(sender instanceof EntityPlayerMP)) throw new CommandException("Players only.");
            if (args.length < 1) throw new CommandException("Usage: /tpacancel <player|all>");
            EntityPlayerMP me = (EntityPlayerMP) sender;
            String myName = me.getGameProfile().getName();
            cleanExpired();
            if ("all".equalsIgnoreCase(args[0])) {
                int count = 0;
                Iterator<Map.Entry<String,Long>> it = pending.entrySet().iterator();
                while (it.hasNext()) {
                    Map.Entry<String,Long> e = it.next();
                    String base = e.getKey().endsWith(":here") ? e.getKey().substring(0, e.getKey().length()-5) : e.getKey();
                    if (base.startsWith(myName + "->")) { it.remove(); count++; }
                }
                me.addChatMessage(new ChatComponentText("Cancelled " + count + " outgoing request(s)."));
            } else {
                String target = args[0];
                String k = key(myName, target);
                boolean removed = pending.remove(k) != null | pending.remove(k + ":here") != null;
                if (!removed) throw new CommandException("No pending request to " + target + ".");
                me.addChatMessage(new ChatComponentText("Cancelled request to " + target + "."));
            }
        }
    }
}
