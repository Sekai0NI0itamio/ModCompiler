package asd.itamio.veinminer;
import net.minecraft.client.Minecraft;
import net.minecraft.client.KeyMapping;
import net.minecraft.network.chat.Component;
import net.neoforged.neoforge.client.event.InputEvent;
import net.neoforged.neoforge.client.event.RegisterKeyMappingsEvent;
import net.neoforged.bus.api.SubscribeEvent;
import org.lwjgl.glfw.GLFW;
public class VeinMinerKeyHandler {
    public static final KeyMapping toggleKey = new KeyMapping(
        "Toggle Vein Miner", GLFW.GLFW_KEY_V,
        KeyMapping.Category.lookup("Vein Miner").orElseGet(() -> KeyMapping.Category.create("Vein Miner", 0))
    );
    public static boolean veinMinerEnabled = true;
    public static void register(RegisterKeyMappingsEvent event) { event.register(toggleKey); }
    @SubscribeEvent
    public void onKeyInput(InputEvent.Key event) {
        if (toggleKey.consumeClick()) {
            veinMinerEnabled = !veinMinerEnabled;
            String msg = veinMinerEnabled ? "§aVein Miner: ENABLED" : "§cVein Miner: DISABLED";
            Minecraft.getInstance().player.displayClientMessage(Component.literal(msg), false);
        }
    }
}
