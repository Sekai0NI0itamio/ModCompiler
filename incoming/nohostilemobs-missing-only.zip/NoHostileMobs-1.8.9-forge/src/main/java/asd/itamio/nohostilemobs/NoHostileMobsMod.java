package asd.itamio.nohostilemobs;

import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.monster.IMob;
import net.minecraftforge.event.entity.living.LivingSpawnEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.event.FMLInitializationEvent;
import net.minecraftforge.fml.common.eventhandler.Event.Result;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.common.MinecraftForge;

@Mod(modid = NoHostileMobsMod.MODID, name = "No Hostile Mobs", version = "1.0.0",
     acceptedMinecraftVersions = "[1.8.9]")
public class NoHostileMobsMod {
    public static final String MODID = "nohostilemobs";

    @Mod.EventHandler
    public void init(FMLInitializationEvent event) {
        MinecraftForge.EVENT_BUS.register(this);
    }

    @SubscribeEvent
    public void onCheckSpawn(LivingSpawnEvent.CheckSpawn event) {
        EntityLivingBase entity = event.entityLiving;
        if (entity instanceof IMob) {
            event.setResult(Result.DENY);
        }
    }
}
