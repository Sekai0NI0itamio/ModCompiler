package asd.itamio.nohostilemobs;

import net.fabricmc.api.ModInitializer;

public class NoHostileMobsMod implements ModInitializer {
    @Override
    public void onInitialize() {
        // Spawn blocking handled via MobSpawnMixin
    }
}
