package asd.itamio.nohostilemobs;

import net.minecraft.world.entity.MobCategory;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.Mod;
import net.neoforged.neoforge.common.NeoForge;
import net.neoforged.neoforge.event.entity.EntityJoinLevelEvent;

@Mod(NoHostileMobsMod.MODID)
public class NoHostileMobsMod {
    public static final String MODID = "nohostilemobs";

    public NoHostileMobsMod(IEventBus modBus) {
        NeoForge.EVENT_BUS.register(this);
    }

    @SubscribeEvent
    public void onEntityJoinLevel(EntityJoinLevelEvent event) {
        if (event.getEntity().getType().getCategory() == MobCategory.MONSTER) {
            event.setCanceled(true);
        }
    }
}
