package asd.itamio.nohostilemobs.mixin;

import net.minecraft.entity.MobEntity;
import net.minecraft.entity.SpawnGroup;
import net.minecraft.world.WorldAccess;
import net.minecraft.entity.SpawnReason;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(MobEntity.class)
public class MobSpawnMixin {
    @Inject(method = "canSpawn(Lnet/minecraft/world/WorldAccess;Lnet/minecraft/entity/SpawnReason;)Z",
            at = @At("HEAD"), cancellable = true)
    private void blockHostileSpawn(WorldAccess world, SpawnReason reason, CallbackInfoReturnable<Boolean> cir) {
        MobEntity self = (MobEntity)(Object)this;
        if (self.getType().getSpawnGroup() == SpawnGroup.MONSTER) {
            cir.setReturnValue(false);
        }
    }
}
