package asd.itamio.nohostilemobs;

import net.minecraft.world.entity.monster.Monster;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.event.entity.living.LivingSpawnEvent;
import net.minecraftforge.eventbus.api.Event.Result;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod(NoHostileMobsMod.MODID)
public class NoHostileMobsMod {
    public static final String MODID = "nohostilemobs";

    public NoHostileMobsMod() {
        MinecraftForge.EVENT_BUS.register(this);
    }

    @SubscribeEvent
    public void onCheckSpawn(LivingSpawnEvent.CheckSpawn event) {
        if (event.getEntity() instanceof Monster) {
            event.setResult(Result.DENY);
        }
    }
}
